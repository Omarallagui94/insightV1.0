const mongoose = require('mongoose');

const storeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  location: {
    type: String
  },
  storeOwnerId:{
    type: String
  },
  photo: {
    type: String // You might want to use a different type depending on how you're storing the photos (e.g., URL, Base64, etc.)
  },
  slogan: {
    type: String
  }
});

module.exports = mongoose.model('Store', storeSchema);
