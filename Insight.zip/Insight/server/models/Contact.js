const mongoose = require('mongoose');

const ContactSchema = new mongoose.Schema({
  PhoneNumber: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    default: 'waiting'
  },
  date: {
    type: Date, // Adding a date field
    default: Date.now // Default value is current date and time
  }
});

module.exports = mongoose.model('Contact', ContactSchema);
