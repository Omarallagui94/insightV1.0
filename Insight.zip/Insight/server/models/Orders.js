const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  id: {
    type: String
  },
  date: {
    type: Date,
    default: Date.now
  },
  person: {
    personId: String,
    personName: String
  },
  addOns: {
    type: String
  },
  products: [{
    productId: String,
    productName: String,
    quantity: Number,
    ingredients: [{
      name: String,
      quantity: Number,
      identifier: String
    }]
  }],
  paid: {
    type: Boolean,
    default: false
  },
  storeId: { // New field for store ID
    type: String // Assuming store ID is a string
  }
});

module.exports = mongoose.model('Orders', OrderSchema);
