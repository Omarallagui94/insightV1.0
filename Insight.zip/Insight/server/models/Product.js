const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  qty: {
    type: Number,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  sum: {
    type: Number,
    required: true
  },
  category: {
    type: String,
    required: true
  },
  description: {
    type: String
  },
  imageUrl: {
    type: String
  },
  ingredients: [{
    name: String,
    quantity: Number,
    identifier: String // New field added
  }],
  storeId: { // New field for store ID
    type: String // Assuming store ID is a string
  }
});

module.exports = mongoose.model('Product', productSchema);
