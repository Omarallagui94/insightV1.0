const mongoose = require('mongoose');

const expensesSchema = new mongoose.Schema({
    name: { type: String, required: true },
    qty: { type: Number, default: 1 }, // Set default quantity to 1
    date: { type: Date },
    price: { type: Number },
    type:{type:String},
    storeId: { type: String } // Add storeId field
});

const ExpensesModel = mongoose.model('Expenses', expensesSchema);
module.exports = ExpensesModel;
