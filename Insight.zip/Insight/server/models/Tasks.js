const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
    task: {
        type: String,
        required: true
    },
    importance: {
        type: String,
    },
    status: {
        type: String,
    },
    workerId: {
        type: String,
    },
    askerId: {
        type: String,
    },
    description: {
        type: String,
    },
    time: {  // New field for time of the task
        type: Date,
        default: Date.now
    }
});

const TaskModel = mongoose.model('Tasks', taskSchema);

module.exports = TaskModel;
