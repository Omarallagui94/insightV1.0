const mongoose = require('mongoose');

const inventoryCategorySchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  storeId: {
    type: String,
    required: true
  }
});

const InventoryCategory = mongoose.model('InventoryCategory', inventoryCategorySchema);

module.exports = InventoryCategory;
