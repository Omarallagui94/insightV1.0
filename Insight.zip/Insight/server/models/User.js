const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, default: "server" },
  storeId: { type: String },
  phoneNumber: { type: String },
  photo: { type: String },
  history: [{
    loginTime: { type: Date },
    logoutTime: { type: Date }
  }],
  salary: { type: Number } // New field for storing salary as a number
});

const UserModel = mongoose.model('Users', UserSchema);

module.exports = UserModel;
