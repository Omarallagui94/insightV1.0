const mongoose = require('mongoose');

const inventoryItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  qty: {
    type: Number,
    required: true
  },
  categ: {
    type: String,
    required: true
  },
  unit: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  minimumQuantity: {
    type: Number,
    required: true
  },
  type: { // Adding the new field "type"
    type: String, // Assuming type is a string, modify as needed
    required: true
  },
  storeId: { // New field for store ID
    type: String // Assuming store ID is a string
  }
});

const InventoryItem = mongoose.model('InventoryItem', inventoryItemSchema);

module.exports = InventoryItem;
