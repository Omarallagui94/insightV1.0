const express = require('express');
const mongoose = require('mongoose');
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const UserModel = require("./models/User");
const Product = require('./models/Product');
const Category = require('./models/Categorie');
const InventoryItem = require('./models/InventoryItem');
const InventoryCategory = require('./models/inventoryCategory');
const { uploadImage, uploadMultipleImages } = require ('./uploadImage');
const Orders = require('./models/Orders');
const Store = require('./models/Store');
const TaskModel = require('./models/Tasks'); // Assuming TaskModel.js is in the same directory
const Contact = require('./models/Contact'); // Assuming Contact.js is in the same directory
const ExpensesModel = require('./models/Expenses'); // Assuming Contact.js is in the same directory





const app = express();
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));
app.use(cors({
  origin: "http://localhost:3000", // Allow requests from this origin
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true
}));
app.use(cookieParser());

mongoose.connect('mongodb://localhost:27017/employee');

/// Register route
app.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
  bcrypt.hash(password, 10)
    .then(hashedPassword => {
      UserModel.create({ name, email, password: hashedPassword })
        .then(user => res.json("success"))
        .catch(err => res.json(err))
    }).catch(err => res.json(err));
});


// Login route
app.post("/login", (req, res) => {
  const { email, password } = req.body;
  UserModel.findOne({ email: email })
    .then(user => {
      if (user) {
        bcrypt.compare(password, user.password, (err, response) => {
          if (response) {
            const loginTime = Date.now();
            const historyObj = { loginTime: loginTime };

            // Save the history object to the user's history array
            user.history.push(historyObj);
            user.save()
              .then(savedUser => {
                const historyId = savedUser.history[savedUser.history.length - 1]._id; // Capture the _id of the last added history object
                const token = jwt.sign({ id: savedUser.id, email: savedUser.email, role: savedUser.role, name: savedUser.name, storeId: savedUser.storeId, photo: savedUser.photo, historyId: historyId }, "jwt-scrkey", { expiresIn: '1d' });
                res.cookie('token', token);
                return res.json({ Status: "Success", token, name: savedUser.name, role: savedUser.role });
              })
              .catch(err => {
                console.error(err);
                res.status(500).json({ message: "An error occurred while saving user history" });
              });
          } else {
            return res.json("Password is incorrect");
          }
        });
      } else {
        return res.json("No record exists");
      }
    })
    .catch(err => {
      console.error(err);
      res.status(500).json({ message: "An error occurred while logging in" });
    });
});

app.put('/logout-user/:userId/:historyId', async (req, res) => {
  const { userId, historyId } = req.params;
  
  try {
    const user = await UserModel.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Find the history object with the given ID
    const historyItem = user.history.id(historyId);

    if (!historyItem) {
      return res.status(404).json({ message: 'History item not found' });
    }

    // Update the logout time
    historyItem.logoutTime = new Date();

    // Save the changes to the user document
    await user.save();

    res.json({ message: 'Logout time updated successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
});
// CRUD operations for contact

// Add Contact route
app.post('/add-contact', async (req, res) => {
  const { phoneNumber, status } = req.body;

  try {
    const date = new Date(); // Get current system date and time
    const newContact = new Contact({ PhoneNumber: phoneNumber, status: status, date: date }); // Including date
    const savedContact = await newContact.save();
    res.status(201).json(savedContact);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Get all contacts route
app.get('/contacts', async (req, res) => {
  try {
    const contacts = await Contact.find();
    res.status(200).json(contacts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get contact by ID route
app.get('/contact/:id', async (req, res) => {
  const contactId = req.params.id;

  try {
    const contact = await Contact.findById(contactId);
    if (!contact) {
      return res.status(404).json({ message: 'Contact not found' });
    }
    res.status(200).json(contact);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update contact route
app.put('/update-contact/:id', async (req, res) => {
  const { PhoneNumber,status } = req.body;
  const contactId = req.params.id;

  try {
    const updatedContact = await Contact.findByIdAndUpdate(contactId, { PhoneNumber,status }, { new: true });
    res.status(200).json(updatedContact);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete contact route
app.delete('/delete-contact/:id', async (req, res) => {
  const contactId = req.params.id;

  try {
    const deletedContact = await Contact.findByIdAndDelete(contactId);
    res.status(200).json({ message: "Contact deleted successfully", deletedContact });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});




// CRUD operations for Products

// Add Products route
app.post('/add-product', async (req, res) => {
  const { name, qty, price, sum, category, description, imageUrl, ingredients, storeId } = req.body;

  try {
    // Create a new product instance
    const newProduct = new Product({
      name,
      qty,
      price,
      sum,
      category,
      description,
      imageUrl,
      ingredients, // Add ingredients to the product
      storeId // Add storeId to the product
    });

    // Save the product to the database
    const savedProduct = await newProduct.save();

    res.status(201).json(savedProduct);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Get all products route
app.get('/products', async (req, res) => {
  try {
    const products = await Product.find();
    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update product route
app.put('/update-product/:id', async (req, res) => {
  const { name, qty, price, sum, category, description, imageUrl, ingredients, storeId } = req.body;
  const productId = req.params.id;

  try {
    // Find the product by ID and update it
    const updatedProduct = await Product.findByIdAndUpdate(productId, {
      name,
      qty,
      price,
      sum,
      category,
      description,
      imageUrl,
      ingredients, // Update ingredients as well
      storeId // Add storeId to the product
    }, { new: true });

    res.status(200).json(updatedProduct);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete product route
app.delete('/delete-product/:id', async (req, res) => {
  const productId = req.params.id;

  try {
    // Find the product by ID and delete it
    const deletedProduct = await Product.findByIdAndDelete(productId);
    res.status(200).json({ message: "Product deleted successfully", deletedProduct });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get product by ID route
app.get('/product/:id', async (req, res) => {
  const productId = req.params.id;

  try {
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.status(200).json(product);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});
// Get products by category route
app.get('/products/:category', async (req, res) => {
  const category = req.params.category;

  try {
    const products = await Product.find({ category });
    if (products.length === 0) {
      return res.status(404).json({ message: `No products found in category ${category}` });
    }
    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// CRUD operations for Categories

// Add Category route
app.post('/add-category', async (req, res) => {
  const { name, storeId } = req.body; // Assuming storeId is provided in the request body

  try {
    const newCategory = new Category({ name, storeId }); // Include storeId in the Category creation
    const savedCategory = await newCategory.save();
    res.status(201).json(savedCategory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});



// Get all categories route
app.get('/categories', async (req, res) => {
  try {
    const categories = await Category.find();
    res.status(200).json(categories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update category route
app.put('/update-category/:id', async (req, res) => {
  const { name, storeId } = req.body; // Include storeId in the request body
  const categoryId = req.params.id;

  try {
    // Find the category by its ID and update its name and storeId
    const updatedCategory = await Category.findByIdAndUpdate(
      categoryId,
      { name, storeId }, // Include storeId in the update
      { new: true }
    );
    res.status(200).json(updatedCategory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Delete category route
app.delete('/delete-category/:id', async(req, res) => {
  const categoryId = req.params.id;

  try {
    const deletedCategory = await Category.findByIdAndDelete(categoryId);
    res.status(200).json({ message: "Category deleted successfully", deletedCategory });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// CRUD operations for Users

// Add user route
app.post('/add-user', async (req, res) => {
  const { name, email, role, password, storeId, photo, phoneNumber,salary } = req.body; // Including phoneNumber field from request body

  try {
    const newUser = new UserModel({ name, email, role, password, storeId, photo, phoneNumber,salary }); // Including phoneNumber when creating a new user
    const savedUser = await newUser.save();
    res.status(201).json(savedUser);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all users route
app.get('/users', async (req, res) => {
  try {
    const users = await UserModel.find();
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update user route
app.put('/update-user/:id', async (req, res) => {
  const { name, email, password, role, storeId, photo, phoneNumber, salary } = req.body; // Including phoneNumber and salary fields
  const userId = req.params.id;

  try {
    // Update user data along with storeId, photo, phoneNumber, and salary
    const updatedUser = await UserModel.findByIdAndUpdate(userId, { name, email, password, role, storeId, photo, phoneNumber, salary }, { new: true });
    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Delete user route
app.delete('/delete-user/:id', async (req, res) => {
  const userId = req.params.id;

  try {
    const deletedUser = await UserModel.findByIdAndDelete(userId);
    res.status(200).json({ message: "User deleted successfully", deletedUser });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});
// Get user history route
app.get('/user-history/:id', async (req, res) => {
  const userId = req.params.id;

  try {
    // Fetch user history based on user ID
    const userHistory = await HistoryModel.find({ userId }); // Assuming you have a HistoryModel with a userId field
    res.status(200).json(userHistory);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


// Get users by store ID route
app.get('/users/:storeId', async (req, res) => {
  const storeId = req.params.storeId;

  try {
    const users = await UserModel.find({ storeId: storeId });
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get user by ID route with history populated
app.get('/user/:id', async (req, res) => {
  const userId = req.params.id;

  try {
    const user = await UserModel.findById(userId).populate('history');
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Add this route to handle updating the user's storeId
app.put('/update-user-store/:id', async (req, res) => {
  const userId = req.params.id;
  const { storeId } = req.body;

  try {
    const updatedUser = await UserModel.findByIdAndUpdate(userId, { storeId }, { new: true });
    res.status(200).json(updatedUser);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// CRUD operations for itemes 

// Add inventory item route
app.post('/add-inventory-item', async (req, res) => {
  const { name, qty, categ, unit, price, minimumQuantity, type, storeId } = req.body;

  try {
    const newInventoryItem = new InventoryItem({ name, qty, categ, unit, price, minimumQuantity, type, storeId });
    const savedInventoryItem = await newInventoryItem.save();
    res.status(201).json(savedInventoryItem);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Get all inventory items route
app.get('/inventory-items', async (req, res) => {
  try {
    const inventoryItems = await InventoryItem.find();
    res.status(200).json(inventoryItems);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});
// Update inventory item route
app.put('/update-inventory-item/:id', async (req, res) => {
  const { name, qty, categ, unit, price, minimumQuantity, type, storeId } = req.body;
  const inventoryItemId = req.params.id;

  try {
    const updatedInventoryItem = await InventoryItem.findByIdAndUpdate(
      inventoryItemId,
      { name, qty, categ, unit, price, minimumQuantity, type, storeId },
      { new: true }
    );
    res.status(200).json(updatedInventoryItem);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete inventory item route
app.delete('/delete-inventory-item/:id', async (req, res) => {
  const inventoryItemId = req.params.id;

  try {
    const deletedInventoryItem = await InventoryItem.findByIdAndDelete(inventoryItemId);
    res.status(200).json({ message: "Inventory item deleted successfully", deletedInventoryItem });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});
// Get all inventory items with a specific type route
app.get('/inventory-items/:type', async (req, res) => {
  const itemType = req.params.type;

  try {
    const inventoryItems = await InventoryItem.find({ type: itemType });
    res.status(200).json(inventoryItems);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


// Add inventory categories route
app.post('/add-inventory-category', async (req, res) => {
  const { name, storeId } = req.body; // Extracting storeId from the request body

  try {
    const newInventoryCategory = new InventoryCategory({ name, storeId }); // Including storeId when creating a new InventoryCategory
    const savedInventoryCategory = await newInventoryCategory.save();
    res.status(201).json(savedInventoryCategory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Get all inventory categories route
app.get('/inventory-categories', async (req, res) => {
  try {
    const inventoryCategories = await InventoryCategory.find();
    res.status(200).json(inventoryCategories);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update inventory category route
app.put('/update-inventory-category/:id', async (req, res) => {
  const { name, storeId } = req.body; // Extracting storeId from the request body
  const inventoryCategoryId = req.params.id;

  try {
    const updatedInventoryCategory = await InventoryCategory.findByIdAndUpdate(
      inventoryCategoryId,
      { name, storeId }, // Including storeId when updating the InventoryCategory
      { new: true }
    );
    res.status(200).json(updatedInventoryCategory);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Delete inventory category route
app.delete('/delete-inventory-category/:id', async(req, res) => {
  const inventoryCategoryId = req.params.id;

  try {
    const deletedInventoryCategory = await InventoryCategory.findByIdAndDelete(inventoryCategoryId);
    res.status(200).json({ message: "Inventory category deleted successfully", deletedInventoryCategory });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});



app.post("/uploadImage", (req, res) => {
  uploadImage(req.body.image)
    .then((url) => res.send(url))
    .catch((err) => res.status(500).send(err));
});

app.post("/uploadMultipleImages", (req, res) => {
  uploadMultipleImages(req.body.images)
    .then((urls) => res.send(urls))
    .catch((err) => res.status(500).send(err));
});

// CRUD operations for orders
// Add Order route
app.post('/add-order', async (req, res) => {
  const { products, person, addOns, paid, storeId } = req.body; // Destructure the storeId field from the request body

  try {
    // Iterate through each product in the order
    for (const productData of products) {
      const { productId, quantity, ingredients } = productData;

      // Update the quantity of each ingredient in the inventory
      for (const ingredient of ingredients) {
        const inventoryItem = await InventoryItem.findOne({ name: ingredient.name });
        if (inventoryItem) {
          // Calculate the used quantity based on product quantity and ingredient quantity
          const usedQuantity = quantity * ingredient.quantity;
          // Deduct the used quantity from the inventory
          inventoryItem.qty -= usedQuantity;
          // Save the updated inventory item
          await inventoryItem.save();
        }
      }
    }

    // Add the date, addOns, and paid to the order
    const date = new Date(); // Current date and time
    const newOrder = new Orders({ products, date, person, addOns, paid, storeId }); // Include person, addOns, paid, and storeId in the order
    const savedOrder = await newOrder.save();
    res.status(201).json(savedOrder);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Get all orders route
app.get('/orders', async (req, res) => {
  try {
    const orders = await Orders.find().populate('person', 'personId personName');
    res.status(200).json(orders);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


// Update order route
app.put('/update-order/:id', async (req, res) => {
  const { id, addOns, products, person, paid,storeId } = req.body;
  const orderId = req.params.id;

  try {
    const updatedOrder = await Orders.findByIdAndUpdate(orderId, { id, addOns, products, person, paid,storeId }, { new: true });
    res.status(200).json(updatedOrder);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete order route
app.delete('/delete-order/:id', async(req, res) => {
  const orderId = req.params.id;

  try {
    const deletedOrder = await Orders.findByIdAndDelete(orderId);
    res.status(200).json({ message: "Order deleted successfully", deletedOrder });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Get orders by person ID route
app.get('/orders/person/:personId', async (req, res) => {
  const personId = req.params.personId; // Extract person ID from the request parameters

  try {
    // Find orders associated with the specified person ID
    const orders = await Orders.find({ 'person.personId': personId }).populate('person', 'personId personName');
    res.status(200).json(orders);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get orders by store ID route
app.get('/orders/store/:storeId', async (req, res) => {
  const storeId = req.params.storeId; // Extract store ID from the request parameters

  try {
    // Find orders associated with the specified store ID
    const orders = await Orders.find({ storeId: storeId }).populate('person', 'personId personName');
    res.status(200).json(orders);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});



/// CRUD operations for Stores

// Add Store route
app.post('/add-store', async (req, res) => {
  const { name, description, location, storeOwnerId, photo, slogan } = req.body;

  try {
    const newStore = new Store({ name, description, location, storeOwnerId, photo, slogan });
    const savedStore = await newStore.save();
    res.status(201).json(savedStore);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get all stores route
app.get('/stores', async (req, res) => {
  try {
    const stores = await Store.find();
    res.status(200).json(stores);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update store route
app.put('/update-store/:id', async (req, res) => {
  const { name, description, location, storeOwnerId, photo, slogan } = req.body;
  const storeId = req.params.id;

  try {
    const updatedStore = await Store.findByIdAndUpdate(storeId, { name, description, location, storeOwnerId, photo, slogan }, { new: true });
    res.status(200).json(updatedStore);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete store route
app.delete('/delete-store/:id', async(req, res) => {
  const storeId = req.params.id;

  try {
    const deletedStore = await Store.findByIdAndDelete(storeId);
    res.status(200).json({ message: "Store deleted successfully", deletedStore });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Get store owner ID route
app.get('/store-owner/:storeId', async (req, res) => {
  const storeId = req.params.storeId;

  try {
    const store = await Store.findById(storeId);
    if (!store) {
      return res.status(404).json({ message: "Store not found" });
    }
    res.status(200).json({ storeOwnerId: store.storeOwnerId });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get store by ID route
app.get('/stores/:id', async (req, res) => {
  const storeId = req.params.id;

  try {
    const store = await Store.findById(storeId, 'name description location storeOwnerId photo slogan');
    if (!store) {
      return res.status(404).json({ message: "Store not found" });
    }
    res.status(200).json(store);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


// CRUD operations for tasks

// Add task route
app.post('/add-task', async (req, res) => {
  const { task, importance, status, workerId, askerId, description, time } = req.body;

  try {
    const newTask = new TaskModel({ task, importance, status, workerId, askerId, description, time });
    const savedTask = await newTask.save();
    res.status(201).json(savedTask);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Get All Tasks
app.get('/tasks', async (req, res) => {
  try {
    const tasks = await TaskModel.find();
    res.status(200).json(tasks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});


// Get Task by ID
app.get('/tasks/:id', async (req, res) => {
  const taskId = req.params.id;

  try {
    const task = await TaskModel.findById(taskId);
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }
    res.status(200).json(task);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update Task
app.put('/tasks/:id', async (req, res) => {
  const taskId = req.params.id;
  const { task, importance, status, workerId, askerId, description, time } = req.body;

  try {
    const updatedTask = await TaskModel.findByIdAndUpdate(taskId, { task, importance, status, workerId, askerId, description, time }, { new: true });
    res.status(200).json(updatedTask);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});



// Get Tasks by Worker ID
app.get('/tasks/worker/:workerId', async (req, res) => {
  const workerId = req.params.workerId;

  try {
    const tasks = await TaskModel.find({ workerId: workerId });
    res.status(200).json(tasks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete Task
app.delete('/tasks/:id', async (req, res) => {
  const taskId = req.params.id;

  try {
    const deletedTask = await TaskModel.findByIdAndDelete(taskId);
    if (!deletedTask) {
      return res.status(404).json({ message: 'Task not found' });
    }
    res.status(200).json({ message: 'Task deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get Tasks by Time Range
app.get('/tasks/time/:start/:end', async (req, res) => {
  const startTime = new Date(req.params.start);
  const endTime = new Date(req.params.end);

  try {
    const tasks = await TaskModel.find({ time: { $gte: startTime, $lte: endTime } });
    res.status(200).json(tasks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Add Expense route
app.post('/add-expense', async (req, res) => {
  const { name, qty, date, price, type,storeId } = req.body; // Include storeId from req.body

  try {
    const newExpense = new ExpensesModel({ name, qty, date, price,type, storeId }); // Include storeId when creating the new expense
    const savedExpense = await newExpense.save();
    res.status(201).json(savedExpense);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});


// Get all expenses route
app.get('/expenses', async (req, res) => {
  try {
    const expenses = await ExpensesModel.find();
    res.status(200).json(expenses);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get expense by ID route
app.get('/expense/:id', async (req, res) => {
  const expenseId = req.params.id;

  try {
    const expense = await ExpensesModel.findById(expenseId);
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    res.status(200).json(expense);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update expense route
app.put('/update-expense/:id', async (req, res) => {
  const { name, qty, date,price } = req.body;
  const expenseId = req.params.id;

  try {
    const updatedExpense = await ExpensesModel.findByIdAndUpdate(expenseId, { name, qty, date,price }, { new: true });
    res.status(200).json(updatedExpense);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete expense route
app.delete('/delete-expense/:id', async (req, res) => {
  const expenseId = req.params.id;

  try {
    const deletedExpense = await ExpensesModel.findByIdAndDelete(expenseId);
    res.status(200).json({ message: "Expense deleted successfully", deletedExpense });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

