/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      borderRadius: {
        '4xl': '3rem', // Example of a bigger size than 3xl
        'custom': '28px', // Custom border radius style
      },
      height:{
        custom :'9.3rem',
        cat1:"140px",
        cart:'1080px',
        car:"345px",
        '100':"100px"
      },
      width:{
        custom :'21rem',
        cust: '910px',
        page:'83rem',
        page1:'83rem',
        cat2:'140px',
        catbar:"500px",
        '42':"170px",
        "900":"900px"


      },
      colors: {
        'custom-gray': '#D0D1D1',
        'custom-green': "#20B486",
        'custom-light-green': "#E8F5EF",
        b1: '#003A20',
        b2: '#F8F8FA',
        bout: '#1d9a5f',
        bla: '#282828',
        g1: '#919895',
        logtex: '#003a20',
        pro: '#f0f0f0',
        catName:'#5d5b70',
        ord:'#fbbc31',
        catbg:'#f5efe1',
        chekou:'#09b52f',
        hist:"#f7fbfe",
        cancel:"#ed8097",
        ger:"#7ebc7b",
        worheader:"#f9fafc",
        inventbar:"#f7f8fc",
        card :"#F2613F"
        
      },
      spacing: {
        '434': '434px', // custom height
        '488': '488px', // custom width
        '600':"600px",
        '85':"340px",
        '18':"72px"
      },
      fontFamily: {
        sans: ['DM Sans','Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'Noto Sans', 'sans-serif', 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji'],
      },
    },
  },
  plugins: [require('tailwind-scrollbar'),
],
};
