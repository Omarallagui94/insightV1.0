import React from 'react';
import './App.css';
import SignUpPage from './signup';
import LoginPage from './login';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navigation from './navigation';


function App() {
  return (
    <div className='DM Sans'>
      <Navigation  />

    </div>
  );
}

export default App;
