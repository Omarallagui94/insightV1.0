import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';
import cloapsSidebar from "../../Assets/less-than-1.png";
import ins from "../../Assets/ins.png";
import axios from 'axios';
import insight from "../../Assets/insight.png";
import {
  DashboardOutlined,
  ShopOutlined,
  ShoppingCartOutlined,
  TeamOutlined,
  CalculatorOutlined,
  DollarOutlined,
  SettingOutlined,
  MoonOutlined,
  AppstoreAddOutlined,
  UserOutlined,
  LoginOutlined,
  HistoryOutlined,
  SolutionOutlined,
  DatabaseOutlined,
} from "@ant-design/icons";


const Sidebar = () => {
  const [open, setOpen] = useState(true);
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [historyId, setHistoryId] = useState(null);
  const [selectedTab, setSelectedTab] = useState(null); // State to track selected tab

  useEffect(() => {
    // Retrieve token from local storage
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      const decodedToken = jwtDecode(storedToken);
      setUser(decodedToken);
      setHistoryId(decodedToken.historyId);
    }

    // Retrieve selected tab index from local storage
    const storedTab = localStorage.getItem('selectedTab');
    if (storedTab) {
      setSelectedTab(parseInt(storedTab));
    }
  }, []);

  useEffect(() => {
    // Store selected tab index in local storage
    localStorage.setItem('selectedTab', selectedTab);
  }, [selectedTab]);

  const toggleSidebar = () => {
    setOpen(!open);
  };
  
  const handleLogout = async () => {
    try {
      await axios.put(`http://localhost:3001/logout-user/${user.id}/${historyId}`);
      localStorage.removeItem('token');
      navigate('/');
    } catch (error) {
      console.log({ historyId });
      console.error('Error logging out:', error);
    }
  };

  const superadmin = [
    { title: "", isTitle: true },
    { title: "Stores", icon: <DashboardOutlined />, href: "/home/superAdmindashboard", tooltip: "stores" },

    { title: "Contact", icon: <DashboardOutlined />, href: "/home/contact", tooltip: "Contact" },
    { title: "Workers ", icon: <DollarOutlined />, href: "/home/addStoreOwners", tooltip: "AddStoreOwners" },

    { title: "profile", icon: <SettingOutlined />, href: "/home/profile", tooltip: "Profile" },
    { title: (
      <>
        <div>{user?.name}</div>
        <div style={{ fontSize: '0.8rem' }}>{user?.role}</div>
      </>
    ), icon: <UserOutlined />, gap: true, tooltip: "User" },
    { title: "Log out", icon: <LoginOutlined />, onClick: handleLogout, tooltip: "Log out" },
  ];

  const adminMenus = [
    { title: "MARKETING", isTitle: true },
    { title: "Dashboard", icon: <DashboardOutlined />, href: "/home/daashboard", tooltip: "Dashboard" },
    { title: "Expenses", icon: <DollarOutlined />, href: "/home/expenses", tooltip: "Expenses " },
    { title: "Menu", icon: <ShopOutlined />, href: "/home/addProducts", tooltip: "Menu" },
    { title: "Orders", icon: <ShoppingCartOutlined />, href: "/home/orders", tooltip: "Orders" },
    { title: "Stock", icon: <AppstoreAddOutlined />, href: "/home/inventory", tooltip: "Stock" },
    { title: "Order history", icon: <DatabaseOutlined />, href: "/home/customers", tooltip: "Customers" },
    { title: "TEAM", isTitle: true },
    { title: "Tasks",  icon: <SolutionOutlined />, href: "/home/tasks", tooltip: "Tasks" },
    { title: "Workers ", icon: <TeamOutlined />, href: "/home/workers", tooltip: "Workers" },
    { title: "Time Sheet ", icon: <HistoryOutlined />, href: "/home/timesheet", tooltip: "Time Sheet" },
    { title: "SETTINGS", isTitle: true },
    { title: "Create a store", icon: <SettingOutlined />, href: "/home/settings", tooltip: "Create a store" },
    { title: "profile", icon: <SettingOutlined />, href: "/home/profile", tooltip: "Profile" },
    { title: (
      <>
        <div>{user?.name}</div>
        <div style={{ fontSize: '0.8rem' }}>{user?.role}</div>
      </>
    ), icon: <UserOutlined />, gap: true, tooltip: "User" },
    { title: "Log out", icon: <LoginOutlined />, onClick: handleLogout, tooltip: "Log out" },
  ];

  const userMenus = [
    { title: "MARKETING", isTitle: true },
    { title: "Orders", icon: <ShoppingCartOutlined />, href: "/home/orders", tooltip: "Orders" },
    { title: "PAYMENTS", isTitle: true },
    { title: "Tasks",  icon: <CalculatorOutlined />, href: "/home/tasks", tooltip: "Tasks" },
    { title: "Time Sheet ", icon: <DollarOutlined />, href: "/home/timesheet", tooltip: "Time Sheet" },
    { title: "SYSTEM", isTitle: true },
    { title: "Settings", icon: <SettingOutlined />, href: "/home/settings", tooltip: "Settings" },
    { title: (
      <>
        <div>{user?.name}</div>
        <div style={{ fontSize: '0.8rem' }}>{user?.role}</div>
      </>
    ), icon: <UserOutlined />, gap: true, tooltip: "User" },
    { title: "Log out", icon: <LoginOutlined />, onClick: handleLogout, tooltip: "Log out" },
  ];

  const menus = {
    "Manager": adminMenus,
    "Store Owner": adminMenus,
    "Server": userMenus,
    "Super Admin": superadmin
  }[user?.role] || [];

  return (
    <div className={`sticky inset-1 ${open ? "w-60" : "w-20"} duration-300 pt-8 bg-slate-100 relative h-auto`}>
      <div className='flex justify-between items-center gap-7 '>
        <img src={open ? ins : insight} className='h-8 ml-4 ' alt='logo' />
        <div className={`${!open ? " -mr-4" : "mr-4"} w-8 h-8 bg-orange-400 rounded-xl flex items-center justify-center cursor-pointer absolute right-0`}>
          <img className={`h-4 w-4 cursor-pointer  ${!open && 'rotate-180 duration-500'}`} src={cloapsSidebar} onClick={toggleSidebar} title="Toggle Sidebar" />
        </div>
      </div>

      <Link to="/" className="block">
      </Link>
      <ul className=''>
        {menus.map((menu, index) => (
          <li key={`menu_${index}`} className={`${menu.isTitle ? "text-teccol text-10 ml-1 p-2 font-semibold" : "text-teccol text-lg flex items-center gap-x-4 cursor-pointer p-2 font-sm hover:bg-light-white rounded-md"} ${menu.gap ? "mt-9" : "mt-2"} ${!open && 'justify-center'} ${index === selectedTab ? 'bg-orange-100' : ''}`} onClick={() => setSelectedTab(index)}>
            <span className={`${index === selectedTab ? 'bg-orange-300 w-2 h-6 rounded-full' : ''}`}></span>
            {menu.href ? (
              <Link to={menu.href} className="flex items-center gap-x-4" title={menu.tooltip}>
                {menu.icon}
                <span className={`${!open && 'hidden'} origin-left duration-200 `}>{menu.title}</span>
              </Link>
            ) : (
              <div className="flex items-center gap-x-4 cursor-pointer p-2 font-sm rounded-md" onClick={menu.onClick === 'logout' ? handleLogout : menu.onClick} title={menu.tooltip}>
                {menu.icon}
                <span className={`${!open && 'hidden'} origin-left duration-200 text-gray-400`}>{menu.title}</span>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Sidebar;
