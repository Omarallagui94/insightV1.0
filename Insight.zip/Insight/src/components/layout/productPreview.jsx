import React from 'react';

const ProductPreview = ({ image, name, price, description }) => {
  return (
    <div className="w-64 m-4 rounded-lg overflow-hidden bg-white shadow-lg">
      <img src={image} alt={name} className="w-full h-40 object-cover" />
      <div className="p-4">
        <h2 className="text-lg font-semibold">{name}</h2>
        <p className="text-gray-600 mb-2">{description}</p>
        <p className="text-gray-800 font-bold">{price}</p>
      </div>
    </div>
  );
};

export default ProductPreview;
