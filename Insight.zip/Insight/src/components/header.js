import React from 'react';
import insight from '../Assets/ins.png';
import login from '../Assets/login.png';
import { HashLink as Link } from 'react-router-hash-link'; // Import HashLink

function Header() {
  return (
    <nav className="bg-transparent text-gray-400">
      <div className="container mx-auto flex items-center justify-between mt-3 py-2">
        <div className="logo  flex items-center">
          <Link smooth to="/#"> {/* Updated Link to use HashLink */}
            <img src={insight} alt="Logo" className="h-10 w-50 pl-32 pt-1" />
          </Link>
        </div>
        <div className="menu flex items-center space-x-4 gap-8 ">
          <Link smooth to="/#about" className="nav-item">About</Link> {/* Updated Link to use HashLink */}
          <Link smooth to="/#features" className="nav-item">Features</Link> {/* Updated Link to use HashLink */}
          <Link smooth to="/#pricing" className="nav-item">Pricing</Link> {/* Updated Link to use HashLink */}
          <Link smooth to="/#contacts" className="nav-item">Contacts</Link> {/* Updated Link to use HashLink */}
        </div>
        <div className="flex items-center justify-center pr-32">
          <Link to="/login" className="flex items-center px-4 py-2 bg-green-100 text-logtex text-sm font-bold rounded-md">
            Login <img src={login} alt="login" className="h-5 w-5 ml-2" />
          </Link>
        </div>
      </div>
      <hr className='opacity-55 mt-2'/>
    </nav>
  );
}

export default Header;
