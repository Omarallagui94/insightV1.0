import React, { useState, useEffect } from "react";
import axios from 'axios';
import editIcon from '../../Assets/draw.png';
import deleteIcon from '../../Assets/delete.png';

function AddCategories() {
  const [personId, setPersonId] = useState('');
  const [personName, setPersonName] = useState('');
  const [PersoneStoreId, setPersoneStoreId] = useState('');
  const [inventoryCategories, setInventoryCategories] = useState([]);
  const [newCategory, setNewCategory] = useState("");
  const [editingCategoryId, setEditingCategoryId] = useState(null);

  useEffect(() => {
    const extractPayloadData = () => {
      const token = localStorage.getItem('token');
      if (token) {
        const payload = token.split('.')[1];
        const decodedPayload = JSON.parse(atob(payload));
        return decodedPayload;
      }
      return null;
    };

    const payloadData = extractPayloadData();

    if (payloadData) {
      setPersonId(payloadData.id || '');
      setPersoneStoreId(payloadData.storeId || '');
      setPersonName(payloadData.name || '');
    }
  }, []);

  useEffect(() => {
    fetchInventoryCategories();
  }, []);

  const fetchInventoryCategories = async () => {
    try {
      const response = await axios.get('http://localhost:3001/inventory-categories');
      setInventoryCategories(response.data);
    } catch (error) {
      console.error("Error fetching inventory categories:", error);
    }
  };

  const handleAddCategory = async () => {
    if (newCategory.trim() !== "") {
      try {
        const response = await axios.post('http://localhost:3001/add-inventory-category', { name: newCategory, storeId: PersoneStoreId });
        const addedCategory = response.data;
        setInventoryCategories([...inventoryCategories, addedCategory]);
        setNewCategory("");
      } catch (error) {
        console.error("Error adding inventory category:", error);
      }
    }
  };

  const handleDeleteCategory = async (id, index) => {
    try {
      await axios.delete(`http://localhost:3001/delete-inventory-category/${id}`);
      const updatedCategories = [...inventoryCategories];
      updatedCategories.splice(index, 1);
      setInventoryCategories(updatedCategories);
    } catch (error) {
      console.error("Error deleting inventory category:", error);
    }
  };

  const handleEditCategory = (index) => {
    setNewCategory(inventoryCategories[index].name);
    setEditingCategoryId(index);
  };

  const handleUpdateCategory = async (id, index) => {
    if (newCategory.trim() !== "") {
      try {
        const response = await axios.put(`http://localhost:3001/update-inventory-category/${id}`, { name: newCategory });
        const updatedCategory = response.data;
        const updatedCategories = [...inventoryCategories];
        updatedCategories[index] = updatedCategory;
        setInventoryCategories(updatedCategories);
        setNewCategory("");
        setEditingCategoryId(null);
      } catch (error) {
        console.error("Error updating inventory category:", error);
      }
    }
  };

  return (
    <div className="flex justify-center items-center pl-96 mt-16">
      <div>
        <h1 className="text-3xl mb-4 text-center font-bold">Manage Inventory Categories</h1>
        <div>
          <table className="table-auto w-full border border-gray-300 shadow-sm rounded mb-16">
            <thead>
              <tr className="bg-gray-200">
                <th className="px-4 py-2 border border-gray-300">Categories</th>
                <th className="px-4 py-2 border border-gray-300">Options</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <input
                    type="text"
                    className="border p-2"
                    placeholder="Add New Category"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                  />
                </td>
                <td>
                  <button
                    className="bg-green-500 text-white py-2 px-4 rounded"
                    onClick={editingCategoryId !== null ? () => handleUpdateCategory(inventoryCategories[editingCategoryId]._id, editingCategoryId) : handleAddCategory}
                  >
                    {editingCategoryId !== null ? 'Update' : 'Add'}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="">
            <div className="overflow-x-auto">
              <table className="w-full table-auto border border-gray-300">
                <thead>
                  <tr className="bg-gray-200">
                    <th className="px-4 py-2 border border-gray-300">Category Name</th>
                    <th className="px-4 py-2 border border-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {inventoryCategories
                  .filter(category =>category.storeId ===PersoneStoreId)
                  .map((category, index) => (
                    <tr key={category._id} className={index % 2 === 0 ? 'bg-gray-100' : 'bg-gray-200'}>
                      <td className="px-4 py-2 border border-gray-300">{category.name}</td>
                      <td className="px-4 py-2 border border-gray-300">
                        <button
                          className="py-1 px-2 rounded-full mr-2"
                          onClick={() => handleEditCategory(index)}
                        >
                          <img className="w-3 h-3" src={editIcon} alt="Edit Icon" />
                        </button>
                        <button
                          className="py-1 px-2 rounded"
                          onClick={() => handleDeleteCategory(category._id, index)}
                        >
                          <img className="w-3 h-3" src={deleteIcon} alt="Delete Icon" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddCategories;
