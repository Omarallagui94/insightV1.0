import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom'; // Import useLocation
import { jwtDecode } from 'jwt-decode'; // Correct import statement for jwtDecode

const CurrentRole = () => {
  const [userRole, setUserRole] = useState(null);
  const location = useLocation(); // Define useLocation hook

  useEffect(() => {
    // Access the token from location state
    const token = location?.state?.token;

    // Decode the token to extract user information
    if (token) {
      const decodedToken = jwtDecode(token);
      setUserRole(decodedToken.role);
    }
  }, [location]);

  return (
    <div>
      {userRole && (
        <p>User's role: {userRole}</p>
      )}
    </div>
  );
}

export default CurrentRole;
