import React, { useState, useEffect } from 'react';

const LowStockPopup = ({ lowStockItems, onClose }) => {
  const [stockToOrder, setStockToOrder] = useState({});
  const [personId, setPersonId] = useState('');
  const [personName, setPersonName] = useState('');
  const [PersoneStoreId, setPersoneStoreId] = useState('');

const extractPayloadData = () => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      return decodedPayload;
    }
    return null;
  };

  const payloadData = extractPayloadData();

  useEffect(() => {
    if (payloadData) {
      setPersonId(payloadData.id || '');
      setPersoneStoreId(payloadData.storeId || '');
      setPersonName(payloadData.name || '');
    }
  }, [payloadData]);

  useEffect(() => {
    const initialStockToOrder = {};
    lowStockItems.forEach(item => {
      initialStockToOrder[item.name] = item.minimumQuantity - item.qty;
    });
    setStockToOrder(initialStockToOrder);
  }, [lowStockItems]);

  const handleStockChange = (item, value) => {
    setStockToOrder({ ...stockToOrder, [item.name]: value });
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-8 rounded-lg shadow-lg">
        <span className="absolute top-2 right-2 text-gray-600 cursor-pointer" onClick={onClose}>
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
          </svg>
        </span>
        <h2 className="text-xl font-bold mb-4">Low Stock Items</h2>
        <div className="bg-gray-100 p-1 rounded-md mb-2 flex items-center ">
          <span className="block p-2 font-bold  ">Product Name </span>
          <span className="block p-2 font-bold mr-5 ">Current Stock </span>
          <span className="block p-2 font-bold ">Minimum Stock </span>
          <span className="block p-2 font-bold ">Stock to Order</span>
        </div>
        {lowStockItems
        .filter(lowStockItem=>lowStockItem.storeId===PersoneStoreId)
        .map((item, index) => (
          <div key={index} className={`bg-gray-200 p-4 rounded-md mb-2 flex items-center w-full`}>
            <div className="w-36 px-4  flex ">
              {item.name}
            </div>
            <div className="w-36 px-4  flex ">
              {item.qty}
            </div>
            <div className="w-36 px-4  flex ">
              {item.minimumQuantity}
            </div>

            <div className="flex justify-center items-center">
              <button
                className="hover:bg-gray-300 bg-gray-100 text-gray-700 px-2 rounded-full"
                onClick={() => handleStockChange(item, (stockToOrder[item.name] || 0) - 1)}
              >
                -
              </button>
              <input
                type="text"
                value={stockToOrder[item.name] || 0}
                onChange={(e) => handleStockChange(item, parseInt(e.target.value))}
                className="text-center w-6 border border-gray-300 ml-2 mr-2"
              />
              <button
                className="hover:bg-gray-300 bg-gray-100 text-gray-700 px-2 rounded-full"
                onClick={() => handleStockChange(item, (stockToOrder[item.name] || 0) + 1)}
              >
                +
              </button>
            </div>
          </div>
        ))}
        <div className="flex justify-end mt-4">
          <button className="bg-green-600 py-3 px-6 rounded-lg text-white mr-4">Add other items</button>
          <button className="bg-green-600 py-3 px-6 rounded-lg text-white mr-4">Place Order</button>
          <button className="bg-green-600 py-3 px-6 rounded-lg text-white" onClick={handlePrint}>Print</button>
        </div>
      </div>
    </div>
  );
};

export default LowStockPopup;
