import React, { useState, useEffect } from 'react';
import axios from 'axios';
import DatePicker from 'react-datepicker'; // Import DatePicker
import 'react-datepicker/dist/react-datepicker.css'; // Import styles for DatePicker
import user1 from "../../Assets/user1.png";
import UserCard from './usercard';
import search from "../../Assets/search3.png";
import date from "../../Assets/date.png";

const Contact = () => {
  const [phoneNumbers, setPhoneNumbers] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:3001/contacts')
      .then(response => {
        setPhoneNumbers(response.data);
      })
      .catch(error => {
        console.error('Error fetching phone numbers:', error);
      });
  }, []);
  

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const handleCheck = async (id, status) => {
    try {
      await axios.put(`http://localhost:3001/update-contact/${id}`, { status });
      setPhoneNumbers(phoneNumbers.map(contact => {
        if (contact._id === id) {
          return { ...contact, status };
        }
        return contact;
      }));
    } catch (error) {
      console.error('Error updating contact status:', error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3001/delete-contact/${id}`);
      setPhoneNumbers(phoneNumbers.filter(contact => contact._id !== id));
    } catch (error) {
      console.error('Error deleting contact:', error);
    }
  };

  const filteredContacts = phoneNumbers.filter(contact => {
    // Filter by search query
    if (searchQuery && typeof contact.PhoneNumber === 'string' && !contact.PhoneNumber.includes(searchQuery)) {
      return false;
    }
    // Filter by selected date
    if (selectedDate && formatDate(contact.date) !== formatDate(selectedDate)) {
      return false;
    }
    return true;
  });
  
  return (
    <div className="container mx-auto p-4 w-page1 bg-hist h-full">
      <div className="flex ml-">
        <h1 className="text-2xl font-bold mb-4 mt-6 mr-11 ml-4">Contacts</h1>
        <div className="w-page1 h-20 relative mt-1">
          <input
            type="text"
            placeholder="Search by phone number"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 border border-gray-300 p-1 w-64 h-9 rounded-lg m-4 ml-6 focus:outline-none focus:border-ord"
          />
          <div className="absolute left-9 top-1/2 transform pb-3 -translate-y-1/2">
            <img src={search} alt="Search" className="w-5 h-5" />
          </div>
        </div>
        <div className="m-5">
          <DatePicker
            selected={selectedDate}
            onChange={date => setSelectedDate(date)}
            dateFormat="yyyy-MM-dd"
            isClearable
            placeholderText="Select date"
            className="border border-gray-300 p-1 rounded-lg focus:outline-none focus:border-ord"
          />
        </div>
        <UserCard />
      </div>
      <div className="px-3 pt-5">
        <div className="bg-white p-1 rounded-md mb-2 flex items-center w-full">
          <span className="block p-2 font-bold ml-7 mr-80">Phone Number</span>
          <span className="block p-2 font-bold mr-434">Date</span>
          <span className="block p-2 font-bold ">Status</span>
        </div>
  
        {filteredContacts.map((contact, index) => (
          <div key={index} className={`bg-white p-4 rounded-md mb-2 flex items-center w-full`}>
            <div className="w-36 px-4  flex mr-64">
              <img className="h-10 mr-4" src={user1} alt="User" />
              <div className="mt-2">{contact.PhoneNumber}</div>
            </div>
            <div className="w-1/4 px-10 py-2 mr-36 "> 
            <div className='bg-gray-100 rounded-xl w-28 flex text-sm text-gray-500 py-1'>
              <img className='h-4 mr-2  ml-2' src={date}/>
            {formatDate(contact.date)}
            </div>
            </div>
            <div className="w-1/4 px-10 py-2">
              <select
                value={contact.status}
                onChange={(e) => handleCheck(contact._id, e.target.value)}
                className="border border-gray-300 bg-gray-100 rounded-md ml-10 p-1 w-24"
              >
                <option value="waiting">Waiting</option>
                <option value="New">New</option>
                <option value="Call Again">Call Again</option>
                <option value="confirmed">Confirmed</option>
                <option value="Remind Customer">Remind Customer</option>
                <option value="Canceled">Canceled</option>
              </select>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Contact;
