import React, { useState, useEffect } from 'react';
import user1 from "../../Assets/user1.png";

const Welcome = () => {
  const [personId, setPersonId] = useState('');
  const [personName, setPersonName] = useState('');
  const [personRole, setPersonRole] = useState('');
  const [personImage, setPersonImage] = useState('');

  const extractPayloadData = () => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      return decodedPayload;
    }
    return null;
  };

  useEffect(() => {
    const payloadData = extractPayloadData();
    if (payloadData) {
      setPersonId(payloadData.id || '');
      setPersonName(payloadData.name || '');
      setPersonRole(payloadData.role || '');
      setPersonImage(payloadData.photo || '');
    }
  }, []);

  const displayImage = personImage ? personImage : user1;

  return (
      <div className="flex flex-col items-center justify-center h-full  w-page1  bg-hist">
        <h1 className="text-4xl -mt-85 mb-14 ">Welcome  back!</h1>
      <div className="text-center mb-8 ">
        <div className="flex items-center justify-center">
        <div className='flex-col'>
          <img className="w-60 rounded-full ml-2" src={displayImage} alt="profile photo" />
        <div className="text-gray-800 text-4xl ">{personName}</div>
          <div className=" text-gray-500 text-xl mt-2">{personRole}</div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default Welcome;
