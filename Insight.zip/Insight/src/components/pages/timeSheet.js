import React, { useState, useEffect } from 'react';
import axios from 'axios';
import clock from "../../Assets/clock.png";
import arrow from "../../Assets/arrow.png";
import search from "../../Assets/search3.png";
import arrowdown from "../../Assets/arrow down.png";
import UserCard from './usercard';

const TimeSheet = () => {
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [userHistory, setUserHistory] = useState([]);
  const [durationSortOrder, setDurationSortOrder] = useState('default');
  const [dateSortOrder, setDateSortOrder] = useState('default');
  const [personName, setPersonName] = useState('');
  const [personRole, setPersonRole] = useState('');
  const [expandedUserIndex, setExpandedUserIndex] = useState(null);
  const [selectedDate, setSelectedDate] = useState('');

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      const extractPayloadData = () => {
        const payload = storedToken.split('.')[1];
        const decodedPayload = JSON.parse(atob(payload));
        return decodedPayload;
      };

      const payloadData = extractPayloadData();
      setLoggedInUser(payloadData);
      setPersonName(payloadData.name || '');
      setPersonRole(payloadData.role || '');

      if (payloadData.role === 'Store Owner') {
        fetchUsersByStoreId(payloadData.storeId);
      } else {
        fetchUserHistory(payloadData.id);
      }
    }
  }, []);

  const fetchUsersByStoreId = async (storeId) => {
    try {
      const response = await axios.get(`http://localhost:3001/users/${storeId}`);
      setUserHistory(response.data.map(user => ({ name: user.name, role: user.role, history: user.history, photo:user.photo})));
    } catch (error) {
      console.error("Error fetching users by store ID:", error);
    }
  };

  const fetchUserHistory = async (userId) => {
    try {
      const response = await axios.get(`http://localhost:3001/user/${userId}`);
      setUserHistory(response.data.history);
    } catch (error) {
      console.error("Error fetching user history:", error);
    }
  };

  const formatTime = (timeString) => {
    const options = { hour: '2-digit', minute: '2-digit' };
    return new Date(timeString).toLocaleTimeString('en-GB', options);
  };

  const formatDate = (dateString) => {
    const options = { day: '2-digit', month: '2-digit' };
    return new Date(dateString).toLocaleDateString('en-GB', options);
  };

  const calculateDuration = (loginTime, logoutTime) => {
    if (loginTime && logoutTime) {
      const loginTimestamp = new Date(loginTime).getTime();
      const logoutTimestamp = new Date(logoutTime).getTime();
      const durationMilliseconds = logoutTimestamp - loginTimestamp;
      const durationSeconds = Math.floor(durationMilliseconds / 1000);
      const durationMinutes = Math.floor(durationSeconds / 60);
      const hours = Math.floor(durationMinutes / 60);
      const minutes = durationMinutes % 60;
      const seconds = durationSeconds % 60;
      return {
        hours,
        minutes,
        seconds
      };
    }
    return {
      hours: 0,
      minutes: 0,
      seconds: 0
    };
  };

  const toggleUserHistory = (index) => {
    if (expandedUserIndex === index) {
      setExpandedUserIndex(null);
    } else {
      setExpandedUserIndex(index);
    }
  };

  const sortByDuration = () => {
    if (durationSortOrder === 'default' || durationSortOrder === 'asc') {
      setUserHistory([...userHistory].sort((a, b) => {
        const durationA = calculateDuration(a.loginTime, a.logoutTime);
        const durationB = calculateDuration(b.loginTime, b.logoutTime);
        return (
          (durationB.hours - durationA.hours) * 60 +
          (durationB.minutes - durationA.minutes)
        );
      }));
      setDurationSortOrder('desc');
    } else {
      setUserHistory([...userHistory].sort((a, b) => new Date(a.loginTime) - new Date(b.loginTime)));
      setDurationSortOrder('default');
    }
    setDateSortOrder('default');
  };

  const sortByDate = () => {
    if (dateSortOrder === 'default') {
      setUserHistory([...userHistory].sort((a, b) => new Date(b.loginTime) - new Date(a.loginTime)));
      setDateSortOrder('desc');
    } else {
      setUserHistory([...userHistory].sort((a, b) => new Date(a.loginTime) - new Date(b.loginTime)));
      setDateSortOrder('default');
    }
    setDurationSortOrder('default');
  };

  const handleDateChange = (e) => {
    setSelectedDate(e.target.value);
    // Filter user history based on selected date
    const filteredHistory = userHistory.filter(record => formatDate(record.loginTime) === e.target.value);
    setUserHistory(filteredHistory);
  };

  return (
    <div className='container mx-auto p-4 bg-inventbar w-page h-full '>
      <div className="absolute top-0 right-0 mt-4 mr-4">
        <UserCard />
      </div>
      <h1 className="text-3xl absolute left-64 pb-16 pt-6 text-center font-bold align">Login History</h1>
      <div className=' h-20 relative mt-2 ml-64'>
        <input
          type="text"
          placeholder="Search "
          className="pl-12 border border-gray-300 p-1 w-64 h-9 rounded-lg m-4 ml-6  focus:outline-none focus:border-ord"
        />
        <div className="absolute left-9 top-1/2 transform pb-3 -translate-y-1/2">
          <img
            src={search}
            alt="Search"
            className="w-5 h-5  "
          />
        </div>
        <label className='text-gray-600'>Filter by Date:</label>
        <input
          type="date"
          value={selectedDate}
          onChange={handleDateChange}
          className="border border-gray-300 p-1 rounded-lg m-2 focus:outline-none focus:border-ord"
        />
      </div>
      <div className='ml-64 mt-4'>
      </div>
      
      {loggedInUser && personRole === 'Store Owner' && (
  <div className=" mt-28">
    <div className="">
      <div className="bg-white p-1 rounded-md mb-2 flex items-center w-full ">
        <span className='w-1/2 block p-2 font-bold'>Name</span>
        <span className='w-1/2 block p-2 font-bold'>Role</span>
      </div>
      {userHistory.map((record, index) => (
        <li key={index} className={'bg-white p-2 rounded-md mb-2 w-full list-none' }>
          <div className='flex items-center'>
            <span className='w-full p-2'>{record.name}</span>
            <span className='w-full p-2'>{record.role}</span>
            <span onClick={() => toggleUserHistory(index)} className='cursor-pointer'><img className='w-3 ml-2 mr-4' src={arrowdown} /></span>

          </div>
          {expandedUserIndex === index && (
            <div className="flex flex-col w-full">
              <div className='flex pb-4'>
                <div className='bg-white p-4 rounded-md mb-2 flex items-center '>
                  <span className='mr-28 font-bold' >Name </span>
                  <span className='mr-28 font-bold' >Login Time</span>
                  <span className='flex cursor-pointer font-bold ml-36'  onClick={sortByDuration}>
                    Duration <img src={arrow} className="ml-3 w-5 mr-2" />
                  </span>
                  <span className=' font-bold ml-44 mr-24'>Logout Time</span>
                  <span className='flex cursor-pointer font-bold ml-40 ' onClick={sortByDate}>
                    Date <img src={arrow} className="ml-3 w-5"  />
                  </span>
                </div>
              </div>
              {record.history.map((item, historyIndex) => (
                <div key={historyIndex} className='bg-inventbar p-4 rounded-lg flex flex-row thisSection m-3'>
                  <span className='font-bold mr-32'>{record.name}</span>
                  <span className='text-green-500 '>{formatTime(item.loginTime)}</span>
                  <span className='ml-auto mr-auto bg-white p-1 rounded-xl  flex font-bold'>
                  <img src={clock} alt="Clock Icon" className="h-5 mr-2 mt-1" />
                    {item.logoutTime && item.logoutTime !== "Invalid Date" ? (
                      <span>
                        {calculateDuration(item.loginTime, item.logoutTime).hours > 0 ? (
                          <span>
                            <span>{calculateDuration(item.loginTime, item.logoutTime).hours} hours, </span>
                          </span>
                        ) : null}
                        <span>{calculateDuration(item.loginTime, item.logoutTime).minutes} minutes</span>
                      </span>
                    ) : "N/A"}
                  </span>
                  <span className='text-red-500 absolute right-96 mr-16  '> {item.logoutTime && item.logoutTime !== "Invalid Date" ? formatTime(item.logoutTime) : "Active"}</span>
                  <span className=' ml-auto mr-16'>      {item.logoutTime && item.logoutTime !== "Invalid Date" ? formatDate(item.logoutTime) : "N/A"}</span>
                </div>
              ))}
            </div>
          )}
        </li>
      ))}
    </div>
  </div>
)}


      {loggedInUser && personRole !== 'Store Owner' && (
        <div className="ml-52 mt-28">
          <ul className="list-disc pl-6">
            <div className='flex pb-4'>
              <div className='bg-white p-4 rounded-md mb-2 flex items-center w-5/6 '>
                <span className='mr-28 font-bold' >Name </span>
                <span className='mr-28 font-bold' >Login Time</span>
                <span className='flex cursor-pointer font-bold ml-3'  onClick={sortByDuration}>
                  Duration <img src={arrow} className="ml-3 w-5 mr-2" />
                </span>
                <span className=' font-bold ml-32 '>Logout Time</span>
                <span className='flex cursor-pointer font-bold ml-auto' onClick={sortByDate}>
                  Date <img src={arrow} className="ml-3 w-5"  />
                </span>
              </div>
            </div>
            {userHistory.map((record, index) => (
              <li key={index} className={'bg-white p-4 rounded-md mb-2 flex items-center w-5/6 asthis' }>
                <span className='mr-32 font-bold'>{personName} </span>
                <span className='text-green-500 mr-40'>  {formatTime(record.loginTime)} </span>
                <div className="flex items-center bg-slate-50 p-1 rounded-xl mr-14">
                  <img src={clock} alt="Clock Icon" className="w-4 mr-2" />
                  {calculateDuration(record.loginTime, record.logoutTime).hours > 0 ? (
                    <span>
                      <strong>{calculateDuration(record.loginTime, record.logoutTime).hours} hours, </strong>
                    </span>
                  ) : null}
                  <strong>{calculateDuration(record.loginTime, record.logoutTime).minutes} minutes</strong>
                </div>
                <span className='text-red-500 ml-20'>{record.logoutTime ? ` ${formatTime(record.logoutTime)}` : "Active"}</span>
                <span className="text-gray-600 ml-auto">{formatDate(record.loginTime)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {!loggedInUser && <p>No user logged in.</p>}
    </div>
  );
};

export default TimeSheet;
