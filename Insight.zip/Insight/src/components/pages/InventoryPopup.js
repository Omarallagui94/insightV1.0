import React from "react";

const InventoryPopup = ({ onClose, name, setName, qty, setQty, minimumQuantity, setMinimumQuantity, unit, setUnit, price, setPrice, categ, setCateg, categories, type, setType, saveInventoryItem, editingItemId }) => {
  return (
    <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-8 rounded-lg shadow-lg flex flex-col justify-start items-start">
        <span className="absolute top-2 right-2 text-gray-600 cursor-pointer" onClick={onClose}>
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
          </svg>
        </span>
        <h2 className="text-xl font-bold mb-4">{editingItemId !== null ? 'Update Item' : 'Add Item'}</h2>
        <input type="text" className="border p-2 mb-2" placeholder="Item Name" value={name} onChange={(e) => setName(e.target.value)} />
        <input type="number" className="border p-2 mb-2" placeholder="Quantity" value={qty} onChange={(e) => setQty(e.target.value)} />
        <input type="number" className="border p-2 mb-2" placeholder="Minimum Quantity" value={minimumQuantity} onChange={(e) => setMinimumQuantity(e.target.value)} />
        <select className="border p-2 mb-2" value={unit} onChange={(e) => setUnit(e.target.value)}>
          <option value="">Select Unit</option>
          <option value="kg">kg</option>
          <option value="gram">gram</option>
          <option value="liter">liter</option>
        </select>
        <input type="number" className="border p-2 mb-2" placeholder="Price" value={price} onChange={(e) => setPrice(e.target.value)} />
        <select className="border p-2 mb-2" value={categ} onChange={(e) => setCateg(e.target.value)}>
          <option value="">Select Category</option>
          {categories.map(category => (
            <option key={category._id} value={category.name}>{category.name}</option>
          ))}
        </select>
        <select className="border p-2 mb-2" value={type} onChange={(e) => setType(e.target.value)}>
          <option value="">Select Type</option>
          <option value="product">Product</option>
          <option value="consumable">Consumable</option>
        </select>
        <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={saveInventoryItem}>{editingItemId !== null ? 'Update Item' : 'Add Item'}</button>
      </div>
    </div>
  );
};

export default InventoryPopup;
