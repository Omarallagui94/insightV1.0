import React, { useState, useEffect } from 'react';
import axios from 'axios';
import bgstore from "../../Assets/storebg.png";
import search from "../../Assets/search2.png";
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import UserCard from './usercard';

const ProductDetailsPopup = ({ product, onClose, onAddToCart }) => {
  const [ingredientQuantities, setIngredientQuantities] = useState(
    product.ingredients.map(ingredient => ({
      ...ingredient,
      quantity: ingredient.quantity || 0
    }))
  );

  const handleIncreaseQuantity = (index) => {
    setIngredientQuantities(prevQuantities => {
      const newQuantities = [...prevQuantities];
      newQuantities[index].quantity += 1;
      return newQuantities;
    });
  };

  const handleDecreaseQuantity = (index) => {
    setIngredientQuantities(prevQuantities => {
      const newQuantities = [...prevQuantities];
      if (newQuantities[index].quantity > 0) {
        newQuantities[index].quantity -= 1;
      }
      return newQuantities;
    });
  };

  const handleQuantityChange = (index, event) => {
    const newQuantity = parseInt(event.target.value);
    if (!isNaN(newQuantity) && newQuantity >= 0 && newQuantity <= 5) {
      setIngredientQuantities(prevQuantities => {
        const newQuantities = [...prevQuantities];
        newQuantities[index].quantity = newQuantity;
        return newQuantities;
      });
    } else {
      // Display an alert message
      alert("Please enter a valid quantity between 0 and 5 for ingredients.");
    }
  };
  
  

  return (
    <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-8 rounded-lg max-w-md shadow-lg">
        <div className="flex items-center justify-between">
          <img className='w-32 h-32 object-contain rounded-md' src={product.imageUrl} alt={product.name} />
          <button className="text-gray-600 hover:text-gray-800" onClick={onClose}>Close</button>
        </div>
        <h2 className="text-xl font-bold mt-4">{product.name}</h2>
        <p className="text-gray-600">{product.description}</p>
        <p className="text-gray-800 mt-2">Price: DT {product.price}</p>
        <div className="mt-4">
          <h3 className="text-lg font-semibold">Ingredients:</h3>
          {ingredientQuantities.map((ingredient, index) => (
            <div key={index} className="flex items-center mt-2">
              <p className="mr-2 text-gray-600">{ingredient.name}</p>
              <div className="flex items-center border border-gray-300 rounded-md px-2 py-1">
                <button className="text-gray-600 hover:text-gray-800" onClick={() => handleDecreaseQuantity(index)}>-</button>
                <input
                  type="number"
                  className="w-16 text-center border-none focus:outline-none"
                  value={ingredient.quantity*100 } 
                  onChange={(event) => handleQuantityChange(index, event)}
                />
                <span className='-ml-6 mr-3 text-sm'> Gram</span>

                <button className="text-gray-600 hover:text-gray-800" onClick={() => handleIncreaseQuantity(index)}>+</button>
              </div>
            </div>
          ))}
        </div>
        <button className="mt-4 bg-green-500 text-white text-lg font-semibold px-4 py-2 rounded-md shadow-md hover:bg-green-600" onClick={() => onAddToCart(product._id, ingredientQuantities)}>Add To Cart</button>
      </div>
    </div>
  );
};




const Orders = () => {
  const [cartItems, setCartItems] = useState({});
  const [products, setProducts] = useState([]);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [storePhoto, setStorePhoto] = useState('');
  const [slogan, setSlogan] = useState('');
  const [storeName, setStoreName] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [personId, setPersonId] = useState('');
  const [personName, setPersonName] = useState('');
  const [PersoneStoreId, setPersoneStoreId] = useState('');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [personOrdersCount, setPersonOrdersCount] = useState(0);
  const [hoveredProductId, setHoveredProductId] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(4);
  const [carouselSettings, setCarouselSettings] = useState({
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1
  });
  const [orders, setOrders] = useState([]);
  const [paid, setPaid] = useState(false); // New state for paid
  const [orderPlaced, setOrderPlaced] = useState(false);

const toggleOrderPlaced = () => {
  setOrderPlaced(!orderPlaced);
};


  useEffect(() => {
    fetchProducts();
    fetchCategories();
    fetchStoreDetails();
    fetchOrders(); // Add this line to fetch orders when the component mounts

  }, []);

  const fetchProducts = async () => {
    try {
      const response = await axios.get('http://localhost:3001/products');
      const allProducts = response.data;
      console.log("All products:", allProducts); // Add this line to check the fetched products
    
      setProducts(allProducts);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };
  
  

  const fetchCategories = async () => {
    try {
      const response = await axios.get('http://localhost:3001/categories');
      
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };
  const fetchOrders = async () => {
    try {
      const response = await axios.get('http://localhost:3001/orders');
      setOrders(response.data); // Update the orders state with the fetched data
    } catch (error) {
      console.error('Error fetching orders:', error);
    }
  };
  const fetchStoreDetails = async () => {
    try {
      const storeId = localStorage.getItem('storeId');
      const response = await axios.get(`http://localhost:3001/stores/${storeId}`);
      const { photo, slogan, name } = response.data;
      setStorePhoto(photo);
      setSlogan(slogan);
      setStoreName(name);
    } catch (error) {
      console.error('Error fetching store details:', error);
    }
  };



  const addToCart = (id, ingredientQuantities) => {
    // Check if any ingredient quantity is less than 0 or greater than 5
    const invalidQuantity = ingredientQuantities.some(ingredient => ingredient.quantity < 0 || ingredient.quantity > 5);
  
    if (!invalidQuantity) {
      // If all ingredient quantities are valid, add the product to the cart
      setCartItems(cartItems => ({ ...cartItems, [id]: { quantity: cartItems[id]?.quantity + 1 || 1, ingredients: ingredientQuantities } }));
    } else {
      // Display an alert message if any ingredient quantity is invalid
      alert("Ingredient quantities must be between 0 and 5.");
    }
  };
  

  const removeFromCart = (id) => {
    setCartItems(cartItems => {
      const newCartItems = { ...cartItems };
      newCartItems[id].quantity = Math.max(newCartItems[id].quantity - 1, 0); // Ensure quantity doesn't go below 0
      return newCartItems;
    });
  };

  const total = Object.keys(cartItems).reduce((acc, id) => {
    const product = products.find(p => p._id === id);
    return acc + (cartItems[id].quantity * product.price);
  }, 0);

  const checkout = () => {
    const orderData = {
      person: {
        personId: personId,
        personName: personName
      },
      products: Object.keys(cartItems).map(id => ({
        productId: id,
        productName: products.find(p => p._id === id).name,
        quantity: cartItems[id].quantity,
        ingredients: cartItems[id].ingredients
      })),
      paid: paid, // Include paid in the order data
      storeId:PersoneStoreId
    };

    axios.post('http://localhost:3001/add-order', orderData)
    .then(response => {
      setOrderPlaced(true); // Set orderPlaced to true on successful checkout
      setCartItems({});
    })
    .catch(error => {
      console.error('Error adding order:', error);
    });

  };

  const handleClick = (category) => {
    setSelectedCategory(prevCategory => prevCategory === category ? '' : category);
  };

  const openProductDetails = (product) => {
    setSelectedProduct(product);
  };

  const closeProductDetails = () => {
    setSelectedProduct(null);
  };

  const extractPayloadData = () => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      return decodedPayload;
    }
    return null;
  };

  const payloadData = extractPayloadData();

  useEffect(() => {
    if (payloadData) {
      setPersonId(payloadData.id || '');
      setPersoneStoreId(payloadData.storeId || '');
      setPersonName(payloadData.name || '');
    }
  }, [payloadData]);

  const handleNextPage = () => {
    setCurrentPage(currentPage + 1);
  };

  const handlePrevPage = () => {
    setCurrentPage(currentPage - 1);
  };

  const getOrderNumber = () => {
    // If orders is not an array or is empty, return 1
    if (!Array.isArray(orders) || orders.length === 0) {
      return 1;
    }
    // Otherwise, return the total number of orders plus 1
    return orders.length + 1;
  };
  

  return (
    <div className='pl-6 pt-2 w-page1'>
      <div className="relative">
        <input
          type="text"
          placeholder="Search ..."
          className="pl-12 ml-6 py-2 w-cust h-12 bg-gray-100 rounded-md focus:outline-none focus:border-ord"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <div className="absolute left-9 top-1/2 transform -translate-y-1/2">
          <img
            src={search}
            alt="Search"
            className="w-5 h-5  "
          />
        </div>
      </div>

      <h1 className='font-medium text-gray-600 mt-3'>
        Store
        <span className="text-ord p-1"> • </span>
        <span className='text-black font-medium'>{storeName}</span>
      </h1>
      <div className='rounded-2xl mt-4 p-4 w-cust flex items-center headBar' style={{ backgroundImage: `url(${bgstore})` }}>
        {storePhoto && <img src={storePhoto} alt="Store Photo" className="w-20 h-20 object-cover rounded-full mr-4" />}
        <div className="flex-grow"> {/* To push other content to the left */}
          <div>
            <h1 className='text-2xl font-semibold text-custom-light-green'>{storeName}</h1>
            <p className='text-lg text-custom-light-green'>{slogan}</p>
          </div>
        </div>
        <div className="ml-auto flex items-end">
          <div className="text-right mr-5">
            <div className="text-center">
              <h1 className='text-ord font-bold text-2xl'>{products.filter(product=>product.storeId===PersoneStoreId).length}</h1>
              <h1 className='text-white'>Total Items</h1>
            </div>
          </div>
          <div className="text-center flex flex-col">
            <div className="mb-3 mr-4">
              <h1 className="text-white">|</h1>
            </div>
          </div>
          <div className="text-right">
            <div className="text-center">
              <h1 className='text-ord font-bold text-2xl'>{categories.filter(product=>product.storeId===PersoneStoreId).length}</h1>
              <h1 className='text-white'>Categories</h1>
            </div>
          </div>
          <div className="text-right ml-2"> {/* Adjust margin for proper alignment */}
          </div>
        </div>
        <h1 className='text-xs text-white pt-7 mt-10'>&nbsp;</h1>
      </div>

      {selectedProduct && (
        <ProductDetailsPopup
          product={selectedProduct}
          onClose={closeProductDetails}
          onAddToCart={(id, ingredientQuantities) => addToCart(id, ingredientQuantities)}
        />
      )}
      <div className='fixed p-4 right-0 top-0 bg-slate-50 h-cart w-custom'>
        <div className='flex h-20 ml-32'>
          <UserCard />
        </div>
        <div className='flex'>
          <p>Order N°{orders.filter(order=>order.storeId===PersoneStoreId).length+1}</p>
          <p className='text-gray-600 text-s text-center ml-11'>Date: {currentDate.toLocaleDateString()} {currentDate.getHours()}:{currentDate.getMinutes()} </p>
          </div>
        <div className='overflow-y-auto h-car'>
          {products.map(product => {
            if (cartItems[product._id]?.quantity > 0) {
              return (
                <div className="relative">
                  <div key={product._id} className='flex justify-between items-center border border-gray-300 bg-slate-200 pr-2 rounded-xl mb-4 overflow-y-auto'>
                    <div className='flex items-center'>
                      <img className='w-20 h-20 my-4' src={product.imageUrl} alt={product.name} />
                      <div className="ml-4 items-center">
                        <p className='text-base font-bold mr-2 text-center'>{product.name}</p>
                        <div className='flex items-center '> {/* Container for price and "DT" */}
                          <p className=' font-light text-sm  mr-1'>{product.price}</p>
                          <p className=' font-thin text-sm mr-1'>DT</p>
                        </div>
                      </div>
                      <div className='flex items-center bg-slate-50 rounded-full'>
                        <button className='bg-orange-400 w-7 rounded-full text-white text-xl ml-1' onClick={() => addToCart(product._id)}>+</button>
                        <p className='text-base font-bold pl-2 pr-2'>{cartItems[product._id].quantity}</p>
                        <button className='bg-orange-400 w-7 rounded-full text-white text-xl mr-1' onClick={() => removeFromCart(product._id)}>-</button>
                      </div>
                    </div>
                  </div>
                  <div className="absolute bottom-1 right-4">
                    <p className='text-red-500 text-sm hover:bg-red-500 hover:rounded-full hover:text-white p-2' onClick={() => removeFromCart(product._id)}>Remove</p>
                  </div>
                </div>
              );
            }
          })}
        </div>

        <div>
          <div className='  p-4 rounded-3xl'>
            <div className="flex justify-between items-center mb-2">
              <label className='font-bold pl-0'>Paid:</label>
              <input
                type="checkbox"
                id="paid"
                checked={paid}
                onChange={(e) => setPaid(e.target.checked)}
                className="form-checkbox h-5 w-5 text-ord"
              />
            </div>
            <p className='font-bold pl-0'>Subtotal: <span className="float-right">{total.toFixed(2)} DT</span></p>
            <p className='font-bold mb-2 text-red-400'>Tax (10%): <span className="float-right">{(total * 0.1).toFixed(2)} DT</span></p>
            <hr className="my-4 border border-dashed border-black" />
            <p className='text-xl font-light '>Total: <span className="float-right text-ord font-normal">{(total * 1.1).toFixed(2)} DT</span></p>

          </div>
          <button className='bg-chekou text-white  font-light m-4 py-2 rounded mt-4 h-11 w-72 hover:bg-green-600' onClick={checkout}>Checkout</button>
          {orderPlaced && (
    <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50 z-2">
      <div className="bg-white p-8 rounded-lg max-w-md shadow-lg">
      <p className="text-green-500">Order placed successfully!</p>
      <button className="mt-4 bg-green-500 text-white text-lg font-semibold px-4 py-2 rounded-md shadow-md hover:bg-green-600" onClick={toggleOrderPlaced}>Close</button>
    </div>
  </div>
)}
    </div>
      </div>

      {!orderPlaced && (
  <>
    <h1 className='font-semibold text-lg pl-9 pt-6 pb-4'>Category</h1>

    <div className="w-cust">
      <Slider {...carouselSettings} className=''>
        {categories
          .filter(category => category.storeId === PersoneStoreId)
          .map((category, index) => (
            <div
              key={index}
              className={`w-cat2 h-cat1 select-none cursor-pointer transition-shadow overflow-hidden rounded-custom bg-${
                selectedCategory === category ? 'ord' : 'catbg'
              } shadow-lg hover:shadow-xl mt-5 mb-5 ml-8 content-center border border-ord  flex-shrink-0`}
              title={category.name}
              onClick={() => handleClick(category)}
            >
              {products.length > 0 &&
                products
                  .find((product) => product.category === category.name) && (
                    <div className="flex flex-col items-center justify-center h-36">
                      <img
                        src={
                          products.find((product) => product.category === category.name)
                            .imageUrl
                        }
                        alt={category.name}
                        className="w-28 pt-2 " // Adjusted margin-top and margin-bottom
                      />
                      <p
                        className={`cursor-pointer font-medium text-base pb-2 ${
                          selectedCategory === category ? 'text-white' : 'text-catName'
                        }`}
                      >
                        {category.name}
                      </p>
                    </div>
                  )}
            </div>
          ))}
      </Slider>
    </div>
  </>
)}


      <h1 className='font-semibold text-lg pl-9'>Menu Items</h1>

      <div className="flex flex-wrap justify-center items-center gap-8 pr-80"> {/* Adjusted gap and padding */}
        {products
          .filter(product => selectedCategory ? product.category === selectedCategory.name : true)
          .filter(product => product.storeId === PersoneStoreId)
          .filter(product => product.name.toLowerCase().includes(searchTerm.toLowerCase()))
          .map(product => (
            <div key={product._id} className="w-52"> {/* Adjusted width to fit 4 products */}
              <div>
                <div className="h-100">
                  <img className='' src={product.imageUrl} alt={product.name} />
                </div>
                <div
                  className={`w-52 ${selectedProduct && selectedProduct._id === product._id ? 'bg-ord' : 'bg-slate-50'} rounded-custom hover:bg-ord overflow-hidden shadow-md`}
                  onMouseEnter={() => setHoveredProductId(product._id)}
                  onMouseLeave={() => setHoveredProductId(null)}
                  onClick={() => setSelectedProduct(product)}
                  style={{
                    backgroundColor: (hoveredProductId === product._id || (selectedProduct && selectedProduct._id === product._id)) ? '#ORD' : '#slate-50',
                    color: (hoveredProductId === product._id || (selectedProduct && selectedProduct._id === product._id)) ? '#fff' : '#000'
                  }} // Adjust hover and selection colors here
                >
                  <div className="p-4 mt-6 flex flex-col">
                    <p className={`text-gray-800 font-semibold text-center mt-12 text-lg ${hoveredProductId === product._id || (selectedProduct && selectedProduct._id === product._id) ? 'text-white' : ''}`}>{product.name}</p>
                    <hr className="my-3 border-gray-300" />
                    <p className={`content-center font-medium text-center overflow-hidden overflow-ellipsis h-20 ${hoveredProductId === product._id || (selectedProduct && selectedProduct._id === product._id) ? 'text-white' : 'text-black'}`}>{product.description}</p>
                    <hr className="my-2 border-gray-300" />
                    <div className="flex justify-between items-center">
                      <div className={`flex-grow text-${hoveredProductId === product._id || (selectedProduct && selectedProduct._id === product._id) ? 'white' : 'black'} font-bold text-center`}>{product.price} DT</div>
                      <button className={`px-4 py-2 mr-3 bg-ord text-white text-lg font-semibold rounded-lg`}>+</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};

export default Orders;
