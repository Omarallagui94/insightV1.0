import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Settings = () => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [token, setToken] = useState('');

  useEffect(() => {
    // Retrieve token from local storage
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
    }
  }, []);

  // Extract payload data from the token
  const extractPayloadData = () => {
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload)); // Decode base64-encoded payload
      return decodedPayload;
    }
    return null;
  };

  // Get payload data
  const payloadData = extractPayloadData();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (name.trim() !== "" && description.trim() !== "" && location.trim() !== "") {
      try {
        // Create the new store
        const newStore = {
          name,
          description,
          location,
          storeOwnerId: payloadData.id // Set the store owner ID to payloadData.id
        };
        const storeResponse = await axios.post('http://localhost:3001/add-store', newStore);
        console.log('Store creation response:', storeResponse.data);
        
        // Update the user's storeId with the new storeId
        const updatedUserData = {
          storeId: storeResponse.data._id // Assuming the storeId is returned in the response
        };
        const userUpdateResponse = await axios.put(`http://localhost:3001/update-user/${payloadData.id}`, updatedUserData);
        console.log('User update response:', userUpdateResponse.data);
  
        // Clear input fields after successful submission
        setName('');
        setDescription('');
        setLocation('');
        // You can add further logic such as displaying a success message or redirecting the user
      } catch (error) {
        console.error('Error creating store:', error);
        // Handle the error appropriately, such as displaying an error message to the user
      }
    }
  };
  

  return (
    <div className="max-w-md mx-auto mt-8 p-6 bg-white rounded-lg shadow-lg">
      <h2 className="text-lg font-semibold mb-4 text-gray-800">Create Store</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <input
            type="text"
            placeholder="Store Name"
            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="mb-4">
          <input
            type="text"
            placeholder="Description"
            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
        </div>
        <div className="mb-4">
          <input
            type="text"
            placeholder="Location"
            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:border-blue-500"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-700">
          Create Store
        </button>
      </form>
    </div>
  );
};

export default Settings;
