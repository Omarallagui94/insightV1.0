import React, { useState, useEffect } from "react";
import axios from 'axios';
import editIcon from '../../Assets/draw.png';
import deleteIcon from '../../Assets/delete.png';
import searchIcon from '../../Assets/search.webp';
import Categories from './categories';
import UserCard from "./usercard";

const AddProducts = () => {
  const [price, setPrice] = useState(0);
  const [qty, setQty] = useState(0);
  const [users, setUsers] = useState([]);
  const [name, setName] = useState("");
  const [sum, setSum] = useState(0);
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [editingProductIndex, setEditingProductIndex] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchItemQuery, setSearchItemQuery] = useState("");
  const [showSearchBar, setShowSearchBar] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("Add Products");
  const [categories, setCategories] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [loading, setLoading] = useState(false);
  const [url, setUrl] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [inventoryItems, setInventoryItems] = useState([]);
  const [checkedIndexes, setCheckedIndexes] = useState([]);
  const [ingredients, setIngredients] = useState([]);
  const [selectedInventoryItem, setSelectedInventoryItem] = useState("");
  const [showInventory, setShowInventory] = useState(false);
  const [showAddProductModal, setShowAddProductModal] = useState(false); // Define showAddProductModal state
  const [personId, setPersonId] = useState('');
  const [personName, setPersonName] = useState('');
  const [PersoneStoreId, setPersoneStoreId] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [deletingProductIndex, setDeletingProductIndex] = useState(null);
  

const extractPayloadData = () => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      return decodedPayload;
    }
    return null;
  };

  const payloadData = extractPayloadData();

  useEffect(() => {
    if (payloadData) {
      setPersonId(payloadData.id || '');
      setPersoneStoreId(payloadData.storeId || '');
      setPersonName(payloadData.name || '');
    }
  }, [payloadData]);

  useEffect(() => {
    fetchCategories(); // Fetch categories when the component mounts
    fetchProducts();
    fetchInventoryItems();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await axios.get('http://localhost:3001/categories');
      setCategories(response.data);
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  const fetchProducts = async () => {
    try {
      const response = await axios.get('http://localhost:3001/products');
      const allProducts = response.data;
      setUsers(allProducts);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };
  

  const fetchInventoryItems = async () => {
    try {
      const response = await axios.get('http://localhost:3001/inventory-items/consumable');
      setInventoryItems(response.data                   
    );
    } catch (error) {
      console.error("Error fetching inventory items:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (name.length === 0 || !name.match(/^[A-Za-z\s]*$/)) {
      alert("Please enter a valid product name.");
      return;
    }
    if (description.length <= 15) {
      alert("Description should be longer than 15 characters.");
      return;
    }
    if (price <= 0) {
      alert("Price should be higher than 0.");
      return;
    }
    if (ingredients.some(ingredient => ingredient.quantity < 0)) {
      alert("Ingredients quantity cannot be lower than 0.");
      return;
    }
    const newProduct = {
      name: name.charAt(0).toUpperCase() + name.slice(1),
      qty,
      price,
      sum,
      category,
      description,
      imageUrl,
      ingredients,
      storeId: PersoneStoreId // Include storeId in the newProduct object
    };
    console.log(newProduct)
    try {
      const response = await axios.post('http://localhost:3001/add-product', newProduct);
      console.log(response.data);
      setUsers([...users, newProduct]);
    } catch (error) {
      console.log(error);
    }
  
    setName("");
    setQty(0);
    setPrice(0);
    setSum(0);
    setCategory("");
    setDescription("");
    setImageUrl("");
    setIngredients([]);
  };
  

  const handlePriceChange = (e) => {
    const newPrice = parseFloat(e.target.value);
    if (newPrice <= 0 || isNaN(newPrice)) {
      // Price should be greater than 0
      // or reset price if it's NaN
      alert("Price must be greater than 0.");
      setPrice(0);
      calculateTotal(0, qty);
    } else {
      setPrice(newPrice);
      calculateTotal(newPrice, qty);
    }
  };
  
  

  const handleQuantityChange = (e) => {
    const newQuantity = parseInt(e.target.value);
    if (!isNaN(newQuantity)) {
      setQty(newQuantity);
      calculateTotal(price, newQuantity);
    }
  };

  const calculateTotal = (price, qty) => {
    const newTotal = price * qty;
    setSum(newTotal);
  };

  const handleEditProduct = (id) => {
    const productToEdit = users.find(product => product._id === id);
    if (productToEdit) {
      setName(productToEdit.name);
      setQty(productToEdit.qty);
      setPrice(productToEdit.price);
      setSum(productToEdit.sum);
      setCategory(productToEdit.category);
      setDescription(productToEdit.description);
      setEditingProductIndex(id);
      setIngredients(productToEdit.ingredients);
  
      setIsEditing(true);
      setShowAddProductModal(true);
    }
  };
  
  
  const handleShowDeleteConfirmation = (id) => {
    setDeletingProductIndex(id);
    setShowDeleteConfirmation(true);
  };
  

  const handleConfirmDelete = async () => {
    try {
      await axios.delete(`http://localhost:3001/delete-product/${deletingProductIndex}`);
      const updatedUsers = users.filter(user => user._id !== deletingProductIndex);
      setUsers(updatedUsers);
    } catch (error) {
      console.error("Error deleting product:", error);
    }
    setShowDeleteConfirmation(false);
    setDeletingProductIndex(null);
  };
  
  const handleCancelDelete = () => {
    // Reset the state
    setShowDeleteConfirmation(false);
    setDeletingProductIndex(null);
  };

  const handleCheckboxChange = (index) => {
    setCheckedIndexes(prevState => {
      if (prevState.includes(index)) {
        return prevState.filter(itemIndex => itemIndex !== index);
      } else {
        return [...prevState, index];
      }
    });
  };

  const handleQuantityInputChange = (value, index) => {
    setIngredients(prevIngredients => {
      const updatedIngredients = [...prevIngredients];
      const ingredientToUpdate = updatedIngredients[index];
      if (ingredientToUpdate) {
        ingredientToUpdate.quantity = value;
      }
      return updatedIngredients;
    });
  };

const handlePopupSubmit = () => {
  const updatedIngredients = [];
  let isValid = true;

  checkedIndexes.forEach(index => {
    const itemCheckbox = document.getElementById(`checkbox-item-${index}`);
    const itemQuantityInput = document.getElementById(`quantity-${index}`);
    if (itemCheckbox && itemCheckbox.checked && itemQuantityInput) {
      const itemName = inventoryItems.filter(inventoryItem => inventoryItem.storeId === PersoneStoreId)[index].name;
      const itemQuantity = itemQuantityInput.value.trim();

      if (itemQuantity !== "" && parseInt(itemQuantity) >= 0) {
        const itemId = inventoryItems.filter(inventoryItem => inventoryItem.storeId === PersoneStoreId)[index]._id;
        updatedIngredients.push({ name: itemName, quantity: parseInt(itemQuantity), identifier: itemId });
      } else {
        isValid = false;
      }
    }
  });

  if (isValid) {
    setIngredients(updatedIngredients); // Set the ingredients state with the new array
    setShowPopup(false);
  } else {
    alert("Ingredient quantities cannot be lower than 0.");
  }
};

  
  
  const handleIngredientSelection = (index) => {
    const selectedIngredient = inventoryItems[index];
    setIngredients(prevIngredients => [...prevIngredients, { name: selectedIngredient.name, quantity: "", identifier: selectedIngredient._id }]);
  };

  const handleRemoveIngredient = (index) => {
    setIngredients(prevIngredients => prevIngredients.filter((_, i) => i !== index));
  };

  const convertBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);

      fileReader.onload = () => {
        resolve(fileReader.result);
      };

      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };

  function uploadSingleImage(base64) {
    setLoading(true);
    axios
      .post("http://localhost:3001/uploadImage", { image: base64 })
      .then((res) => {
        setUrl(res.data);
        setImageUrl(res.data);
        alert("Image uploaded Successfully");
      })
      .then(() => setLoading(false))
      .catch(console.log);
  }

  function uploadMultipleImages(images) {
    setLoading(true);
    axios
      .post("http://localhost:3001/uploadMultipleImages", { images })
      .then((res) => {
        setUrl(res.data);
        alert("Image uploaded Successfully");
      })
      .then(() => setLoading(false))
      .catch(console.log);
  }

  const uploadImage = async (event) => {
    const file = event.target.files[0];
    const base64 = await convertBase64(file);
    uploadSingleImage(base64);
  };

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) && (category === "" || user.category === category)
    
    
  );

  const toggleAddProductModal = () => {
    // Set mode to adding
    setIsEditing(false);
    setShowAddProductModal(!showAddProductModal);
  };

  const handleShowInventory = () => {
    setShowInventory(!showInventory);
  };
  const filteredProducts = filteredUsers.filter(product => product.storeId === PersoneStoreId);


  return (
    <div className="flex justify-center items-center  mt-10 w-page1">
      <div>
      <div className="flex mb-6">
        <div className="-ml-48 mr-4 mt-2 font-bold text-2xl">Products</div>
                  <input
                    type="text"
                    className="border rounded-lg p-2"
                    placeholder="Search by Product Name"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <select className="border p-2 ml-7 rounded-lg thisSellect" value={category} onChange={(event) => setCategory(event.target.value)}>
                    <option value="">Select Category</option>
                    {categories.filter(category => category.storeId === PersoneStoreId)
                    .map((category, index) => (
                      <option key={index} value={category.name}>{category.name}</option>
                    ))}
                  </select>
                </div>
      <div className="absolute top-0 right-0 mt-4 mr-4">
        <UserCard />
      </div>
        <ProductCategoriesSidebar selectedCategory={selectedCategory} setSelectedCategory={setSelectedCategory} />
        {selectedCategory === "Add Products" ? (
          <>
            <h1 className="text-3xl mb-4 text-center font-bold">Add Products</h1>
            <div className="mb-4 flex items-center">
              <h3 className="text-xl mr-4">Products</h3>
              <img
                className="w-4 h-4 mr-2 cursor-pointer"
                src={searchIcon}
                alt="Search Icon"
                onClick={() => setShowSearchBar(!showSearchBar)}
              />
              {showSearchBar && (
                <div>
                  <input
                    type="text"
                    className="border p-2"
                    placeholder="Search by Product Name"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <select className="border p-2 thisSellect" value={category} onChange={(event) => setCategory(event.target.value)}>
                    <option value="">Select Category</option>
                    {categories.map((category, index) => (
                      <option key={index} value={category.name}>{category.name}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            <div className="grid grid-cols-3 gap-4">
  <div key="empty-card" className="border border-ord  rounded-md cursor-pointer" onClick={toggleAddProductModal}>
    <div className="bg-orange-100 w-60 h-96 flex justify-center items-center mx-6 my-5 rounded-lg">
      <div className="text-center text-orange-600">
        <h1 className="text-6xl">+</h1>
        <h1 className="text-black">Add Product</h1>
      </div>
    </div>
  </div>
  {filteredProducts.map((product) => (
  <div key={product._id} className="border border-ord hover:bg-ord hover:text-white rounded-md w-72 h-auto">
    <div className="p-4">
      {product.imageUrl && <img src={product.imageUrl} alt="Product Image" className="h-40 object-cover mb-2" />}
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-bold">{product.name}</h3>
        <div className="flex">
          <img className="w-5 h-5 mr-2 cursor-pointer" src={editIcon} alt="Edit Icon" onClick={() => handleEditProduct(product._id)} />
          <img className="w-5 h-5 cursor-pointer" src={deleteIcon} alt="Delete Icon" onClick={() => handleShowDeleteConfirmation(product._id)} />
          {showDeleteConfirmation && deletingProductIndex === product._id && (
            <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-50">
              <div className="bg-white p-8 rounded-md shadow-lg relative">
                <h1 className="text-black text-xl font-bold">Confirmation:</h1>
                <p className="text-lg mb-4 text-black">Are you sure you want to delete this item?</p>
                <div className="flex justify-end">
                  <button className="bg-red-500 text-white px-4 py-2 rounded-md mr-4" onClick={handleConfirmDelete}>Yes</button>
                  <button className="bg-gray-300 text-gray-800 px-4 py-2 rounded-md" onClick={handleCancelDelete}>No</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      <p className="mb-2"><strong>Category:</strong> {product.category}</p>
      <p className="mb-2"><strong>Description:</strong> {product.description}</p>
      <p className="mb-2"><strong>Price:</strong> {product.price} DT</p>
    </div>
  </div>
))}

</div>

          </>
        ) : (
          <Categories />
        )}
      </div>
      {showAddProductModal && (
  <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-50">
    <div className="bg-white p-8 rounded-md shadow-lg relative">
      <button
        className="absolute top-0 right-0 m-2 text-gray-600 hover:text-gray-800"
        onClick={toggleAddProductModal}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-6 w-6"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M6 18L18 6M6 6l12 12"
          />
        </svg>
      </button>
      <h2 className="text-2xl font-bold mb-4">{isEditing ? 'Edit Product' : 'Add Product'}</h2>
      <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="productName" className="block text-sm font-medium text-gray-700">
                  Product Name
                </label>
                <input
                  type="text"
                  id="productName"
                  className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Enter product name"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                />
              </div>
              <div>
                <label htmlFor="image" className="block text-sm font-medium text-gray-700">
                  Image
                </label>
                <input
                  type="file"
                  id="image"
                  className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  accept=".jpg, .jpeg, .png, .gif"
                  onChange={uploadImage}
                />
              </div>
              <div className="col-span-2">
                <label htmlFor="category" className="block text-sm font-medium text-gray-700">
                  Category
                </label>
             
<select
  id="category"
  className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
  value={category}
  onChange={(event) => setCategory(event.target.value)}
>
  <option value="">Select category</option>
  {categories
    .filter(category => category.storeId === PersoneStoreId) // Filter categories based on storeId
    .map((category, index) => (
      <option key={index} value={category.name}>{category.name}</option>
    ))}
</select>

              </div>
              <div className="col-span-2">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                  Description
                </label>
                <textarea
                  id="description"
                  className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Enter product description"
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                />
              </div>

              <div>
                <label htmlFor="price" className="block text-sm font-medium text-gray-700">
                  Price
                </label>
                <input
                  type="number"
                  id="price"
                  className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Enter price"
                  value={price}
                  onChange={handlePriceChange}
                />
              </div>
              <div className="col-span-2">
                <div>
                  <button
                    className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                    onClick={handleShowInventory}
                  >
                    Show Inventory Items
                  </button>
                  {showInventory && (
                    <div className="z-10 bg-salt-200 rounded-lg shadow w-60 h-60 overflow-auto mt-2">
                      <ul className="p-3 overflow-y-auto text-sm text-black">
                        <input
                          type="text"
                          className="border p-2 thisSearchBar"
                          placeholder="Search by Item Name"
                          value={searchItemQuery}
                          onChange={(e) => setSearchItemQuery(e.target.value)}
                        />
                        {inventoryItems
                                                .filter(inventoryItem=>inventoryItem.storeId===PersoneStoreId)

                          .map((item, index) => (
                            <li key={index}>
                              <div className="flex items-center px-2 rounded hover:bg-gray-100 ">
                                <input
                                  id={`checkbox-item-${index}`}
                                  type="checkbox"
                                  value=""
                                  className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-700 dark:focus:ring-offset-gray-700 focus:ring-2 dark:bg-gray-600 dark:border-gray-500"
                                  onChange={() => handleCheckboxChange(index)}
                                />
                                <label
                                  htmlFor={`checkbox-item-${index}`}
                                  className="w-full py-2 ms-2 text-sm font-medium text-black rounded"
                                >
                                  {item.name}
                                </label>
                                {/* Quantity Input - Conditionally rendered based on checked state */}
                                {checkedIndexes.includes(index) && (
                                  <input
                                    type="number"
                                    id={`quantity-${index}`} // Added unique identifier for quantity input
                                    className="border p-2 ml-2 w-20 text-right bg-gray-50"
                                    placeholder={` In ${item.unit}`} // Corrected placeholder
                                  />
                                )}
                              </div>
                            </li>
                          ))}
                      </ul>
                    </div>
                  )}
                  <button className="bg-orange-500 p-2 rounded-lg text-white ml-3" onClick={handlePopupSubmit}>Save Ingredients</button>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <button
                type="button"
                className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                onClick={handleSubmit}
              >
                Add Product
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const ProductCategoriesSidebar = ({ selectedCategory, setSelectedCategory }) => {
  const categories = ['Add Products', 'Add Categories'];

  const handleClick = (category) => {
    setSelectedCategory(category);
  };

  return (
    <ul className="flex justify-center mb-8">
      {categories.map((category, index) => (
        <li 
          key={index} 
          className={`cursor-pointer mr-6 ${selectedCategory === category ? 'text-blue-500 border-b-2 border-blue-500' : ''}`}
          onClick={() => handleClick(category)}
        >
          {category}
        </li>
      ))}
    </ul>
  );
};

export default AddProducts;
