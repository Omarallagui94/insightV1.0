import React, { useState, useEffect } from "react";
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import bcrypt from 'bcryptjs';
import userpic from '../../Assets/user1.png';
import sort from '../../Assets/sort.png';
import searchIcon from '../../Assets/search.webp';
import UserCard from "./usercard";

const Workers = () => {
  const location = useLocation();
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");
  const [editingUserId, setEditingUserId] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearchBar, setShowSearchBar] = useState(true);
  const [token, setToken] = useState("");
  const [storeId, setStoreId] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const [sortBy, setSortBy] = useState({ key: '', order: '' });
  const [salary, setSalary] = useState(""); // Step 1: Add a new state variable for salary
  const [deleteUserId, setDeleteUserId] = useState(""); // State to store the user ID to be deleted
  const [deleteConfirmation, setDeleteConfirmation] = useState(false); // State to track delete confirmation

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
    }

    fetchUsers();
  }, [location, searchQuery]); // Include searchQuery here

  useEffect(() => {
    const extractPayloadData = () => {
      if (token) {
        const payload = token.split('.')[1];
        const decodedPayload = JSON.parse(atob(payload));
        return decodedPayload;
      }
      return null;
    };

    const payloadData = extractPayloadData();
    setLoggedInUser(payloadData);

    if (payloadData && payloadData.storeId) {
      setStoreId(payloadData.storeId);
    }
  }, [token]);

  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:3001/users');
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const saveUser = async () => {
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = { name, email, password: hashedPassword, role, phoneNumber, storeId, salary };// Include phoneNumber in the new user object

    // Check permission for adding users based on logged-in user's role
    if (loggedInUser) {
      if (loggedInUser.role === "Super Admin") {
        // Super Admin can add any user
        try {
          const response = await axios.post('http://localhost:3001/add-user', newUser);
          const savedUser = response.data;
          setUsers([...users, savedUser]);
          // Reset form fields
          setName("");
          setPhoneNumber("");
          setEmail("");
          setPassword("");
          setRole("");
          setEditingUserId(null);
          setShowPopup(false); // Close the popup after adding user

          // Add the new worker to expenses
          await axios.post('http://localhost:3001/add-expense', {
            name: savedUser.name,
            price: savedUser.salary,
            date: new Date().toISOString().split('T')[0],
            type:"Worker",
            storeId :storeId,
          });
        } catch (error) {
          console.error("Error saving user:", error);
          // Handle the error appropriately, such as displaying a message to the user
        }
      } else if (loggedInUser.role === "Store Owner") {
        // Store Owner can add users except Super Admin
        if (role !== "Super Admin") {
          try {
            const response = await axios.post('http://localhost:3001/add-user', newUser);
            const savedUser = response.data;
            setUsers([...users, savedUser]);
            // Reset form fields
            setName("");
            setPhoneNumber("");
            setEmail("");
            setPassword("");
            setRole("");
            setEditingUserId(null);
            setShowPopup(false); // Close the popup after adding user

            // Add the new worker to expenses
            await axios.post('http://localhost:3001/add-expense', {
              name: savedUser.name,
              price: savedUser.salary,
              date: new Date().toISOString().split('T')[0],
              storeId:storeId
            });
          } catch (error) {
            console.error("Error saving user:", error);
            // Handle the error appropriately, such as displaying a message to the user
          }
        } else {
          alert("Permission denied: Store Owners cannot add Super Admins.");
        }
      } else {
        // Manager can only add servers
        if (role === "Server") {
          try {
            const response = await axios.post('http://localhost:3001/add-user', newUser);
            const savedUser = response.data;
            setUsers([...users, savedUser]);
            // Reset form fields
            setName("");
            setPhoneNumber("");
            setEmail("");
            setPassword("");
            setRole("");
            setEditingUserId(null);
            setShowPopup(false); // Close the popup after adding user

            // Add the new worker to expenses
            await axios.post('http://localhost:3001/add-expense', {
              name: savedUser.name,
              price: savedUser.salary,
              date: new Date().toISOString().split('T')[0],
              type:"Salary",
              storeId :storeId,
              // Today's date
            });
          } catch (error) {
            console.error("Error saving user:", error);
            // Handle the error appropriately, such as displaying a message to the user
          }
        } else {
          alert("Permission denied: Managers can only add servers.");
        }
      }
    }
  };
  
  const filterUsers = (users) => {
    const filteredUsers = users.filter(user =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) && user.storeId === loggedInUser.storeId
    );
    return filteredUsers;
  };

  const handleEditUser = (userId, userRole) => {
    if (!loggedInUser) return;

    // Check permission for editing users based on logged-in user's role
    if (loggedInUser.role === "Super Admin" || (loggedInUser.role === "Store Owner" && userRole !== "Super Admin")) {
      const userToEdit = users.find(user => user._id === userId);
      setName(userToEdit.name);
      setPhoneNumber(userToEdit.phoneNumber);
      setEmail(userToEdit.email);
      setRole(userToEdit.role);
      setEditingUserId(userToEdit._id); // Set the ID of the user being edited
      setShowPopup(true); // Show the popup for editing
    } else {
      alert("Permission denied: You do not have permission to edit this user.");
    }
  };

  const handleDeleteUser = async (userId, userRole) => {
    if (!loggedInUser) return;

    // Check permission for deleting users based on logged-in user's role
    if (loggedInUser.role === "Super Admin" || (loggedInUser.role === "Store Owner" && userRole !== "Super Admin")) {
      setDeleteUserId(userId); // Set the user ID to be deleted
      setDeleteConfirmation(true); // Show confirmation popup
    } else {
      alert("Permission denied: You do not have permission to delete this user.");
    }
  };

  const confirmDeleteUser = async () => {
    try {
      await axios.delete(`http://localhost:3001/delete-user/${deleteUserId}`);
      const updatedUsers = users.filter(user => user._id !== deleteUserId);
      setUsers(updatedUsers);
      setDeleteConfirmation(false); // Close the popup after deletion
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  const handleSort = (key) => {
    if (sortBy.key === key) {
      setSortBy({ key, order: sortBy.order === 'asc' ? 'desc' : 'asc' });
    } else {
      setSortBy({ key, order: 'asc' });
    }
  };

  const sortedUsers = users.slice().sort((a, b) => {
    if (sortBy.key === 'name') {
      if (sortBy.order === 'asc') {
        return a.name.localeCompare(b.name);
      } else {
        return b.name.localeCompare(a.name);
      }
    } else if (sortBy.key === 'email') {
      if (sortBy.order === 'asc') {
        return a.email.localeCompare(b.email);
      } else {
        return b.email.localeCompare(a.email);
      }
    } else if (sortBy.key === 'role') {
      // Custom sorting logic for role
      const roles = ["Super Admin", "Store Owner", "Manager", "Server"];
      const roleIndexA = roles.indexOf(a.role);
      const roleIndexB = roles.indexOf(b.role);
      if (roleIndexA !== -1 && roleIndexB !== -1) {
        return roleIndexA - roleIndexB;
      } else {
        return 0;
      }
    } else {
      return 0;
    }
  });

  return (
    <div className="flex justify-center items-center  w-page1 ">

      <div>
      <div className="flex mt-4 mr-4">
  <div className="absolute top-0 right-0 ">
    <UserCard />
  </div>
  <h1 className="text-3xl mb-4 text-center font-bold pr-6">Workers</h1>
  <div className="relative ">
    <input
      type="text"
      className="border border-gray-300 bg-white h-10 px-5 pr-10 rounded-lg text-sm focus:outline-none"
      placeholder="Search by Worker Name"
      value={searchQuery}
      onChange={(e) => setSearchQuery(e.target.value)}
    />
    <img
      className="absolute top-3 right-3 w-4 h-4 cursor-pointer"
      src={searchIcon}
      alt="Search Icon"
      onClick={() => setShowSearchBar(!showSearchBar)}
    />
  </div>
  <button className="bg-blue-700 text-white px-4 py-2 rounded mb-4 ml-96" onClick={() => setShowPopup(true)}>Add New Worker</button>
</div>

        {loggedInUser && (
          <div>
          </div>
        )}

        <div className="mb-4 flex items-center">
          <div className="flex">


            <div>
              {showPopup && (
                <div className="fixed inset-0 bg-gray-900 bg-opacity-75 flex justify-center items-center">
                  <div className="bg-white p-8 rounded shadow-lg">

                      <>
                        <h3 className="text-xl mb-2">{editingUserId ? 'Edit Worker' : 'Add New Worker'}</h3>
                        <input type="text" className="border p-2 mb-2" placeholder="Worker Name" value={name} onChange={(e) => setName(e.target.value)} />
                        <input type="text" className="border p-2 mb-2" placeholder="Worker Phone" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
                        <input type="text" className="border p-2 mb-2" placeholder="Worker Email" value={email} onChange={(e) => setEmail(e.target.value)} />
                        <input type="password" className="border p-2 mb-2" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
                        <input type="text" className="border p-2 mb-2" placeholder="Worker Salary" value={salary} onChange={(e) => setSalary(e.target.value)} /> 
                        <select className="border p-2 mb-2" value={role} onChange={(e) => setRole(e.target.value)}>
                          <option value="">Select Role</option>
                          <option value="Super Admin">Super Admin</option>
                          <option value="Store Owner">Store Owner</option>
                          <option value="Manager">Manager</option>
                          <option value="Server">Server</option>
                        </select>
                        <button className="bg-blue-700 text-white px-4 py-2 rounded" onClick={saveUser}>{editingUserId ? 'Update Worker' : 'Add Worker'}</button>
                        <button className="bg-gray-500 text-white px-4 py-2 rounded ml-2" onClick={() => { setShowPopup(false); setName(""); setEmail(""); setPassword(""); setRole(""); setEditingUserId(null); }}>Cancel</button>
                      </>
                    
                    
                    
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-cust table-auto border border-gray-300 mt-10 rounded-lg">
            <thead>
              <tr className="bg-worheader h-12">
                <th className="px-4 py-2 text-left cursor-pointer" onClick={() => handleSort('name')}>
                  <div className="flex items-center">
                   Name 
                    { <img className="ml-2 h-5" src={sort} alt="Sort Icon"/>}
                  </div>
                </th>
                <th className="px-4 py-2 text-left cursor-pointer" onClick={() => handleSort('email')}>
                  <div className="flex items-center">
                   Email 
                    {
                      <img className="ml-2 h-5" src={sort} alt="Sort Icon"/>}
</div>
</th>
<th className="px-4 py-2 text-left cursor-pointer" >
<div className="flex items-center">
Phone Number
</div>
</th>
<th className="px-4 py-2 text-left cursor-pointer" onClick={() => handleSort('role')}>
<div className="flex items-center">
Role
{

<img className="ml-2 h-5" src={sort} alt="Sort Icon"/>}
</div>
</th>
<th className="px-4 py-2 text-left"></th>
</tr>
</thead>        <tbody>
{filterUsers(sortedUsers).map(user => (
<tr key={user._id}>
<td className="px-4 py-2 flex items-center">
{user.photo ? (
<img src={user.photo} className="w-11 h-11 rounded-full mr-6" alt="User Photo" />
) : (
<img src={userpic} className="w-10 h-10 rounded-full mr-6" alt="Default User Icon" />
)}
{user.name}
</td>
<td className="px-4 py-2">{user.email}</td>
<td className="px-4 py-2">{user.phoneNumber}</td>
<td className="px-4 py-2">{user.role}</td>
<td className="px-4 py-2">
<button className="py-1 px-2 rounded text-red-500" onClick={() => handleDeleteUser(user._id, user.role)}>
Delete
</button>
<button className="py-1 px-2 rounded-full mr-2 text-purple-500" onClick={() => handleEditUser(user._id, user.role)}>
Edit
</button>
</td>
</tr>
))}

</tbody>
          </table>
        </div>

        {/* Delete confirmation popup */}
        {deleteConfirmation && (
          <div className="fixed inset-0 bg-gray-900 bg-opacity-75 flex justify-center items-center">
            <div className="bg-white p-8 rounded shadow-lg">
              <h3 className="text-xl mb-4">Confirm Delete</h3>
              <p>Are you sure you want to delete this user?</p>
              <div className="flex justify-end mt-4">
                <button className="bg-red-600 text-white px-4 py-2 rounded mr-2" onClick={confirmDeleteUser}>Delete</button>
                <button className="bg-gray-500 text-white px-4 py-2 rounded" onClick={() => setDeleteConfirmation(false)}>Cancel</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
export default Workers;
