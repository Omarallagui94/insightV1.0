import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from '../layout/sidebar';
import Dashboard from './home';
import AddProducts from './addProducts';
import Orders from './orders';
import Categories from './categories';
import Customers from './customers';
import Inventory from './inventory';
import Tasks from './tasks';
import Workers from './workers';
import Settings from './settings';
import UserProfile from './profile';
import Contact from './contact';
import TimeSheet from './timeSheet';
import UserCard from './usercard';
import Expenses from './expenses';
import Welcome from './Welcome';
import SuperAdmindashboard from './superAdmindashboard';
import AssStoreOwners from './AddStoreOwners';
import AddStoreOwners from './AddStoreOwners';

export const getRole = () => {
  return localStorage.getItem("role");
}

const LoggedInLayout = () => {
  const [userName, setUserName] = useState("");
  const [personId, setPersonId] = useState('');
  const [personName, setPersonName] = useState('');
  const [PersoneStoreId, setPersoneStoreId] = useState('');

  const extractPayloadData = () => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      return decodedPayload;
    }
    return null;
  };

  const payloadData = extractPayloadData();

  useEffect(() => {
    if (payloadData) {
      setPersonId(payloadData.id || '');
      setPersoneStoreId(payloadData.storeId || '');
      setPersonName(payloadData.name || '');
    }
  }, [payloadData]);

  const isAuthenticated = () => {
    return localStorage.getItem("token") !== null;
  }

  const AuthGuard = ({ children, allowedRoles }) => {
    const isAuth = isAuthenticated();
    const userRole = getRole();
    const isAllowed = allowedRoles.includes(userRole);

    if (isAuth && isAllowed) {
      return <>{children}</>;
    } else {
      return <Navigate to="/login" />;
    }
  };


  return (
    <div className="flex sticky">
      <Sidebar userNme={userName} />
      <div>
        <Routes>
        <Route path="superAdmindashboard" element={
            <AuthGuard allowedRoles={['Super Admin']}>
              <SuperAdmindashboard/>

            </AuthGuard>
          } />
        <Route path="addStoreOwners" element={
            <AuthGuard allowedRoles={['Super Admin']}>
              <AddStoreOwners/>

            </AuthGuard>
          } />

          <Route path="daashboard"element={
            <AuthGuard allowedRoles={['Super Admin', 'Store Owner', 'Manager','Server']}>
 <Dashboard /> 
            </AuthGuard>
          } />

          <Route path="/" element={
            <AuthGuard allowedRoles={['Super Admin','Store Owner', 'Manager','Server']}>
              {/* <Dashboard /> */}
              <Welcome/>

            </AuthGuard>
          } />
          <Route path="expenses" element={
            <AuthGuard allowedRoles={['Store Owner', 'Manager']}>
              <Expenses />
            </AuthGuard>
          } />
          <Route path="contact" element={
            <AuthGuard allowedRoles={['Super Admin','Store Owner', 'Manager']}>
              <Contact />
            </AuthGuard>
          } />
          <Route path="addProducts" element={
            <AuthGuard allowedRoles={['Store Owner', 'Manager']}>
              <AddProducts />
            </AuthGuard>
          } />
          <Route path="orders" element={
            <AuthGuard allowedRoles={['Store Owner', 'Manager','Server']}>
              <Orders />
            </AuthGuard>
          } />
          <Route path="categories" element={
            <AuthGuard allowedRoles={['Store Owner', 'Manager']}>
              <Categories />
            </AuthGuard>
          } />
          <Route path="customers" element={
            <AuthGuard allowedRoles={['Store Owner', 'Manager','Server']}>
              <Customers />
            </AuthGuard>
          } />
          <Route path="inventory" element={
            <AuthGuard allowedRoles={['Store Owner', 'Manager']}>
              <Inventory />
            </AuthGuard>
          } />
          <Route path="tasks" element={
            <AuthGuard allowedRoles={['Store Owner', 'Manager','Server']}>
              <Tasks />
            </AuthGuard>
          } />
          <Route path="profile" element={
            <AuthGuard allowedRoles={['Super Admin','Store Owner', 'Manager','Server']}>
              <UserProfile />
            </AuthGuard>
          } />
          <Route path="workers" element={
            <AuthGuard allowedRoles={['Super Admin','Store Owner', 'Manager']}>
              <Workers token={userName} />
            </AuthGuard>
          } />
          <Route path="timesheet" element={
            <AuthGuard allowedRoles={['Store Owner', 'Manager','Server']}>
              <TimeSheet token={userName} />
            </AuthGuard>
          } />
          <Route path="settings" element={
            <AuthGuard allowedRoles={['Store Owner', 'Manager']}>
              <Settings />
            </AuthGuard>
          } />
        </Routes>
      </div>
    </div>
  );
};

export default LoggedInLayout;
