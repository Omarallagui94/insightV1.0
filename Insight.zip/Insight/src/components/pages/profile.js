import React, { useState, useEffect } from 'react';
import axios from 'axios';
import bcrypt from 'bcryptjs'; // Import bcryptjs for password hashing
import assets from "../../Assets/assets.gif";
import UserCard from './usercard';
import user1 from "../../Assets/user1.png";


const UserProfile = () => {
  const [id, setId] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [storeId, setStoreId] = useState('');
  const [token, setToken] = useState('');
  const [store, setStore] = useState(null);
  const [userPhoto, setUserPhoto] = useState('');
  const [storePhoto, setStorePhoto] = useState('');
  const [storeName, setStoreName] = useState('');
  const [storeLocation, setStoreLocation] = useState('');
  const [slogan, setSlogan] = useState('');

  // Fetch token from local storage on component mount
  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
    }
  }, []);
  

  // Decode token and set user data on token change
  useEffect(() => {
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      setId(decodedPayload.id || '');
      setName(decodedPayload.name || '');
      setEmail(decodedPayload.email || '');
      setRole(decodedPayload.role || '');
      setStoreId(decodedPayload.storeId || '');
      setUserPhoto(decodedPayload.photo || ''); // Set user photo
    }
  }, [token]);

  // Fetch store data when storeId changes
  useEffect(() => {
    if (storeId) {
      axios.get(`http://localhost:3001/stores/${storeId}`)
        .then(response => {
          setStore(response.data);
          setStoreName(response.data ? response.data.name : '');
          setStoreLocation(response.data ? response.data.location : '');
          setSlogan(response.data ? response.data.slogan : '');
          setStorePhoto(response.data ? response.data.photo : '');
        })
        .catch(error => {
          console.error('Error fetching store data:', error);
        });
    }
  }, [storeId]);

  // Check if the current user is the owner of the store
  const isStoreOwner = id === (store && store.storeOwnerId);

  // Function to handle image upload for user
  const handleUserImageUpload = (imageUrl) => {
    setUserPhoto(imageUrl);
    axios.put(`http://localhost:3001/update-user/${id}`, { photo: imageUrl })
      .then(response => {
        console.log('User photo updated successfully:', response.data);
        // Additional logic after successful update
      })
      .catch(error => {
        console.error('Error updating user photo:', error);
        // Additional error handling logic
      });
  };

  // Function to handle image upload for store
  const handleStoreImageUpload = (imageUrl) => {
    if (isStoreOwner) {
      setStorePhoto(imageUrl);
    }
    axios.put(`http://localhost:3001/update-store/${storeId}`, { photo: imageUrl })
      .then(response => {
        console.log('Store photo updated successfully:', response.data);
        // Additional logic after successful update
      })
      .catch(error => {
        console.error('Error updating store photo:', error);
        // Additional error handling logic
      });
  };

  // Function to handle input change for name
  const handleNameChange = (e) => {
    setName(e.target.value);
  };

  // Function to handle input change for email
  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  // Function to handle input change for password
  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  // Function to handle input change for role
  const handleRoleChange = (e) => {
    setRole(e.target.value);
  };

  // Function to handle update for user profile
  const handleUpdateUser = async () => {
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10); // 10 is the salt rounds
    
    const updatedUserData = {
      name,
      email,
      password: hashedPassword, // Use hashed password
      role,
      storeId,
      photo: userPhoto // Include user photo in user data
    };

    axios.put(`http://localhost:3001/update-user/${id}`, updatedUserData)
      .then(response => {
        console.log('User updated successfully:', response.data);
        // You can add additional logic here, such as displaying a success message or updating state after successful update
      })
      .catch(error => {
        console.error('Error updating user:', error);
        // You can add additional error handling logic here
      });
  };

  // Function to handle update for store profile
  const handleUpdateStore = () => {
    const updatedStoreData = {
      name: storeName,
      location: storeLocation,
      photo: storePhoto, // Include store photo in store data
      slogan // Include slogan in store data
    };

    axios.put(`http://localhost:3001/update-store/${storeId}`, updatedStoreData)
      .then(response => {
        console.log('Store updated successfully:', response.data);
        // Additional logic after successful update
      })
      .catch(error => {
        console.error('Error updating store:', error);
        // Additional error handling logic
      });
  };
  const displayImage = userPhoto ? userPhoto : user1;


  return (
    <div className="">
      <div className='-mr-60'>

      </div>
      <table className="w-full">
        <tbody>
          <tr>
            <td className="pr-2 pl-18">
              {/* Store Profile */}
              {isStoreOwner && (
                <div>
                  <h2 className="text-3xl font-semibold mb-2">Store Profile</h2>
                  {storePhoto && <img src={storePhoto} alt="Store Photo" className="w-40 mb-2" />} {/* Display photo if available */}
                    <UploadImage onImageUpload={handleStoreImageUpload} />
                  <input
                    type="text"
                    placeholder="Store Name"
                    value={storeName}
                    onChange={(e) => setStoreName(e.target.value)}
                    className="w-full mt-2 p-2 border rounded"
                  />
                  <input
                    type="text"
                    placeholder="Location"
                    value={storeLocation}
                    onChange={(e) => setStoreLocation(e.target.value)}
                    className="w-full mt-2 p-2 border rounded"
                  />
                  {/* Display slogan if available */}
                  <input
                    type="text"
                    placeholder="Slogan"
                    value={slogan}
                    onChange={(e) => setSlogan(e.target.value)}
                    className="w-full mt-2 p-2 border rounded"
                  />
                  <button className='bg-purple-500 hover:bg-purple-700 mt-9 text-white font-semibold py-2 px-4 rounded' onClick={handleUpdateStore}>Update</button>
                </div>
              )}
            </td>
            <td className="p-8 pl-24">
              {/* User Profile */}
              <div>
                <div className='flex flex-row items-center  '>
                <div>
                <h2 className="text-3xl font-semibold mb-1">Your Profile</h2>
                <p className='text-gray-400 pl-1'>Manage your profile settings</p>
                <p className='text-xl font-semibold mt-16 pl-3'>Your profile photo</p>
                <div className='flex flex-col mt-6 pl-3'>
        
                <img src={displayImage} alt="User Photo" className="w-32 h-32 rounded-full mb-2 ml-4" /> {/* Display user photo */}
                <p className='text-gray-400 text-sm mt-11 pl-3'>Add your photo the recommended size is 256x256px</p>
                <div className='pl-5 mt-3'>
                <UploadImage onImageUpload={handleUserImageUpload} />
                </div>
                </div>
                </div>

                <div className='flex flex-col ml-64 pt-6 '>
  <h1 className='text-gray-400 font-semibold pl-1 mt-20'> Your name:</h1>
  <input
    type="text"
    placeholder="Name"
    value={name}
    onChange={handleNameChange}
    className=" mt-2 p-2 border rounded font-bold"
  />
  <h1 className='text-gray-400 font-semibold mt-2 pl-1'> Your e-mail</h1>
  <input
    type="email"
    placeholder="Email"
    value={email}
    onChange={handleEmailChange}
    className="mt-2 p-2 border rounded font-bold"
  />
  <h1 className='text-gray-400 font-semibold mt-2 pl-1'> Your password:</h1>
  <input
    type="password"
    placeholder="Password"
    value={password}
    onChange={handlePasswordChange}
    className=" mt-2 p-2 border rounded font-bold"
  />
  <h1 className='text-gray-400 font-semibold mt-2 pl-1'> Your role:</h1>
  <input
    type="text"
    placeholder="Role"
    value={role}
    onChange={handleRoleChange}
    readOnly
    className=" mt-2 p-2 border rounded font-bold"
  />
  <div className="mt-7 ml-14">
    <button className='bg-purple-500 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded' onClick={handleUpdateUser}>Update</button>
  </div>
</div>
<div className='fixed top-5 right-5'>
  <UserCard/>
</div>


                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

const UploadImage = ({ onImageUpload }) => {
  const [loading, setLoading] = useState(false);

  const convertBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);

      fileReader.onload = () => {
        resolve(fileReader.result);
      };

      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };

  const uploadImage = async (event) => {
    const files = event.target.files;

    if (files.length === 1) {
      const base64 = await convertBase64(files[0]);
      setLoading(true);
      axios
        .post("http://localhost:3001/uploadImage", { image: base64 })
        .then((res) => {
          onImageUpload(res.data);
          alert("Image uploaded Successfully");
        })
        .then(() => setLoading(false))
        .catch(console.log);
    }
  };

  return (
<div>
  {loading ? (
    <div className="flex items-center justify-center">
      <img src={assets} alt="loading" />
    </div>
  ) : (
    <label htmlFor="dropzone-file" className="bg-purple-500 hover:bg-purple-700 text-white font-semibold py-2 px-4 rounded inline-flex items-center">
 
      Change photo
      <input
        onChange={uploadImage}
        id="dropzone-file"
        type="file"
        className="hidden"
      />
    </label>
  )}
</div>

  );
};

export default UserProfile;
