import React from 'react'

const superAdminDash = () => {
  return (
    <div>superAdminDash</div>
  )
}

export default superAdminDash