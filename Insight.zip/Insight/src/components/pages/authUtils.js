import { jwtDecode } from 'jwt-decode';

export const getUserFromToken = (token) => {
  if (!token) return null;
  
  const decodedToken = jwtDecode(token);
  return decodedToken;
};
