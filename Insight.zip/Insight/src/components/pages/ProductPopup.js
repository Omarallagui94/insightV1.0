import React, { useState } from 'react';

const ProductPopup = ({ product, addToCart, closePopup, removeFromCart, addFromCart }) => {
    const [extraLight, setExtraLight] = useState(false);
  
    if (!product) return null;
  
    const toggleExtraLight = () => {
      setExtraLight(!extraLight);
    };
  
    return (
      <div className="fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg">
          <img className='w-40 h-40 object-contain' src={product.productImage} alt={product.productName} />
          <p>{product.productName}</p>
          <p>{product.price}</p>
          <div className="flex justify-between items-center mb-4">
            <div>
              <div>
                <button onClick={() => addFromCart(product.id)} className='border-2 drop-shadow-2xl p-2 rounded hover:bg-green-300'>+</button>
                <button onClick={() => removeFromCart(product.id)} className='border-2 drop-shadow-2xl p-2 rounded hover:bg-red-300'>-</button>
              </div>
            </div>
            <div>
              <button onClick={toggleExtraLight} className={`border-2 p-2 rounded ${extraLight ? 'bg-green-300' : 'bg-gray-300'}`}>
                {extraLight ? 'Remove Extra Light' : 'Add Extra Light'}
              </button>
            </div>
          </div>
          <div className="flex justify-between">
            <button onClick={() => addToCart(product.id)} className='border-2 drop-shadow-2xl p-2 rounded hover:bg-green-300'>Add To Cart</button>
            <button onClick={closePopup} className='border-2 drop-shadow-2xl p-2 rounded hover:bg-red-300'>Close</button>
          </div>
        </div>
      </div>
    );
  };

  export default ProductPopup;