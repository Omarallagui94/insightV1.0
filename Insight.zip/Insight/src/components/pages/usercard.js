import React, { useState, useEffect } from 'react';
import user1 from "../../Assets/user1.png";

const UserCard = () => {
  const [personId, setPersonId] = useState('');
  const [personName, setPersonName] = useState('');
  const [personRole, setPersonRole] = useState('');
  const [personImage, setPersonImage] = useState('');

  const extractPayloadData = () => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      return decodedPayload;
    }
    return null;
  };

  useEffect(() => {
    const payloadData = extractPayloadData();
    if (payloadData) {
      setPersonId(payloadData.id || '');
      setPersonName(payloadData.name || '');
      setPersonRole(payloadData.role || '');
      setPersonImage(payloadData.photo || '');
    }
  }, []);

  const displayImage = personImage ? personImage : user1;

  return (
    <div className="mb-14">
      <div className="w-42 p-4  rounded-lg  float-right flex items-center cursor-pointer transition-colors duration-300 hover:bg-slate-100"> {/* the user section */}
        <div className="font-medium text-right "> {/* Adjusted to text-right */}
          <div className='text-gray-800'>{personName}</div>
          <div className="text-sm text-gray-500">{personRole}</div>
        </div>
        <img className="w-10 h-10 rounded-full ml-2 " src={displayImage} alt="profile photo" /> {/* Kept as is */}
      </div>
    </div>
  );
};

export default UserCard;
