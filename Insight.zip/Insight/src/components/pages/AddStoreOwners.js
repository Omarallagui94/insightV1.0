import React, { useState, useEffect } from "react";
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import bcrypt from 'bcryptjs';
import userpic from '../../Assets/user1.png';
import sort from '../../Assets/sort.png';
import searchIcon from '../../Assets/search.webp';
import UserCard from "./usercard";

const AddStoreOwners = () => {
  const location = useLocation();
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");
  const [editingUserId, setEditingUserId] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearchBar, setShowSearchBar] = useState(true);
  const [token, setToken] = useState("");
  const [storeId, setStoreId] = useState("");
  const [showPopup, setShowPopup] = useState(false);
  const [sortBy, setSortBy] = useState({ key: '', order: '' });
  const [salary, setSalary] = useState("");

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
    }

    fetchUsers();
  }, [location, searchQuery]);

  useEffect(() => {
    const extractPayloadData = () => {
      if (token) {
        const payload = token.split('.')[1];
        const decodedPayload = JSON.parse(atob(payload));
        return decodedPayload;
      }
      return null;
    };

    const payloadData = extractPayloadData();
    setLoggedInUser(payloadData);

    if (payloadData && payloadData.storeId) {
      setStoreId(payloadData.storeId);
    }
  }, [token]);

  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:3001/users');
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const saveUser = async () => {
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = { name, email, password: hashedPassword, role:"Store Owner", phoneNumber,storeId:""  };

    if (loggedInUser) {
      // Check permissions for adding users based on logged-in user's role
      if (loggedInUser.role === "Super Admin" || (loggedInUser.role === "Store Owner" && role !== "Super Admin")) {
        try {
          const response = await axios.post('http://localhost:3001/add-user', newUser);
          const savedUser = response.data;
          setUsers([...users, savedUser]);
          resetFormFields();
          setShowPopup(false);

          // Add the new worker to expenses
          await axios.post('http://localhost:3001/add-expense', {
            name: savedUser.name,
            price: savedUser.salary,
            date: new Date().toISOString().split('T')[0],
            storeId,
          });
        } catch (error) {
          console.error("Error saving user:", error);
        }
      } else {
        alert("Permission denied: You do not have permission to add this user.");
      }
    }
  };

  const resetFormFields = () => {
    setName("");
    setPhoneNumber("");
    setEmail("");
    setPassword("");
    setRole("");
    setEditingUserId(null);
  };

  const handleEditUser = (userId, userRole) => {
    if (!loggedInUser) return;

    if (loggedInUser.role === "Super Admin" || (loggedInUser.role === "Store Owner" && userRole !== "Super Admin")) {
      const userToEdit = users.find(user => user._id === userId);
      setName(userToEdit.name);
      setPhoneNumber(userToEdit.phoneNumber);
      setEmail(userToEdit.email);
      setRole(userToEdit.role);
      setEditingUserId(userToEdit._id);
      setShowPopup(true);
    } else {
      alert("Permission denied: You do not have permission to edit this user.");
    }
  };

  const handleDeleteUser = async (userId, userRole) => {
    if (!loggedInUser) return;

    if (loggedInUser.role === "Super Admin" || (loggedInUser.role === "Store Owner" && userRole !== "Super Admin")) {
      try {
        await axios.delete(`http://localhost:3001/delete-user/${userId}`);
        const updatedUsers = users.filter(user => user._id !== userId);
        setUsers(updatedUsers);
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    } else {
      alert("Permission denied: You do not have permission to delete this user.");
    }
  };

  const handleSort = (key) => {
    // Your sorting logic here
  };

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) && user.role === "Store Owner"
  );

  return (
    <div className="flex justify-center items-center w-page1 h-cart bg-hist">
      <div className="absolute top-0 right-0 ">
    <UserCard />
  </div>
      <div>
        <div>
        <div className="-ml-600 mr-96">
        <h1 className="text-3xl mb-4 text-center -mt-85   font-bold pr-6">Store Owners</h1>
        </div>
        </div>
        <div className="flex  ml-32 absolute left-96  top-20">
        <div className="relative mb-4">
          <input
            type="text"
            className="border border-gray-300 bg-white h-10 px-5 pr-10 rounded-lg text-sm focus:outline-none"
            placeholder="Search by Store Owner Name"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <img
            className="absolute top-3 right-3 w-4 h-4 cursor-pointer"
            src={searchIcon}
            alt="Search Icon"
            onClick={() => setShowSearchBar(!showSearchBar)}
          />
        </div>
        <button className="bg-blue-700 text-white px-4 py-2 ml-96 h-12 rounded mb-4" onClick={() => setShowPopup(true)}>Add New Store Owner</button>
        </div>
        {showPopup && (
          <div className="fixed inset-0 bg-gray-900 bg-opacity-75 flex justify-center items-center">
            <div className="bg-white p-8 rounded shadow-lg">
              <h3 className="text-xl mb-2">{editingUserId ? 'Edit Store Owner' : 'Add New Store Owner'}</h3>
              <input type="text" className="border p-2 mb-2" placeholder="Store Owner Name" value={name} onChange={(e) => setName(e.target.value)} />
              <input type="text" className="border p-2 mb-2" placeholder="Store Owner Phone" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
              <input type="text" className="border p-2 mb-2" placeholder="Store Owner Email" value={email} onChange={(e) => setEmail(e.target.value)} />
              <input type="password" className="border p-2 mb-2" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
              <button className="bg-blue-700 text-white px-4 py-2 rounded" onClick={saveUser}>{editingUserId ? 'Update Store Owner' : 'Add Store Owner'}</button>
              <button className="bg-gray-500 text-white px-4 py-2 rounded ml-2" onClick={() => { setShowPopup(false); resetFormFields(); }}>Cancel</button>
            </div>
          </div>
        )}
        <div className="overflow-x-auto">
          <table className="w-cust table-auto border border-gray-300 mt-10 rounded-lg">
            <thead>
              <tr className="bg-worheader h-12">
                <th className="px-4 py-2 text-left cursor-pointer" onClick={() => handleSort('name')}>
                  <div className="flex items-center">
                    Name
                    <img className="ml-2 h-5" src={sort} alt="Sort Icon"/>
                  </div>
                </th>
                <th className="px-4 py-2 text-left cursor-pointer" onClick={() => handleSort('email')}>
                  <div className="flex items-center">
                    Email
                    <img className="ml-2 h-5" src={sort} alt="Sort Icon"/>
                  </div>
                </th>
                <th className="px-4 py-2 text-left cursor-pointer">
                  <div className="flex items-center">
                    Phone Number
                  </div>
                </th>
                <th className="px-4 py-2 text-left cursor-pointer" onClick={() => handleSort('role')}>
                  <div className="flex items-center">
                    Role
                    <img className="ml-2 h-5" src={sort} alt="Sort Icon"/>
                  </div>
                </th>
                <th className="px-4 py-2 text-left"></th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map(user => (
                <tr key={user._id}>
                  <td className="px-4 py-2 flex items-center">
                    {user.photo ? (
                      <img src={user.photo} className="w-11 h-11 rounded-full mr-6" alt="User Photo" />
                    ) : (
                      <img src={userpic} className="w-10 h-10 rounded-full mr-6" alt="Default User Icon" />
                    )}
                    {user.name}
                  </td>
                  <td className="px-4 py-2">{user.email}</td>
                  <td className="px-4 py-2">{user.phoneNumber}</td>
                  <td className="px-4 py-2">{user.role}</td>
                  <td className="px-4 py-2">
                    <button className="py-1 px-2 rounded text-red-500" onClick={() => handleDeleteUser(user._id, user.role)}>
                      Delete
                    </button>
                    <button className="py-1 px-2 rounded-full mr-2 text-purple-500" onClick={() => handleEditUser(user._id, user.role)}>
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default AddStoreOwners;
