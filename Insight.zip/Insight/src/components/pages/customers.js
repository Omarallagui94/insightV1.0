import React, { useState, useEffect } from 'react';
import axios from 'axios';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import search from "../../Assets/search3.png";
import arrow from '../../Assets/arrow.png';
import UserCard from './usercard';

const Customers = () => {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [productDetails, setProductDetails] = useState({});
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [sortByQty, setSortByQty] = useState(false);
  const [sortByPrice, setSortByPrice] = useState(false);
  const [sortByDate, setSortByDate] = useState(false);
  const [sortByOrdered, setSortByOrdered] = useState(false);
  const [personId, setPersonId] = useState('');
  const [personName, setPersonName] = useState('');
  const [PersoneStoreId, setPersoneStoreId] = useState('');
  const [personImage, setPersonImage] = useState('');
  const [orderCounter, setOrderCounter] = useState(1); // Counter for filtered orders


  const extractPayloadData = () => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      return decodedPayload;
    }
    return null;
  };

  const payloadData = extractPayloadData();

  useEffect(() => {
    if (payloadData) {
      setPersonId(payloadData.id || '');
      setPersoneStoreId(payloadData.storeId || '');
      setPersonName(payloadData.name || '');
    }
  }, [payloadData]);

  useEffect(() => {
    // Fetch orders from the server and update order counter
    axios.get('http://localhost:3001/orders')
      .then(response => {
        const mappedOrders = response.data.map((order, index) => ({ ...order }));

        const filteredOrders = mappedOrders.filter(order => order.storeId === PersoneStoreId);

        setOrders(mappedOrders);
        setFilteredOrders(mappedOrders);
        setOrderCounter(filteredOrders.length); // Update order counter with filtered orders
      })
      .catch(error => {
        console.error('Error fetching orders:', error);
      });
  }, []);

  useEffect(() => {
    const fetchProductDetails = async (productId) => {
      try {
        const response = await axios.get(`http://localhost:3001/product/${productId}`);
        const productDetails = response.data;
        setProductDetails(prevState => ({
          ...prevState,
          [productId]: productDetails,
        }));
      } catch (error) {
        console.error('Error fetching product details:', error);
      }
    };

    orders.forEach(order => {
      order.products.forEach(product => {
        if (!productDetails[product.productId]) {
          fetchProductDetails(product.productId);
        }
      });
    });
  }, [orders, productDetails]);

  useEffect(() => {
    if (selectedDate) {
      const filtered = orders.filter(order => {
        const orderDate = new Date(order.date);
        return (
          orderDate.getFullYear() === selectedDate.getFullYear() &&
          orderDate.getMonth() === selectedDate.getMonth() &&
          orderDate.getDate() === selectedDate.getDate()
        );
      });
      setFilteredOrders(filtered);
    } else {
      setFilteredOrders(orders);
    }
  }, [selectedDate, orders]);

  useEffect(() => {
    if (searchTerm) {
      const filteredResults = filteredOrders.filter(order =>
        order.person.personName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.products.some(product =>
          productDetails[product.productId]?.name.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
      setSearchResults(filteredResults);
    } else {
      setSearchResults(filteredOrders);
    }
  }, [searchTerm, filteredOrders, productDetails]);

  const handleSearch = event => {
    setSearchTerm(event.target.value);
  };

  const sortByQuantity = () => {
    let sortedResults = [...searchResults];
    sortedResults.sort((a, b) => {
      const qtyA = a.products.reduce((total, product) => total + product.quantity, 0);
      const qtyB = b.products.reduce((total, product) => total + product.quantity, 0);
      return sortByQty ? qtyA - qtyB : qtyB - qtyA;
    });
    setSearchResults(sortedResults);
    setSortByQty(!sortByQty);
    setSortByPrice(false);
    setSortByDate(false);
    setSortByOrdered(false);
  };

  const sortByPriceFunc = () => {
    let sortedResults = [...searchResults];
    sortedResults.sort((a, b) => {
      const priceA = a.products.reduce((total, product) => total + (product.quantity * productDetails[product.productId]?.price), 0);
      const priceB = b.products.reduce((total, product) => total + (product.quantity * productDetails[product.productId]?.price), 0);
      return sortByPrice ? priceA - priceB : priceB - priceA;
    });
    setSearchResults(sortedResults);
    setSortByPrice(!sortByPrice);
    setSortByQty(false);
    setSortByDate(false);
    setSortByOrdered(false);
  };

  const sortByDateFunc = () => {
    let sortedResults = [...searchResults];
    sortedResults.sort((a, b) => {
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      return sortByDate ? dateA - dateB : dateB - dateA;
    });
    setSearchResults(sortedResults);
    setSortByDate(!sortByDate);
    setSortByQty(false);
    setSortByPrice(false);
    setSortByOrdered(false);
  };

  const sortByOrderedBy = () => {
    let sortedResults = [...searchResults];
    sortedResults.sort((a, b) => {
      const orderedByA = a.person.personName.toLowerCase();
      const orderedByB = b.person.personName.toLowerCase();
      return sortByOrdered ? orderedByA.localeCompare(orderedByB) : orderedByB.localeCompare(orderedByA);
    });
    setSearchResults(sortedResults);
    setSortByOrdered(!sortByOrdered);
    setSortByQty(false);
    setSortByPrice(false);
    setSortByDate(false);
  };

  const formatTime = date => {
    return date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  const formatDate = date => {
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit' });
  };

  const getStatusColor = (paid) => {
    return paid ? 'bg-green-500' : 'bg-red-500';
  };

  const handleStatusChange = (order, newStatus) => {
    axios.put(`http://localhost:3001/update-order/${order._id}`, { paid: newStatus === true })
      .then(response => {
        console.log('Status updated successfully:', response.data);
        // Fetch orders again to refresh data if needed
      })
      .catch(error => {
        console.error('Error updating status:', error);
      });
  };

  return (
    <div className="container mx-auto p-4 w-page1 h-full bg-hist">
      <div className='flex'>
        <h1 className="text-2xl font-bold mb-4 mt-6 mr-11 ml-4">Orders</h1>
        <div className='w-page1 h-20 relative mt-1'>
          <input
            type="text"
            placeholder="Search "
            value={searchTerm}
            onChange={handleSearch}
            className="pl-12 border border-gray-300 p-1 w-64 h-9 rounded-lg m-4 ml-6  focus:outline-none focus:border-ord"
          />
          <div className="absolute left-9 top-1/2 transform pb-3 -translate-y-1/2">
            <img
              src={search}
              alt="Search"
              className="w-5 h-5  "
            />
          </div>
        </div>
        <div className='m-5  '>
          <DatePicker
            selected={selectedDate}
            onChange={date => setSelectedDate(date)}
            dateFormat="yyyy-MM-dd"
            isClearable
            placeholderText="Select date"
            className="border border-gray-300 p-1 rounded-lg focus:outline-none focus:border-ord"
            value=''
          />
        </div>
        <UserCard/>
      </div>
      <div className="mb-4 flex justify-between">
        <div className='mb-4 mt-6 flex absolute right-14 top-24'>
     
        </div>
      </div>
      <table className="w-full border-collapse rounded-lg border bg-white">
        <thead>
          <tr className="bg-white border-b border-gray-300">
            <th className="p-2 w-16 text-left">N°</th>
            <th className="p-2 text-left cursor-pointer flex " onClick={sortByQuantity}>
              <div className='flex items-center '>
                Qty 
                <img src={arrow} className={`h-4 ml-2 mt-1 ${sortByQty ? 'rotate-180' : ''}`} />
              </div>
            </th>
            <th className="p-2 text-left">Products</th>
            <th className="p-2 text-left cursor-pointer flex" onClick={sortByPriceFunc}>
              <div className='flex items-center '>
                Price 
                <img src={arrow} className={`h-4 ml-2 ${sortByPrice ? 'rotate-180' : ''}`} />
              </div>
            </th>
            <th className="p-2 text-left cursor-pointer " onClick={sortByOrderedBy}>
              <div className='flex items-center '>
                Ordered By 
                <img src={arrow} className={`h-4 ml-2 ${sortByOrdered ? 'rotate-180' : ''}`} />
              </div>
            </th>
            <th className="p-2 text-left cursor-pointer " onClick={sortByDateFunc}>
              <div className='flex items-center '>
                Ordered on 
                <img src={arrow} className={`h-4 ml-2  ${sortByDate ? 'rotate-180' : ''}`} />
              </div>
            </th>
            <th className="p-2 text-left">Status</th>
          </tr>
        </thead>
        <tbody>
          {searchResults.map((order, index) => (
            order.storeId === PersoneStoreId && (
              <tr key={order._id} className="border-b border-gray-300">
      <td className="p-2">{orderCounter - filteredOrders.length + index + 2}</td>
                <td className="p-2 ">
                  {order.products.map(product => (
                    <div key={product.productId} className='mb-3'>
                      {product.quantity}
                    </div>
                  ))}
                </td>
                <td className="p-2">
                  {order.products.map(product => (
                    <div key={product.productId} className="flex items-center">
                      <img src={productDetails[product.productId]?.imageUrl} alt={productDetails[product.productId]?.name} className=" w-10 h-10 mr-2" />
                      <span className='font-semibold'>{productDetails[product.productId]?.name}</span>
                    </div>
                  ))}
                </td>
                <td className="p-2">
                {order.products.reduce((total, product) => total + (product.quantity * productDetails[product.productId]?.price), 0)}  DT
                </td>
                <td className="p-2">
                  {order.person.personName}
                </td>
                <td className="p-2">
                  {formatTime(new Date(order.date))} {formatDate(new Date(order.date))}
                </td>
                <td className="p-2 flex">
                  <div className={`w-4 h-4 mt-1 mr-1 rounded-full ${getStatusColor(order.paid)} `}></div>
                  <select
                    value={order.paid ? 'paid' : 'not_paid'}
                    onChange={e => handleStatusChange(order, e.target.value === 'paid')}
                  >
                    <option value="paid">Paid</option>
                    <option value="not_paid">Not Paid</option>
                  </select>
                </td>
              </tr>
            )
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Customers;
