import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ProductCategoriesSidebar = () => {
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  
  useEffect(() => {
    axios.get('http://localhost:3001/categories')
      .then(response => {
        setCategories(response.data);
      })
      .catch(error => {
        console.error('Error fetching categories:', error);
      });
  }, []);// Empty dependency array ensures the effect runs only once after initial render

  const handleClick = (category) => {
    setSelectedCategory(category);
  };

  return (
    <ul className="flex">
      {categories.map((category, index) => (
        <li 
          key={index} 
          className={`cursor-pointer mr-4 ${selectedCategory === category ? 'text-blue-500 border-b-2 border-blue-500' : ''}`}
          onClick={() => handleClick(category)}
        >
          {category.name} {/* Assuming 'name' is the property containing category names */}
        </li>
      ))}
    </ul>
  );
};

export default ProductCategoriesSidebar;
