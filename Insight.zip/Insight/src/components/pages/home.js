import React, { useState, useEffect } from "react";
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import Chart from 'chart.js/auto';
import UserCard from "./usercard";
import userpic from '../../Assets/user.png';
import salary from "../../Assets/salary.png";
import inventory from "../../Assets/inventory.png";
import order from "../../Assets/order.png";
import net from "../../Assets/net.png";
import clock from "../../Assets/clock.png";
import superAdminDash from "./superAdminDash";

const Home = () => {
  const location = useLocation();
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [productDetails, setProductDetails] = useState({});
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");
  const [editingUserId, setEditingUserId] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearchBar, setShowSearchBar] = useState(true);
  const [token, setToken] = useState("");
  const [storeId, setStoreId] = useState("");
  const [sortBy, setSortBy] = useState({ key: '', order: '' });

  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      setToken(storedToken);
    }

    fetchUsers();
    fetchInventoryItems(); // Fetch inventory items
  }, [location, searchQuery]); // Include searchQuery here

  useEffect(() => {
    const extractPayloadData = () => {
      if (token) {
        const payload = token.split('.')[1];
        const decodedPayload = JSON.parse(atob(payload));
        return decodedPayload;
      }
      return null;
    };

    const payloadData = extractPayloadData();
    setLoggedInUser(payloadData);

    if (payloadData && payloadData.storeId) {
      setStoreId(payloadData.storeId);
    }
  }, [token]);

  useEffect(() => {
    if (!storeId) return; // Skip if storeId is not available
  
    axios.get(`http://localhost:3001/orders/store/${storeId}`)
      .then(response => {
        const mappedOrders = response.data.map((order, index) => ({ ...order, orderNumber: index + 1 }));
        setOrders(mappedOrders);
        setFilteredOrders(mappedOrders);
  
        // Call function to draw the chart after orders are fetched
        drawOrdersChart(mappedOrders);
      })
      .catch(error => {
        console.error('Error fetching orders:', error);
      });
  }, [storeId]); // Fetch orders when storeId changes
  

  useEffect(() => {
    const fetchProductDetails = async (productId) => {
      try {
        const response = await axios.get(`http://localhost:3001/product/${productId}`);
        const productDetails = response.data;
        setProductDetails(prevState => ({
          ...prevState,
          [productId]: productDetails,
        }));
      } catch (error) {
        console.error('Error fetching product details:', error);
      }
    };

    orders.forEach(order => {
      order.products.forEach(product => {
        if (!productDetails[product.productId]) {
          fetchProductDetails(product.productId);
        }
      });
    });
  }, [orders, productDetails]);

  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:3001/users');
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const fetchInventoryItems = async () => {
    try {
      const response = await axios.get('http://localhost:3001/inventory-items');
      setInventoryItems(response.data);
    } catch (error) {
      console.error("Error fetching inventory items:", error);
    }
  };

  // Calculate total salary
  const totalSalary = users
    .filter(user => user.storeId === storeId)
    .reduce((total, user) => total + (user.salary || 0), 0);

  // Calculate total value of inventory items
  const totalInventoryValue = inventoryItems
    .filter(item => item.storeId === storeId)
    .reduce((total, item) => total + (item.price * item.qty), 0);

  // Calculate total of all orders
  const totalOrdersPrice = orders
    .filter(order => order.storeId === storeId)
    .reduce((total, order) => {
      const orderPrice = order.products.reduce((orderTotal, product) => {
        return orderTotal + (product.quantity * productDetails[product.productId]?.price);
      }, 0);
      return total + orderPrice;
    }, 0);

    const drawOrdersChart = (orders) => {
      const filteredOrders = orders.filter(order => order.storeId === storeId); // Filter orders by storeId
      const orderDates = filteredOrders.map(order => new Date(order.date));
    
      // Group orders by month
      const ordersByMonth = orderDates.reduce((acc, date) => {
        const month = date.getMonth();
        const year = date.getFullYear();
        const key = `${year}-${month}`;
        acc[key] = (acc[key] || 0) + 1;
        return acc;
      }, {});
    
      const labels = Object.keys(ordersByMonth).map(key => {
        const [year, month] = key.split('-');
        return `${year}-${parseInt(month) + 1}`;
      });
    
      const data = Object.values(ordersByMonth);
    
      const ctx = document.getElementById('ordersChart');
      new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: 'Number of Orders',
            data: data,
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          },
          plugins: {
            title: {
              display: true,
              text: 'Orders Passed Each Month'
            }
          }
        }
      });
    };
    

  // Calculate duration between login and logout times
  const calculateDuration = (history) => {
    if (history.length > 0) {
      const lastHistory = history[history.length - 1]; // Get the last history entry
      const loginTime = lastHistory.loginTime;
      const logoutTime = lastHistory.logoutTime;
      if (loginTime && logoutTime) {
        const loginTimestamp = new Date(loginTime).getTime();
        const logoutTimestamp = new Date(logoutTime).getTime();
        const durationMilliseconds = logoutTimestamp - loginTimestamp;
        const durationSeconds = Math.floor(durationMilliseconds / 1000);
        const durationMinutes = Math.floor(durationSeconds / 60);
        const hours = Math.floor(durationMinutes / 60);
        const minutes = durationMinutes % 60;
        const seconds = durationSeconds % 60;
        return {
          hours,
          minutes,
          seconds
        };
      }
    }
    return {
      hours: 0,
      minutes: 0,
      seconds: 0
    };
  };

  return (
    <div className="flex justify-center items-center w-page1 h-full bg-hist">
      <div>
        <div className="flex mt-4 mr-4">
          <div className="absolute top-0 right-0">
            <UserCard />
          </div>
        </div>
      </div>
      <div className="gap-4 flex flex-wrap absolute top-4 right-56 ">
        {/* Display total salary */}
        <div className={`p-4 rounded-lg border-black flex-col mt-4 text-center text-white ${totalSalary < 0 ? 'bg-red-500' : 'bg-green-500'}`} style={{ width: '250px', justifyContent: 'center', alignItems: 'center' }}>
          <div className="font-semibold text-2xl mb-2">
           {totalSalary}  DT 
          </div>
          <div className="flex justify-center items-center font-bold">
            <img className="mr-2 w-8" src={salary} alt="salary Icon" />
            Total Salary
          </div>
        </div>

        {/* Display total inventory value */}
        <div className={`p-4 rounded-lg border-black flex-col mt-4 text-center text-white ${totalInventoryValue < 0 ? 'bg-red-500' : 'bg-green-500'}`} style={{ width: '250px', justifyContent: 'center', alignItems: 'center' }}>
          <div className="font-semibold text-2xl mb-2">
           {totalInventoryValue} DT 
          </div>
          <div className="flex justify-center items-center font-bold">
            <img className="mr-2 w-8" src={inventory} alt="inventory Icon" />
            Total Inventory Value
          </div>
        </div>

        {/* Display total order price */}
        <div className={`p-4 rounded-lg border-black flex-col mt-4 text-center text-white ${totalOrdersPrice < 0 ? 'bg-red-500' : 'bg-green-500'}`} style={{ width: '250px', justifyContent: 'center', alignItems: 'center' }}>
          <div className="font-semibold text-2xl mb-2 ">
            {totalOrdersPrice} DT 
          </div>
          <div className="flex justify-center items-center font-bold">
            <img className="mr-2 w-8" src={order} alt="order Icon" />
            Total Orders Price
          </div>
        </div>

        {/* Display net incomes */}
        <div className={`p-4 rounded-lg border-black flex-col mt-4 text-center text-white ${totalOrdersPrice - totalSalary < 0 ? 'bg-red-500' : 'bg-green-500'}`} style={{ width: '250px', justifyContent: 'center', alignItems: 'center' }}>
          <div className="font-semibold text-2xl mb-2">
          {totalOrdersPrice -  totalSalary} DT 
          </div>
          <div className="flex justify-center items-center font-bold">
            <img className="mr-2 w-8" src={net} alt="order Icon" />
            Net Incomes
          </div>
        </div>
      </div>

      {/* Chart showing number of orders passed in a day */}
      <div className="w-1/2  mb-85 flex bg-white shadow-md rounded overflow-hidden p-4"> 
        <canvas id="ordersChart"></canvas>
      </div>

{/* List of inventory items */}
<div className="-mt-96 ml-12">
  <h2 className="text-xl font-semibold mb-4">Inventory Items</h2>
  <div className="ml-12 h-80 overflow-y-auto" style={{ scrollbarWidth: 'thin', scrollbarColor: '#a5a5a5 #f4f4f4' }}>
    <div className="bg-white rounded-lg shadow-lg p-4">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {inventoryItems
            .filter(item => item.storeId === storeId)
            .sort((a, b) => a.qty - b.qty) // Sort in ascending order by quantity
            .map(item => (
              <tr key={item.id}>
                <td className="px-6 py-4 whitespace-nowrap">{item.name}</td>
                <td className="px-6 py-4 whitespace-nowrap">{item.qty} {item.unit}</td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  </div>
</div>


      {/* List of users and their stay durations */}
      <div className=" absolute bottom-36 w-4/5">
        <h2 className="text-xl font-semibold mb-4 ml-1">Users and Stay Durations</h2>
        <div className="ml-12 h-80 overflow-y-auto overflow-x-hidden">
          <div className="bg-white rounded-lg shadow-lg p-4">
          <table className="min-w-full divide-y divide-gray-200">
  <thead className="bg-gray-50">
    <tr>
      <th className="px-6 py-3 pl-20  text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
      <td className="pl-40"> </td>
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stay Duration</th>
    </tr>
  </thead>
  <tbody className="bg-white divide-y divide-gray-200">
    {/* Loop through users */}
    {users.filter(user=>user.storeId===storeId)
    .map(user => (
      <tr key={user.id}>
        <td className="px-6 py-4 pl-20 whitespace-nowrap">{user.name}</td>
        <td></td>
        <td className="px-6 py-4  whitespace-nowrap flex">
        <img src={clock} alt="Clock Icon" className="h-5 mr-2 mt-1" />

          {calculateDuration(user.history).hours > 0 ? (
            <span>
              <span>{calculateDuration(user.history).hours} hours, </span>
            </span>
          ) : null}
          <span>{calculateDuration(user.history).minutes} minutes</span>
        </td>
      </tr>
    ))}
  </tbody>
</table>

          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
