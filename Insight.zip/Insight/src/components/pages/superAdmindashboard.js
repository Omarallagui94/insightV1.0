import React, { useState, useEffect } from 'react';
import axios from 'axios';
import clock from "../../Assets/clock.png";
import arrow from "../../Assets/arrow.png";
import arrowdown from "../../Assets/arrow down.png";
import UserCard from './usercard';

const SuperAdmindashboard = () => {
    const [personId, setPersonId] = useState('');
    const [personName, setPersonName] = useState('');
    const [personRole, setPersonRole] = useState('');
    const [personImage, setPersonImage] = useState('');
    const [stores, setStores] = useState([]);
    const [users, setUsers] = useState([]);
    const [expandedStoreIndex, setExpandedStoreIndex] = useState(null);

    const extractPayloadData = () => {
        const token = localStorage.getItem('token');
        if (token) {
            const payload = token.split('.')[1];
            const decodedPayload = JSON.parse(atob(payload));
            return decodedPayload;
        }
        return null;
    };

    useEffect(() => {
        const payloadData = extractPayloadData();
        if (payloadData) {
            setPersonId(payloadData.id || '');
            setPersonName(payloadData.name || '');
            setPersonRole(payloadData.role || '');
            setPersonImage(payloadData.photo || '');
        }

        fetchStores();
        fetchUsers();
    }, []);

    const fetchStores = async () => {
        try {
            const response = await axios.get('http://localhost:3001/stores');
            setStores(response.data);
        } catch (error) {
            console.error("Error fetching stores:", error);
        }
    };

    const fetchUsers = async () => {
        try {
            const response = await axios.get('http://localhost:3001/users');
            setUsers(response.data);
        } catch (error) {
            console.error("Error fetching users:", error);
        }
    };

    const toggleExpandedStore = async (index, storeId) => {
        if (expandedStoreIndex === index) {
            setExpandedStoreIndex(null);
        } else {
            setExpandedStoreIndex(index);
        }
    };

    return (
        <div className="bg-hist w-page1 h-cart">
              <div className="absolute top-0 right-0 ">
    <UserCard />
  </div>
            <div className="">
                <div className='p-6 text-2xl font-bold'>Store List</div>
                <div className="bg-white p-1 rounded-md mb-2 flex items-center mt-20 ml-96 w-434">
                    <span className='w-1/2 block p-2 font-bold'>Store Name</span>
                    <span className='w-1/2 block p-2 font-bold'>Location</span>
                </div>
                {stores.map((store, index) => (
                    <div key={store.id} className="p-2 rounded-md mb-2 list-none cursor-pointer " onClick={() => toggleExpandedStore(index, store.id)}>
                        <div className='bg-white p-2 rounded-md mb-2 flex items-center ml-96 w-434'>
                            <span className='w-1/2  p-2 font-bold flex gap-3' >
                                <img className='w-8 rounded-full' src={store.photo} alt={store.name} />
                               <span className='mt-1'> {store.name}</span>
                            </span>
                            <span className='w-1/2 block p-2 font-bold'>{store.location}</span>
                            <span className='bg-hist rounded-2xl p-2' ><img className='w-3 my-2 mx-1' src={arrowdown}  /></span>
                        </div>
                        {expandedStoreIndex === index && (
                            <div className="flex flex-col ml-96 w-434 bg-hist">
                                <div className='flex pb-4'>
                                    <div className='bg-white p-4 rounded-md mb-2 flex items-center w-434'>
                                        <span className='mr-28 font-bold'>Name </span>
                                        <span className='mr-28 font-bold'>Phone Number</span>
                                        <span className='mr-28 font-bold'>Role</span>
                                    </div>
                                </div>
                                {users
                                    .filter(user => user.storeId === store._id)
                                    .sort((a, b) => {
                                        // Custom sorting function to sort by role
                                        const roleOrder = {
                                            'Store Owner': 0,
                                            'Manager': 1,
                                            'Server': 2
                                        };
                                        return roleOrder[a.role] - roleOrder[b.role];
                                    })
                                    .map((user, userIndex) => (
                                        <div key={user.id} className='bg-slate-100 p-4 rounded-lg flex flex-row thisSection m-3 w-434'>
                                            <span className='font-bold mr-32'>{user.name}</span>
                                            <span className='font-bold mr-32'>{user.phoneNumber}</span>
                                            <span className='text-green-500 mr-4  absolute right-488 '>{user.role}</span>
                                        </div>
                                    ))}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
}

export default SuperAdmindashboard;
