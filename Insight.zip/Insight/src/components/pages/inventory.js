import React, { useState, useEffect } from "react";
import axios from 'axios';
import editIcon from '../../Assets/draw.png';
import deleteIcon from '../../Assets/delete.png';
import searchIcon from '../../Assets/search.webp';
import AddCategories from './addCategories';
import sto from "../../Assets/sto.png";
import arrowdown from "../../Assets/arrow down.png";
import LowStockPopup from "./LowStockPopup"; // Import the LowStockPopup component
import UserCard from "./usercard";

function Inventory() {
  const [inventoryItems, setInventoryItems] = useState([]);
  const [name, setName] = useState("");
  const [qty, setQty] = useState("");
  const [unit, setUnit] = useState("");
  const [categ, setCateg] = useState("");
  const [price, setPrice] = useState("");
  const [minimumQuantity, setMinimumQuantity] = useState(""); // Added
  const [type, setType] = useState(""); // Added
  const [editingItemId, setEditingItemId] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearchBar, setShowSearchBar] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("Add Inventory Items");
  const [categories, setCategories] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [popupItem, setPopupItem] = useState(null);
  const [lowStockItems, setLowStockItems] = useState([]); // New state for low stock items
  const [showLowStockPopup, setShowLowStockPopup] = useState(false); // State to control visibility of low stock popup
  const [showManageStockButtonIndex, setShowManageStockButtonIndex] = useState(null);
  const [showSortDropdown, setShowSortDropdown] = useState(false); // Added for sorting dropdown
  const [selectedItemIndex, setSelectedItemIndex] = useState(null);
  const [sortByQuantity, setSortByQuantity] = useState(""); // Added for sorting by quantity
  const [showAddItemPopup, setShowAddItemPopup] = useState(false);

  const [personId, setPersonId] = useState('');
  const [personName, setPersonName] = useState('');
  const [PersoneStoreId, setPersoneStoreId] = useState('');

const extractPayloadData = () => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      return decodedPayload;
    }
    return null;
  };

  const payloadData = extractPayloadData();

  useEffect(() => {
    if (payloadData) {
      setPersonId(payloadData.id || '');
      setPersoneStoreId(payloadData.storeId || '');
      setPersonName(payloadData.name || '');
    }
  }, [payloadData]);
  useEffect(() => {
    fetchInventoryItems();
    fetchCategories();
  }, []);

  // Fetch categories from the server
  const fetchCategories = async () => {
    try {
      const response = await axios.get('http://localhost:3001/inventory-categories');
      setCategories(response.data);
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  // Fetch inventory items from the server
  const fetchInventoryItems = async () => {
    try {
      const response = await axios.get('http://localhost:3001/inventory-items');
      setInventoryItems(response.data);
    } catch (error) {
      console.error("Error fetching inventory items:", error);
    }
  };

  // Save or update an inventory item
// Save or update an inventory item
const saveInventoryItem = async () => {
  const newInventoryItem = { name, qty, unit, categ, price, minimumQuantity, type, storeId: PersoneStoreId }; // Add storeId here

  try {
    if (editingItemId !== null) {
      // Update existing inventory item
      await axios.put(`http://localhost:3001/update-inventory-item/${inventoryItems[editingItemId]._id}`, newInventoryItem);
      const updatedItems = [...inventoryItems];
      updatedItems[editingItemId] = newInventoryItem;
      setInventoryItems(updatedItems);
      setEditingItemId(null);
    } else {
      // Add new inventory item
      const response = await axios.post('http://localhost:3001/add-inventory-item', newInventoryItem);
      setInventoryItems([...inventoryItems, response.data]);

      // Save the new item in expenses
      const expenseData = {
        name: response.data.name,
        qty: parseInt(response.data.qty),
        price: response.data.price,
        date: new Date().toISOString(),
        type:"Stock item",
        storeId: PersoneStoreId,
      };
      await axios.post('http://localhost:3001/add-expense', expenseData);
    }

    // Clear input fields after saving/updating
    setName("");
    setQty("");
    setUnit("");
    setCateg("");
    setPrice("");
    setMinimumQuantity("");
    setType("");
  } catch (error) {
    console.error("Error adding/updating inventory item:", error);
  }
};


  // Handle editing an inventory item
  const handleEditInventoryItem = (index) => {
    const itemToEdit = inventoryItems[index];
    setName(itemToEdit.name);
    setQty(itemToEdit.qty);
    setUnit(itemToEdit.unit);
    setCateg(itemToEdit.categ);
    setPrice(itemToEdit.price);
    setMinimumQuantity(itemToEdit.minimumQuantity);
    setType(itemToEdit.type);
    setEditingItemId(index);
  };

  // Handle deleting an inventory item
  const handleDeleteInventoryItem = async (index) => {
    try {
      await axios.delete(`http://localhost:3001/delete-inventory-item/${inventoryItems[index]._id}`);
      const updatedItems = [...inventoryItems];
      updatedItems.splice(index, 1);
      setInventoryItems(updatedItems);
    } catch (error) {
      console.error("Error deleting inventory item:", error);
    }
  };

  // Handle changing the selected category
  const handleCategoryChange = (selectedCategory) => {
    const selectedCategoryObject = categories.find(category => category.name === selectedCategory);
    if (selectedCategoryObject) {
      setCateg(selectedCategoryObject.name);
    }
  };

  // Handle sorting inventory items by quantity
  const handleSortChange = (value) => {
    if (value === "asc") {
      setSortByQuantity("asc");
      const sortedItems = [...inventoryItems].sort((a, b) => a.qty - b.qty);
      setInventoryItems(sortedItems);
    } else if (value === "desc") {
      setSortByQuantity("desc");
      const sortedItems = [...inventoryItems].sort((a, b) => b.qty - a.qty);
      setInventoryItems(sortedItems);
    } else {
      setSortByQuantity("");
      fetchInventoryItems(); // Fetch default order from server
    }
  };

  // Filter inventory items based on search query
  const filteredInventoryItems = inventoryItems.filter(item =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) && item.storeId === PersoneStoreId
  );

  // Handle clicking on the "Manage Stock" button
  const handleStoClick = (item, index) => {
    setPopupItem(item);
    setSelectedItemIndex(index); // Pass the selected item index to the popup
    setShowPopup(true);
  };
  
  // Handle clicking on the "Manage Stock" button from the popup
  const handleStomClick = async (item) => {
    setPopupItem(item);
    setShowPopup(true);
  };

  // Handle closing the popup
  const handlePopupClose = () => {
    setShowPopup(false);
  };

  // Handle adding stock to an inventory item
  const handleAddStock = async () => {
    if (popupItem && qty !== "") {
      const updatedQty = parseInt(popupItem.qty) + parseInt(qty);
      try {
        await axios.put(`http://localhost:3001/update-inventory-item/${popupItem._id}`, { qty: updatedQty });
        const expenseData = {
          name: popupItem.name,
          qty: parseInt(qty),
          price: popupItem.price,
          date: new Date().toISOString(),
          type:"Stock item",
          storeId:PersoneStoreId,
        };
        await axios.post('http://localhost:3001/add-expense', expenseData);
        const updatedItems = [...inventoryItems];
        const index = updatedItems.findIndex(item => item._id === popupItem._id);
        if (index !== -1) {
          updatedItems[index].qty = updatedQty;
          setInventoryItems(updatedItems);
        }
        const updatedPopupItem = { ...popupItem, qty: updatedQty };
        setPopupItem(updatedPopupItem);
      } catch (error) {
        console.error("Error updating quantity:", error);
      }
      setShowPopup(false);
      setQty("");
    }
  };

  // Handle checking stock for low quantity items
  const handleCheckStock = () => {
    const lowStockItems = inventoryItems.filter(item => parseInt(item.qty) < parseInt(item.minimumQuantity));
    setLowStockItems(lowStockItems);
    setShowLowStockPopup(true);
  };

  // Handle hovering over a table row to show "Manage Stock" button
  const handleRowHover = (isHovering, index) => {
    if (isHovering) {
      setShowManageStockButtonIndex(index);
    } else {
      setShowManageStockButtonIndex(null);
    }
  };

  // Function to toggle the visibility of the Add Item popup
  const toggleAddItemPopup = () => {
    setShowAddItemPopup(!showAddItemPopup);
  };

  // Render the inventory component
  return (
    <div className="flex justify-center items-center pl-44 mt-16 w-page1">
      <div className="absolute top-0 right-0 mt-4 mr-4">
        <UserCard />
      </div>
      <div>
        <ProductCategoriesSidebar selectedCategory={selectedCategory} setSelectedCategory={setSelectedCategory} />
        {selectedCategory === "Add Inventory Items" ? (
          <>
            <h1 className="text-3xl mb-4 text-center font-bold">Inventory</h1>
            <div className="mb-4 flex items-center">
              <h3 className="text-xl mr-4 mb-6">Inventory Items</h3>
              <div className={`bg-inventbar rounded-lg border border-gray-300 h-12 ${showSearchBar ? 'w-80' : 'w-12'} flex p-3`}>
                <div className=" -ml-3 -mt-3 h-12 w-12 cursor-pointer" onClick={() => setShowSearchBar(!showSearchBar)}>
                  <img
                    className="w-5 h-5  ml-3 mt-3 "
                    src={searchIcon}
                    alt="Search Icon"
                  />
                </div>
                {showSearchBar && (
                  <input
                    type="text"
                    className=" p-2 h-11 -mt-3 w-80 bg-inventbar"
                    placeholder="Search by Item Name"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                )}
              </div>

              <div className="relative ml-4">
                <button className="bg-inventbar rounded-lg border border-gray-300  h-12 px-4 py-2 ite flex " onClick={() => setShowSortDropdown(!showSortDropdown)}>Sort by quantity <img className="w-3 ml-2 mt-3" src={arrowdown}/> </button>
                {showSortDropdown && (
                  <div className="absolute top-10 right-0 mt-2 bg-white border border-gray-300 rounded-lg shadow-md">
                    <button className="block px-4 py-2 text-gray-800 hover:bg-gray-200 w-full text-left" onClick={() => handleSortChange("asc")}>Asc</button>
                    <button className="block px-4 py-2 text-gray-800 hover:bg-gray-200 w-full text-left" onClick={() => handleSortChange("desc")}>Desc</button>
                    <button className="block px-4 py-2 text-gray-800 hover:bg-gray-200 w-full text-left" onClick={() => handleSortChange("")}>Reset</button>
                  </div>
                )}
              </div>
              <button className="bg-blue-500 ml-4 text-white px-4 py-2 rounded" onClick={handleCheckStock}>Check Stock</button>
              <button className="bg-blue-500 ml-4 text-white px-4 py-2 rounded" onClick={toggleAddItemPopup}>Add Item</button>
            </div>
            <div className="flex overflow-x-auto">
              <div className="table-wrapper">
                <table className="border-collapse rounded-lg border bg-white">
                  <thead>
                    <tr className="border-b border-gray-300">
                      <th className="p-2 text-left">Item Name</th>
                      <th className="p-2 text-left">Quantity</th>
                      <th className="p-2 text-left"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredInventoryItems.map((item, index) => (
                      index % 2 === 0 && (
                        <tr
                          key={index}
                          className="border-b border-gray-300"
                          onMouseEnter={() => handleRowHover(true, index)}
                          onMouseLeave={() => handleRowHover(false, index)}
                        >
                          <td className="p-2">
                            <div className="flex items-center justify-between">
                              <div className="mr-8">{item.name}</div>
                              <div>
                                {item.qty.toFixed(2)} {item.unit}
                              </div>
                            </div>
                            </td>
                            <td className="p-2">

                            {showManageStockButtonIndex === index && (
                              <button className="bg-ord text-white px-2 py-2 ml-16 rounded hover:bg-orange-600" onClick={() => handleStoClick(item)}>
                                <img className="w-4" src={sto} alt="Edit Icon" />
                              </button>
                            )}
                          </td>
                        </tr>
                      )
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="table-wrapper">
                <table className="border-collapse rounded-lg border bg-white">
                  <thead>
                    <tr className="border-b border-gray-300">
                      <th className="p-2 text-left">Item Name</th>
                      <th className="p-2 text-left">Quantity</th>
                      <th className="p-2 text-left"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredInventoryItems.map((item, index) => (
                      index % 2 !== 0 && (
                        <tr
                          key={index}
                          className="border-b border-gray-300"
                          onMouseEnter={() => handleRowHover(true, index)}
                          onMouseLeave={() => handleRowHover(false, index)}
                        >
                          <td className="p-2">{item.name}</td>
                          <td className="p-2 border-b">{item.qty.toFixed(2)} {item.unit}</td>
                          <td className="p-2">
                          {showManageStockButtonIndex === index && (
                              <button className="bg-ord text-white px-2 py-2 ml-16 rounded hover:bg-orange-600" onClick={() => handleStoClick(item)}>
                                <img className="w-4" src={sto} alt="Edit Icon" />
                              </button>
                            )}
                          </td>
                        </tr>
                      )
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : (
          <AddCategories />
        )}
      </div>
      {showPopup && (
        <Popup onClose={() => setShowPopup(false)} item={popupItem} onAddStock={handleAddStock} setQty={setQty} />
      )}
      {showLowStockPopup && (
        <LowStockPopup lowStockItems={lowStockItems} onClose={() => setShowLowStockPopup(false)} />
      )}

      {/* Add Item Popup */}
      {showAddItemPopup && (
  <div className="fixed z-10 inset-0 overflow-y-auto">
    <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
      <div className="fixed inset-0 transition-opacity" aria-hidden="true">
        <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
      </div>
      <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
      <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
        <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
          <div className="sm:flex sm:items-start">
            <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Add Inventory Item</h3>
              <div className="mt-2">
                <input type="text" className="border p-2 mb-2 w-full" placeholder="Item Name" value={name} onChange={(e) => setName(e.target.value)} />
                <input type="number" className="border p-2 mb-2 w-full" placeholder="Quantity" value={qty} onChange={(e) => setQty(e.target.value)} />
                <input type="number" className="border p-2 mb-2 w-full" placeholder="Minimum Quantity" value={minimumQuantity} onChange={(e) => setMinimumQuantity(e.target.value)} />
                <select className="border p-2 mb-2 w-full" value={unit} onChange={(e) => setUnit(e.target.value)}>
                  <option value="">Select Unit</option>
                  <option value="kg">kg</option>
                  <option value="gram">gram</option>
                  <option value="liter">liter</option>
                </select>
                <input type="number" className="border p-2 mb-2 w-full" placeholder="Price" value={price} onChange={(e) => setPrice(e.target.value)} />
                <select className="border p-2 mb-2 w-full" value={categ} onChange={(e) => handleCategoryChange(e.target.value)}>
                  <option value="">Select Category</option>
                  {categories
                  .filter(category=>category.storeId===PersoneStoreId)
                  .map(category => (
                    <option key={category._id} value={category.name}>{category.name}</option>
                  ))}
                </select>
                <select className="border p-2 mb-2 w-full" value={type} onChange={(e) => setType(e.target.value)}>
                  <option value="">Select Type</option>
                  <option value="product">Product</option>
                  <option value="consumable">Consumable</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
          <button onClick={saveInventoryItem} className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
            {editingItemId !== null ? 'Update Item' : 'Add Item'}
          </button>
          <button onClick={toggleAddItemPopup} className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
            Cancel
          </button>
        </div>
      </div>
    </div>
  </div>
)}

    </div>
  );
}

const ProductCategoriesSidebar = ({ selectedCategory, setSelectedCategory }) => {
  const categories = ['Add Inventory Items', 'Add Categories'];

  const handleClick = (category) => {
    setSelectedCategory(category);
  };

  return (
    <ul className="flex justify-center mb-8">
      {categories.map((category, index) => (
        <li
          key={index}
          className={` cursor-pointer mr-6 ${selectedCategory === category ? 'text-blue-500 border-b-2 border-blue-500' : ''}`}
          onClick={() => handleClick(category)}
        >
          {category}
        </li>
      ))}
    </ul>
  );
};

const Popup = ({ onClose, item, qty, onAddStock, setQty }) => {
  const [newTotal, setNewTotal] = useState(item.qty);
  const [showInventory, setShowInventory] = useState(false);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [checkedIndexes, setCheckedIndexes] = useState([]);
  const [selectedItemIndex, setSelectedItemIndex] = useState(null); // Track the index of the selected item
  const [searchItemQuery, setSearchItemQuery] = useState(''); // Define search query state
  const [personId, setPersonId] = useState('');
  const [personName, setPersonName] = useState('');
  const [PersoneStoreId, setPersoneStoreId] = useState('');

const extractPayloadData = () => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      return decodedPayload;
    }
    return null;
  };

  const payloadData = extractPayloadData();

  useEffect(() => {
    if (payloadData) {
      setPersonId(payloadData.id || '');
      setPersoneStoreId(payloadData.storeId || '');
      setPersonName(payloadData.name || '');
    }
  }, [payloadData]);


  useEffect(() => {
    if (qty && !isNaN(qty)) {
      setNewTotal(parseInt(item.qty) + parseInt(qty));
    }
    fetchAllInventoryItems();
  }, [qty, item]);

  const fetchAllInventoryItems = async () => {
    try {
      const response = await axios.get('http://localhost:3001/inventory-items');
      setInventoryItems(response.data);
    } catch (error) {
      console.error("Error fetching all inventory items:", error);
    }
  };
  

  const handleCheckboxChange = (index) => {
    const currentIndex = checkedIndexes.indexOf(index);
    if (currentIndex === -1) {
      setCheckedIndexes([...checkedIndexes, index]);
      setSelectedItemIndex(index); // Update the selected item index
    } else {
      const newCheckedIndexes = [...checkedIndexes];
      newCheckedIndexes.splice(currentIndex, 1);
      setCheckedIndexes(newCheckedIndexes);
      setSelectedItemIndex(null); // Deselect the item if checkbox is unchecked
    }
  };

  const handleShowInventory = () => {
    setShowInventory(!showInventory);
  };

  const handlePopupSubmit = () => {
    // Perform actions with selected items
    console.log("Selected items:", checkedIndexes.map(index => inventoryItems[index]));
    // Reset checked indexes and close the popup
    setCheckedIndexes([]);
    onClose();
  };

  return (
    <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-8 rounded-lg shadow-lg flex flex-col justify-start items-start">
        <span className="absolute top-2 right-2 text-gray-600 cursor-pointer" onClick={onClose}>
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
          </svg>
        </span>
        <div className="flex">
          <h2 className="text-xl font-bold mb-4">Add Stock</h2>
          <button className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800" onClick={handleShowInventory}>
            Show Inventory Items
          </button>
        </div>
        {showInventory && (
          <div className="z-10 bg-salt-200 rounded-lg shadow w-60 overflow-hidden mt-2">
            <select
              className="w-full py-2 px-3 text-sm text-black rounded"
              onChange={(e) => handleCheckboxChange(e.target.value)}
            > 
              {inventoryItems
              .filter(item => item.storeId === PersoneStoreId)
                .filter(item =>
                  item.name.toLowerCase().includes(searchItemQuery.toLowerCase())
                )
                .map((item, index) => (
                  <option key={index} value={index}>
                    {item.name}
                  </option>
                ))}
            </select>
          </div>
        )}

        {selectedItemIndex !== null && ( // Render details only if an item is selected
          <div className="mt-4">
            <h3 className="text-lg font-semibold">Selected Item Details</h3>
            <div className="flex">
              <div>
                <label className="block text-sm font-medium text-gray-700">Item</label>
                <input
                  type="text"
                  className="border border-gray-300 px-4 py-2 rounded-md w-full bg-gray-100"
                  value={inventoryItems[selectedItemIndex].name}
                  readOnly
                /></div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Current Quantity</label>
                <input
                  type="text"
                  className="border border-gray-300 px-4 py-2 rounded-md w-full bg-gray-100"
                  value={inventoryItems[selectedItemIndex].qty.toFixed(2)}
                  readOnly
                />
              </div>
              <div>

                <label className="block text-sm font-medium text-gray-700">Price</label>
                <input
                  type="text"
                  className="border border-gray-300 px-4 py-2 rounded-md w-full bg-gray-100"
                  value={inventoryItems[selectedItemIndex].price}
                  readOnly
                />
              </div>
              <div className="mb-2 pr-2">
  <label className="block text-sm font-medium text-gray-700">Enter quantity to add</label>
  <input
    type="number"
    className="border border-gray-300 px-4 py-2 rounded-md w-full"
    placeholder="Enter quantity to add"
    value={qty}
    onChange={(e) => {
      const value = e.target.value;
      // Ensure the value is a number and greater than 0
      if (value === '' || (Number(value) > 0 && Number.isInteger(Number(value)))) {
        setQty(value);
      }
    }}
  />
</div>

            </div>
          </div>
        )}

        <div className="flex  mb-2">
          <div className=" mb-2 pr-2">
            <label className="block text-sm font-medium text-gray-700">Item</label>
            <input
              type="text"
              className="border border-gray-300 px-4 py-2 rounded-md w-full bg-gray-100"
              value={item.name}
              readOnly
            />
          </div>
          <div className=" mb-2 pr-2">
            <label className="block text-sm font-medium text-gray-700">Current Quantity</label>
            <input
              type="text"
              className="border border-gray-300 px-4 py-2 rounded-md w-full bg-gray-100"
              value={item.qty.toFixed(2)}
              readOnly
            />
          </div>
          <div className=" mb-2 pr-2">
            <label className="block text-sm font-medium text-gray-700">Price</label>
            <input
              type="text"
              className="border border-gray-300 px-4 py-2 rounded-md w-full bg-gray-100"
              value={item.price}
              readOnly
            />
          </div>
          <div className="  mb-2 pr-2">
            <label className="block text-sm font-medium text-gray-700">Enter quantity to add</label>
            <input
              type="number"
              className="border border-gray-300 px-4 py-2 rounded-md w-full"
              placeholder="Enter quantity to add"
              value={qty}
              onChange={(e) => setQty(e.target.value)}
            />
          </div>
        </div>

        <div className="flex justify-center">
          <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600" onClick={onAddStock}>Add Stock</button>
        </div>
      </div>
    </div>
  );
};

export default Inventory;
