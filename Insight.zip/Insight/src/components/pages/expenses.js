import React, { useState, useEffect } from "react";
import axios from 'axios';
import UserCard from "./usercard";
import search from "../../Assets/search3.png";


const Expenses = () => {
    const [expenses, setExpenses] = useState([]);
    const [users, setUsers] = useState([]);
    const [totalSalaries, setTotalSalaries] = useState(0);
    const [totalExpenses, setTotalExpenses] = useState(0);
    const [expenseName, setExpenseName] = useState("");
    const [expenseValue, setExpenseValue] = useState("");
    const [expenseDate, setExpenseDate] = useState("");
    const [showPopup, setShowPopup] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");
    const [isProgrammable, setIsProgrammable] = useState(false);
    const [selectedMonth, setSelectedMonth] = useState('');
    const [personId, setPersonId] = useState('');
    const [personName, setPersonName] = useState('');
    const [PersoneStoreId, setPersoneStoreId] = useState('');
  
  const extractPayloadData = () => {
      const token = localStorage.getItem('token');
      if (token) {
        const payload = token.split('.')[1];
        const decodedPayload = JSON.parse(atob(payload));
        return decodedPayload;
      }
      return null;
    };
  
    const payloadData = extractPayloadData();
  
    useEffect(() => {
      if (payloadData) {
        setPersonId(payloadData.id || '');
        setPersoneStoreId(payloadData.storeId || '');
        setPersonName(payloadData.name || '');
      }
    }, [payloadData]);

    useEffect(() => {
        fetchExpenses();
        fetchUsers();
    }, []);

    useEffect(() => {
        const calculateTotalSalaries = () => {
            const total = users.reduce((acc, user) => acc + (user.salary || 0), 0);
            setTotalSalaries(total);
        };
        calculateTotalSalaries();
    }, [users]);

    useEffect(() => {
        const calculateTotalExpenses = () => {
            const total = expenses.reduce((acc, expense) => acc + (expense.price * expense.qty), 0);
            setTotalExpenses(total);
        };
        calculateTotalExpenses();
    }, [expenses, totalSalaries]);
    

    const fetchExpenses = async () => {
        try {
            const response = await axios.get('http://localhost:3001/expenses');
            setExpenses(response.data);
        } catch (error) {
            console.error("Error fetching expenses:", error);
        }
    };

    const fetchUsers = async () => {
        try {
            const response = await axios.get('http://localhost:3001/users');
            setUsers(response.data);
        } catch (error) {
            console.error("Error fetching users:", error);
        }
    };

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        const day = date.getDate().toString().padStart(2, '0');
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
    };

    const handleSaveExpense = async () => {
        try {
            const dateToSave = isProgrammable ? expenseDate : new Date().toISOString();
            await axios.post('http://localhost:3001/add-expense', {
                name: expenseName,
                price: expenseValue,
                date: dateToSave
            });
            fetchExpenses();
            setShowPopup(false);
            setExpenseName("");
            setExpenseValue("");
            setExpenseDate("");
        } catch (error) {
            console.error("Error saving expense:", error);
        }
    };

    const filteredExpenses = expenses.filter(expense =>
        expense.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
        (!selectedMonth || new Date(expense.date).getMonth() === parseInt(selectedMonth))
        && expense.storeId === PersoneStoreId
    );

    useEffect(() => {
        const calculateTotalExpenses = () => {
            const total = filteredExpenses.reduce((acc, expense) => acc + (expense.price * expense.qty), 0);
            setTotalExpenses(total);
        };
        calculateTotalExpenses();
    }, [filteredExpenses, selectedMonth]);

    return (
        <div className="bg-hist w-page h-full">
        <div className="container p-4 ">
            <div className="flex justify-between mt-8">
                <h1 className="text-2xl ml-3 font-bold">Expenses</h1>

        <div className='w-page1 h-20 relative -mt-4'>
          <input
            type="text"
            placeholder="Search "
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 border border-gray-300 p-1 w-64 h-9 rounded-lg m-4 ml-6  focus:outline-none focus:border-ord"
          />
          <div className="absolute left-9 top-1/2 transform pb-3 -translate-y-1/2">
            <img
              src={search}
              alt="Search"
              className="w-5 h-5  "
            />
          </div>
          <select
                    className="border h-11 rounded-lg p-2 mb-2"
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                >
                    <option value="">All Months</option>
                    <option value="0">January</option>
                    <option value="1">February</option>
                    <option value="2">March</option>
                    <option value="3">April</option>
                    <option value="4">May</option>
                    <option value="5">June</option>
                    <option value="6">July</option>
                    <option value="7">August</option>
                    <option value="8">September</option>
                    <option value="9">October</option>
                    <option value="10">November</option>
                    <option value="11">December</option>
                </select>
        </div>

                <div className="absolute top-0 right-0 mt-4 mr-4">
        <UserCard />
      </div>
            </div>

            <div className="absolute right-7">
                        <button className="bg-blue-500 text-white px-4 py-2 mb-4  rounded" onClick={() => setShowPopup(true)}>Add Expense</button>
            </div>
            <div className="my-8">
                {showPopup && (
                    <div className="fixed inset-0 bg-gray-900 bg-opacity-75 flex justify-center items-center">
                        <div className="bg-white p-8 rounded shadow-lg">
                            <h3 className="text-xl mb-4">Add Expense</h3>
                            <input
                                type="text"
                                className="border p-2 mb-2"
                                placeholder="Expense Name"
                                value={expenseName}
                                onChange={(e) => setExpenseName(e.target.value)}
                            />
                            <input
                                type="text"
                                className="border p-2 mb-2"
                                placeholder="Expense Price"
                                value={expenseValue}
                                onChange={(e) => setExpenseValue(e.target.value)}
                            />
                            <div className="flex">
                                <label className="flex items-center mb-2 mr-5">
                                    <input
                                        type="checkbox"
                                        className="mr-2"
                                        checked={isProgrammable}
                                        onChange={(e) => setIsProgrammable(e.target.checked)}
                                    />
                                    Programmable Expenses
                                </label>
                                {isProgrammable && (
                                    <input
                                        type="date"
                                        className="border p-2 mb-2"
                                        placeholder="Expense Date (DD/MM/YYYY)"
                                        value={expenseDate}
                                        onChange={(e) => setExpenseDate(e.target.value)}
                                    />
                                )}
                            </div>
                            <button className="bg-green-500 text-white px-4 py-2 rounded" onClick={handleSaveExpense}>Save</button>
                            <button className="bg-gray-500 text-white px-4 py-2 rounded ml-2" onClick={() => setShowPopup(false)}>Cancel</button>
                        </div>
                    </div>
                )}
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Value</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {filteredExpenses.map(expense => (
                            <tr key={expense.id}>
                                <td className="px-6 py-4 whitespace-nowrap">{formatDate(expense.date)}</td>
                                <td className="px-6 py-4 whitespace-nowrap">{expense.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap">{expense.type}</td>
                                <td className="px-6 py-4 whitespace-nowrap">${(expense.price * expense.qty || 0).toFixed(2)}</td>
                            </tr>
                        ))}
                        <tr className="">
                            <div className="bg-white absolute right-40 h-12 w-96">
                            <td className="px-6 py-4 whitespace-nowrap   font-semibold">Total Expenses: ${totalExpenses.toFixed(2)}</td>
                            </div>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        </div>

    );
}

export default Expenses;
