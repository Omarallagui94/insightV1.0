import React, { useState, useEffect } from "react";
import axios from 'axios';
import arrow from "../../Assets/sort.png";
import alertIcon from "../../Assets/alert.png";
import UserCard from "./usercard";
import searchIcon from "../../Assets/search.webp";
import { FaTimes, FaSearch } from 'react-icons/fa';

function Tasks() {
  // State variables
  const [userTasks, setUserTasks] = useState([]);
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [UserRole, setUserRole] = useState(null);  
  const [users, setUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [storeId, setStoreId] = useState('');
  const [taskName, setTaskName] = useState('');
  const [taskWorkerId, setTaskWorkerId] = useState('');
  const [taskDescription, setTaskDescription] = useState('');
  const [taskImportance, setTaskImportance] = useState('');
  const [taskTime, setTaskTime] = useState('');
  const [showPopup, setShowPopup] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [sortByTimeAsc, setSortByTimeAsc] = useState(true);
  const [showSearchBar, setShowSearchBar] = useState(true);

  // Fetch user tasks on user login
  useEffect(() => {
    const fetchUserTasks = async () => {
      try {
        const response = await axios.get(`http://localhost:3001/tasks/worker/${loggedInUser.id}`);
        setUserTasks(response.data);
      } catch (error) {
        console.error("Error fetching user tasks:", error);
      }
    };

    if (loggedInUser) {
      fetchUserTasks();
    }
  }, [loggedInUser]);

  // Decode and set logged in user
  useEffect(() => {
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      const payload = storedToken.split('.')[1];
      const decodedPayload = JSON.parse(atob(payload));
      setLoggedInUser(decodedPayload);
      setUserRole(decodedPayload.role);
    }
  }, []);

  // Fetch users on component mount
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get('http://localhost:3001/users');
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };

    fetchUsers();
  }, []);

  // Handle marking task completion
  const handleChangeStatus = async (status, taskId) => {
    try {
      await axios.put(`http://localhost:3001/tasks/${taskId}`, { status });
      console.log(`Task marked as ${status}`);
      const updatedTasks = userTasks.map(task => {
        if (task._id === taskId) {
          return { ...task, status };
        } else {
          return task;
        }
      });
      setUserTasks(updatedTasks);
    } catch (error) {
      console.error(`Error marking task as ${status}:`, error);
    }
  };

  // Format task time for display
  const formatTaskTime = (timeString) => {
    const date = new Date(timeString);
    const formattedDate = date.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit' });
    const formattedTime = date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
    return `${formattedDate} ${formattedTime}`;
  };

  // Filter tasks based on search query
  const filteredTasks = userTasks.filter(task =>
    task.task.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sort tasks by time
  const sortByTime = () => {
    const sortedTasks = [...userTasks].sort((a, b) => {
      if (sortByTimeAsc) {
        return new Date(a.time) - new Date(b.time);
      } else {
        return new Date(b.time) - new Date(a.time);
      }
    });
    setUserTasks(sortedTasks);
    setSortByTimeAsc(!sortByTimeAsc); // Toggle sorting order
  };
  

  // Filter users based on search query and logged in user's store
  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) && user.storeId === loggedInUser.storeId
  );

  // Handle submitting a new task
  const handleTaskSubmit = async () => {
    try {
      // Send a POST request to add the new task
      await axios.post(`http://localhost:3001/add-task`, {
        task: taskName,
        workerId: taskWorkerId,
        description: taskDescription,
        importance: taskImportance,
        status: "pending", // Set the default status to "pending"
        askerId: loggedInUser.id,
        time: taskTime,
      });
      console.log("Task created successfully");

      // Close the popup after task creation
      setShowPopup(false);

      // Fetch user tasks again after creating the task
      const response = await axios.get(`http://localhost:3001/tasks/worker/${loggedInUser.id}`);
      setUserTasks(response.data);
      
      // Reset form values after task creation
      resetFormValues();
    } catch (error) {
      console.error("Error creating task:", error);
    }
  };

  // Define the resetFormValues function to clear form fields
  const resetFormValues = () => {
    setTaskName('');
    setTaskWorkerId('');
    setTaskDescription('');
    setTaskImportance('');
    setTaskTime('');
  };

  return (
    <div className=" bg-hist h-full">
      <div className="container mx-auto ">
        <div className="flex p-4">
          <div className="absolute top-0 right-0 mt-4 mr-4">
            <UserCard />
          </div>
          <h1 className="text-2xl ml-5 pb-4 mt-6 text-center font-bold">My tasks</h1>
          <div className="flex justify-between items-center px-8 mt-4">
            <div>
              <div className="flex items-center">
                <img
                  className="w-4 h-4  cursor-pointer"
                  src={searchIcon}
                  alt="Search Icon"
                  onClick={() => setShowSearchBar(!showSearchBar)}
                />
                {showSearchBar && (
                  <input
                    type="text"
                    placeholder="Search task..."
                    className="ml-4 px-3 placeholder-gray-400 text-gray-700 relative bg-white rounded text-sm shadow outline-none focus:outline-none focus:ring w-80 h-10 border border-gray-300"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                )}
              </div>
            </div>
            <div className="flex ml-60">
              <button className="bg-slate-50 border border-gray-700 hover:bg-slate-100 text-black font-bold py-2 px-3 rounded flex items-center h-10" onClick={sortByTime}>
                Sort by Time <img src={arrow} className="ml-3 w-5" />
              </button>
              {/* Condition to show create task button based on user role */}
              {UserRole !== 'server' && (
                <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded ml-4" onClick={() => setShowPopup(true)}>+ Create a Task</button>
              )}
            </div>
          </div>
        </div>
        <div className="relative w-page1">
          <div className="px-64  mt-14">
            {filteredTasks.map((task, index) => (
              <div key={index} className={index % 2 === 0 ? 'bg-gray-100 p-4 rounded-md mb-2 flex items-center ' : 'bg-gray-200 p-4 rounded-md mb-2 flex items-center '}>
                <label className="mx-6 w-16">{task.task}</label>
                <div className="flex items-center  bg-slate-50 p-1 rounded-xl">
                  <img src={alertIcon} alt="Alert Icon" className="w-6 mr-1" />
                  <label className="mx-1 text-xs text-gray-500">{formatTaskTime(task.time)}</label>
                </div>
                <label className="mx-6 w-52">{task.description}</label>
                {task.importance === 'critical' && <div className="mr-auto flex items-center">
                  <div className="w-4 h-4 rounded-full bg-red-700 mr-2"></div>
                  <span className="mr-9">Critical</span>
                </div>}
                {task.importance === 'high' && <div className="mr-auto flex items-center">
                  <div className="w-4 h-4 rounded-full bg-orange-400 mr-2"></div>
                  <span>High</span>
                </div>}
                {task.importance === 'medium' && <div className="mr-auto flex items-center">
                  <div className="w-4 h-4 rounded-full bg-blue-400 mr-2"></div>
                  <span>Medium</span>
                </div>}
                {task.importance === 'low' && <div className="mr-auto flex items-center">
                  <div className="w-4 h-4 rounded-full bg-gray-500 mr-2"></div>
                  <span>Low</span>
                </div>}
                <div className="ml-auto mt-2 w-28">
                  <select
                    className="bg-gray-100 border border-gray-300 rounded-md py-1 px-2"
                    value={task.status}
                    onChange={(e) => handleChangeStatus(e.target.value, task._id)}
                  >
                    <option value="completed">Completed</option>
                    <option value="pending">Pending</option>
                    <option value="cancel">Cancel</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
          {showPopup && (
            <div className="fixed top-0 left-0 w-full h-full bg-gray-700 bg-opacity-50 flex justify-center items-center">
              <div className="bg-white p-6 rounded shadow-md w-96">
                <h2 className="text-xl font-bold mb-4">Create Task</h2>
                <div className="mb-4">
                  <label className="block mb-1">Task Name:</label>
                  <input type="text" className="form-input w-full border border-gray-300" value={taskName} onChange={(e) => setTaskName(e.target.value)} />
                </div>
                <div className="mb-4">
                  <label className="block mb-1">Task Description:</label>
                  <textarea className="form-textarea w-full border border-gray-300" value={taskDescription} onChange={(e) => setTaskDescription(e.target.value)} />
                </div>
                <div className="mb-4">
                  <label className="block mb-1">Importance:</label>
                  <select className="form-select w-full border border-gray-300" value={taskImportance} onChange={(e) => setTaskImportance(e.target.value)}>
                    <option value="">Select Importance</option>
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
                <div className="mb-4">
                  <label className="block mb-1">Task Time:</label>
                  <input type="datetime-local" className="form-input w-full border border-gray-300" value={taskTime} onChange={(e) => setTaskTime(e.target.value)} />
                </div>
                <div className="mb-4">
                  <label className="block mb-1">Select Worker:</label>
                  {/* Condition to limit worker selection for manager role */}
                  {UserRole === 'Manager' ? (
                    <select className="form-select w-full border border-gray-300" value={taskWorkerId} onChange={(e) => setTaskWorkerId(e.target.value)}>
                      <option value="">Select Worker</option>
                      {/* Filter users to show only servers */}
                      {filteredUsers
                        .filter(user => user.role === 'server')
                        .map(user => (
                          <option key={user.id} value={user._id}>{user.name}</option>
                        ))}
                    </select>
                  ) : (
                    <select className="form-select w-full border border-gray-300" value={taskWorkerId} onChange={(e) => setTaskWorkerId(e.target.value)}>
                      <option value="">Select Worker</option>
                      {/* Show all users */}
                      {filteredUsers.map(user => (
                        <option key={user.id} value={user._id}>{user.name}</option>
                      ))}
                    </select>
                  )}
                </div>
                <div className="flex justify-end">
                  <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2" onClick={handleTaskSubmit}>Create</button>
                  <button className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded" onClick={() => setShowPopup(false)}>Cancel</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Tasks;
