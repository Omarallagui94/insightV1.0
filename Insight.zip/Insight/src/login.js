import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Header from './components/header';
import {jwtDecode} from 'jwt-decode'; // Corrected import statement

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  axios.defaults.withCredentials = true;

  const loginUser = async () => {
    try {
      const response = await axios.post('http://localhost:3001/login', { email, password });
      const { data } = response;
      if (data.Status === "Success") {
        const { token } = data;
        const decodedToken = jwtDecode(token);
        const { name, role, storeId } = decodedToken;

        localStorage.setItem('token', token);
        localStorage.setItem('name', name);
        localStorage.setItem('role', role);
        localStorage.setItem('storeId', storeId);


        navigate('/home');
      } else {
        setError("Invalid email or password");
      }
    } catch (err) {
      console.error(err);
      setError("An error occurred while logging in");
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    await loginUser();
  }

  return (
    <>
      <Header />
      <div className="flex justify-center items-center h-screen">
        <div className="bg-custom-gray p-8 rounded-3xl shadow-md w-434 h-488">
          <h2 className="text-3xl mb-14 text-center text-custom-green">LOGIN</h2>
          {error && <p className="text-red-500 mb-4">{error}</p>}
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="email" className="block mb-3 pl-12 text-lg font-bold">Email</label>
              <input
                type="text"
                id="email"
                name="email"
                placeholder='Email'
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-72 px-3 py-2 ml-9 border rounded focus:outline-none focus:border-blue-500"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="password" className="block mb-3 pl-12 text-lg font-bold">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                placeholder='Password'
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-72 px-3 py-2 ml-9 border rounded focus:outline-none focus:border-blue-500"
              />
            </div>
            <div className="flex justify-center">
              <button type="submit" className="bg-custom-green text-white py-2 px-4 rounded hover:bg-green-700 justify-center mt-14 h-12 w-28">Login</button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}

export default LoginPage;
