import React from 'react';
import about from '../../Assets/about.png';

function Index() {
  const imageStyle = {
    width: '984px',
    height: '850px',
    marginTop: '16px', 
    marginLeft: 'auto',
    marginRight: 'auto',
    display: 'block',
  };

  return (
    <>
             

    <div className="text-center mt-28">
      <div className="text-green-500 text-sm mb-2"> CONTACTS</div>

      <p className="text-6xl text-black font-semibold mb-2 mt-9">
      Video and chat communication
      </p>

      <p className="text-g1 text-sm mb-4 mt-9 ">
        We are a young innovation company that emerged with the goal of <br/>
      </p>

      <img src={about} alt="About us" style={imageStyle} />
    </div>
    </>
  );
}

export default Index;
