import React, { useState, useEffect } from "react";
import { v4 as uuidv4 } from 'uuid'; // Import uuid
import editIcon from '../../Assets/draw.png';
import deleteIcon from '../../Assets/delete.png';
import Header from "../../components/header";

function Categories() {
  const initialCategories = ["Desert", "Burgers", "Pizza"];
  const [categories, setCategories] = useState(initialCategories);
  const [newCategory, setNewCategory] = useState("");
  const [editingCategoryId, setEditingCategoryId] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const filteredCategories = initialCategories.filter(category =>
      category.toLowerCase().includes(searchQuery.toLowerCase())
    );
    setCategories(filteredCategories);
  }, [searchQuery]);

  const handleAddCategory = () => {
    if (newCategory.trim() !== "") {
      if (editingCategoryId !== null) {
        const updatedCategories = [...categories];
        updatedCategories[editingCategoryId] = newCategory;
        setCategories(updatedCategories);
        setEditingCategoryId(null);
      } else {
        setCategories([...categories, newCategory]);
      }
      setNewCategory("");
    }
  };

  const handleDeleteCategory = (index) => {
    const updatedCategories = [...categories];
    updatedCategories.splice(index, 1);
    setCategories(updatedCategories);
  };

  const handleEditCategory = (index) => {
    setNewCategory(categories[index]);
    setEditingCategoryId(index);
  };

  return (
    <>

    <div className="flex justify-center items-center pl-96 mt-16">
      <div>
        <h1 className="text-3xl mb-4 text-center font-bold">Manage Categories</h1>
        <div>
       
          <table className="table-auto w-full border border-gray-300 shadow-sm rounded mb-16">
            <thead>
              <tr className="bg-gray-200">
                <th className="px-4 py-2 border border-gray-300">Categories</th>
                <th className="px-4 py-2 border border-gray-300">Options</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <input
                    type="text"
                    className="border p-2"
                    placeholder="Add New Category"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                  />
                </td>
                <td>
                  <button
                    className="bg-green-500 text-white py-2 px-4 rounded"
                    onClick={handleAddCategory}
                  >
                    {editingCategoryId !== null ? 'Update' : 'Add'}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
          <div className="">
            <div className="overflow-x-auto">
              <input
                type="text"
                className="border p-2 mb-4 w-72"
                placeholder="Search by Category Name"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <table className="w-full table-auto border border-gray-300">
                <thead>
                  <tr className="bg-gray-200">
                    <th className="px-4 py-2 border border-gray-300">Category Name</th>
                    <th className="px-4 py-2 border border-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {categories.map((category, index) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-gray-100' : 'bg-gray-200'}>
                      <td className="px-4 py-2 border border-gray-300">{category}</td>
                      <td className="px-4 py-2 border border-gray-300">
                        <button
                          className="py-1 px-2 rounded-full mr-2"
                          onClick={() => handleEditCategory(index)}
                        >
                          <img className="w-3 h-3" src={editIcon} alt="Edit Icon" />
                        </button>
                        <button
                          className="py-1 px-2 rounded"
                          onClick={() => handleDeleteCategory(index)}
                        >
                          <img className="w-3 h-3" src={deleteIcon} alt="Delete Icon" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}

export default Categories;
