import React, { useState } from 'react';
import das from '../../Assets/das.png';
import Header from '../../components/header';
import About from "../About";
import Features from "../Features";
import Pricing from "../Pricing";
import Contacts from "../Contacts";
import axios from 'axios';

function Welcome() {
  const [phoneNumber, setPhoneNumber] = useState('');

  const savePhoneNumber = () => {
    const status = 'waiting'; // Default status value
    axios
      .post("http://localhost:3001/add-contact", { phoneNumber, status })
      .then((res) => {
        console.log('Phone number saved successfully!');
        // Optionally, you can display a success message or perform other actions here
      })
      .catch((error) => {
        console.error('Failed to save phone number:', error);
        // Optionally, you can display an error message or perform other actions here
      });
  };

  return (
    <>
      <Header />

      <div className="text-center mt-28">
        <div className="text-green-500 text-sm mb-2">WE  &nbsp;ARE &nbsp; INSIGHT</div>

        <p className="text-6xl text-logtex font-semibold mb-2 mt-9">
          We help Streamline <br/> your store operation.
        </p>

        <p className="text-g1 text-sm mb-4 mt-9 ">
          Insight is your all-in-one admin platform for effortless order tracing, delivery <br/>management, and sales analysis. Powered by AI to deliver the best possible solutions<br/> in your Business Management!
        </p>

        <div className="flex flex-col items-center justify-center gap-8 mt-10">
          <div className="flex items-center justify-center mb-4">
            <input
              type="text"
              placeholder="Enter your phone number"
              className="w-64 h-11 px-4 py-2 bg-b2   rounded focus:outline-none"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
            />

            <button
              className="px-4 py-2 bg-bout w-28  h-10 text-white rounded"
              onClick={savePhoneNumber}
            >
              Send
            </button>
          </div>
          
          <img src={das} alt="dashboard" className="mt-12" />
        </div>
      </div>

      <div id="about" className="text-center mt-28">
        <About/>
      </div>
      <div id="features" className="text-center mt-28">
        <Features/>
      </div>
      <div id="pricing" className="text-center mt-28">
        <Pricing/>
      </div>
      <div id="contacts" className="text-center mt-28">
        <Contacts/>
      </div>
    </>
  );
}

export default Welcome;
