import React, { useState } from "react";
import { v4 as uuidv4 } from 'uuid'; // Import uuid
import editIcon from '../../Assets/draw.png';
import deleteIcon from '../../Assets/delete.png';
import searchIcon from '../../Assets/search.webp';
import Categories from "../Categories";
import Header from "../../components/header";

function AddProducts() {
  const [price, setPrice] = useState(0);
  const [qty, setQty] = useState(0);
  const [users, setUsers] = useState([]);
  const [name, setName] = useState("");
  const [sum, setSum] = useState(0);
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [editingProductIndex, setEditingProductIndex] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearchBar, setShowSearchBar] = useState(false); // New state to toggle search bar
  const [selectedCategory, setSelectedCategory] = useState("Add Products"); // State to track selected category

  // Define constant array for categories
  
  const categories = ["Desert", "Burgers", "Pizza"];

  function Calculation() {
    if (editingProductIndex !== null) {
      const updatedUsers = [...users];
      updatedUsers[editingProductIndex] = { id: uuidv4(), name, qty, price, sum, category, description }; // Generate ID
      setUsers(updatedUsers);
      setEditingProductIndex(null);
    } else {
      setUsers([...users, { id: uuidv4(), name, qty, price, sum, category, description }]); // Generate ID
    }
    // Clear the input fields
    setName("");
    setQty(0);
    setPrice(0);
    setSum(0);
    setCategory("");
    setDescription("");
  }

  const handlePriceChange = (e) => {
    const newPrice = parseFloat(e.target.value);
    if (!isNaN(newPrice)) {
      setPrice(newPrice);
      calculateTotal(newPrice, qty);
    }
  };

  // Event handler for quantity selection
  const handleQuantityChange = (e) => {
    const newQuantity = parseInt(e.target.value);
    if (!isNaN(newQuantity)) {
      setQty(newQuantity);
      calculateTotal(price, newQuantity);
    }
  };

  // Calculate the total based on price and quantity
  const calculateTotal = (price, qty) => {
    const newTotal = price * qty;
    setSum(newTotal);
  };

  // Function to handle editing a product
  const handleEditProduct = (index) => {
    const productToEdit = users[index];
    setName(productToEdit.name);
    setQty(productToEdit.qty);
    setPrice(productToEdit.price);
    setSum(productToEdit.sum);
    setCategory(productToEdit.category);
    setDescription(productToEdit.description);
    setEditingProductIndex(index);
  };

  // Function to handle deleting a product
  const handleDeleteProduct = (index) => {
    const updatedUsers = [...users];
    updatedUsers.splice(index, 1);
    setUsers(updatedUsers);
  };

  // Function to filter products based on search query
  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
 <>
   { <Header />} {/* Render header only if user is logged in */}

    <div className="flex justify-center items-center pl-44 mt-16">
      <div>
        <ProductCategoriesSidebar selectedCategory={selectedCategory} setSelectedCategory={setSelectedCategory} />
        {selectedCategory === "Add Products" ? ( // Render Add Products component if selected category is "Add Products"
          <>
            <h1 className="text-3xl mb-4 text-center font-bold">Add Products</h1>
            <h3 className="text-xl mr-4 mb-6">Products</h3>
            <table className="table-auto w-full border border-gray-300 shadow-sm rounded mb-8">
              <thead>
                <tr className="bg-gray-200">
                  <th className="px-4 py-2 border border-gray-300">Categories</th>
                  <th className="px-4 py-2 border border-gray-300">Product Name</th>
                  <th className="px-4 py-2 border border-gray-300">Description</th>
                  <th className="px-4 py-2 border border-gray-300">Price</th>
                  <th className="px-4 py-2 border border-gray-300">Options</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <select className="border p-2" value={category} onChange={(event) => setCategory(event.target.value)}>
                      <option value="">Select Category</option>
                      {categories.map((category, index) => (
                        <option key={index} value={category}>{category}</option>
                      ))}
                    </select>
                  </td>
                  <td><input type="text" className="border p-2" placeholder="Item Name" value={name} onChange={(event) => setName(event.target.value)} /></td>
                  <td><input type="text" className="border p-2" placeholder="Description" value={description} onChange={(event) => setDescription(event.target.value)} /></td>
                  <td><input type="text" className="border p-2" placeholder="Enter Price" value={price} onChange={handlePriceChange} /></td>
                  <td><button className="bg-green-500 text-white py-2 px-4 rounded" type="submit" onClick={Calculation}>{editingProductIndex !== null ? 'Update' : 'Add'}</button></td>
                </tr>
              </tbody>
            </table>
            <div className="mb-4 flex items-center">
              <h3 className="text-xl mr-4">Products</h3>
              <img
                className="w-4 h-4 mr-2 cursor-pointer"
                src={searchIcon}
                alt="Search Icon"
                onClick={() => setShowSearchBar(!showSearchBar)} // Toggle search bar visibility
              />
              {showSearchBar && ( // Conditionally render the search bar based on state
                <input
                  type="text"
                  className="border p-2"
                  placeholder="Search by Product Name"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              )}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full table-auto border border-gray-300"> {/* Set the width */}
                <thead>
                  <tr className="bg-gray-200">
                    <th className="px-4 py-2 border border-gray-300">Product ID</th>
                    <th className="px-4 py-2 border border-gray-300">Product Name</th>
                    <th className="px-4 py-2 border border-gray-300">Category</th>
                    <th className="px-4 py-2 border border-gray-300">Description</th>
                    <th className="px-4 py-2 border border-gray-300">Price</th>
                    <th className="px-4 py-2 border border-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((row, index) => (
                    <tr key={index} className={index % 2 === 0 ? 'bg-gray-100' : 'bg-gray-200'}>
                      <td className="px-4 py-2 border border-gray-300">{row.id}</td>
                      <td className="px-4 py-2 border border-gray-300">{row.name}</td>
                      <td className="px-4 py-2 border border-gray-300">{row.category}</td>
                      <td className="px-4 py-2 border border-gray-300">{row.description}</td>
                      <td className="px-4 py-2 border border-gray-300">{row.price}</td>
                      <td className="px-4 py-2 border border-gray-300">
                        <button className="py-1 px-2 rounded-full mr-2" onClick={() => handleEditProduct(index)}>
                          <img className="w-3 h-3" src={editIcon} alt="Edit Icon" />
                        </button>
                        <button className="py-1 px-2 rounded" onClick={() => handleDeleteProduct(index)}>
                          <img className="w-3 h-3" src={deleteIcon} alt="Edit Icon" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <Categories /> // Render Categories component if selected category is "Add Categories"
        )}
      </div>
    </div>
    </>
  );
}

const ProductCategoriesSidebar = ({ selectedCategory, setSelectedCategory }) => {
  const categories = ['Add Products', 'Add Categories'];

  const handleClick = (category) => {
    setSelectedCategory(category);
  };

  return (
    <ul className="flex justify-center mb-8">
      {categories.map((category, index) => (
        <li 
          key={index} 
          className={` cursor-pointer mr-6 ${selectedCategory === category ? 'text-blue-500 border-b-2 border-blue-500' : ''}`}
          onClick={() => handleClick(category)}
        >
          {category}
        </li>
      ))}
    </ul>
  );
};

export default AddProducts;
