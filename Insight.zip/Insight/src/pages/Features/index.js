import React from 'react';
import feat from '../../Assets/feat.png';
import Header from '../../components/header';

function Index() {
  const sectionStyle = {
    margin: '20px', // Adjust the margin as needed
  };

  return (
    <>   

    <div className="bg-bla text-white min-h-screen">
      <div className="text-center"><br/><br/><br/><br/><br/>
        <div className="text-sm mb-2">FEATURES </div>

        <p className="text-6xl font-semibold  mb-2 mt-9">
          Powerful features that set us apart
        </p>

        <p className="text-g1 text-sm mb-4 mt-9 ">
          Key features of our product that might interest you
        </p>

        <div className="flex justify-center items-center mt-20">
        <div className="text-left text-sm" style={sectionStyle}>
            <img src={feat} alt="image" className="" />
            <h1 className='mt-6'>Sales Analytics</h1>
            <p className='text-xs mt-2 text-gray-400'>
              Gain valuable insights with sales analytics tools,<br/> including statistics trends, and
              reports to <br/>understand your audience’s needs and optimize
            </p>
            <h1 className='text-sm mt-1'>Read more </h1>

          </div>

          <div className="text-left text-sm" style={sectionStyle}>
            <img src={feat} alt="image" className="" />
            <h1 className='mt-6'>Sales Analytics</h1>
            <p className='text-xs mt-2 text-gray-400'>
              Gain valuable insights with sales analytics tools,<br/> including statistics trends, and
              reports to <br/>understand your audience’s needs and optimize
            </p>
            <h1 className='text-sm mt-1'>Read more </h1>

          </div>

          <div className="text-left text-sm" style={sectionStyle}>
            <img src={feat} alt="image" className="" />
            <h1 className='mt-6'>Sales Analytics</h1>
            <p className='text-xs mt-2 text-gray-400'>
              Gain valuable insights with sales analytics tools,<br/> including statistics trends, and
              reports to <br/>understand your audience’s needs and optimize
            </p>
            <h1 className='text-sm mt-1'>Read more </h1>
          </div>
        </div>
      </div>
    </div>
    </>

  );
}

export default Index;
