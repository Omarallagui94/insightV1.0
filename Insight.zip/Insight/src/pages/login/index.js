import React, { useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3000/login', { email, password });
      console.log(response);
      if (response.data === "success") {
        // Redirect user to Home page upon successful login
        navigate('/home/welcome');
      } else {
        setError("Login failed. Please check your credentials.");
      }
    } catch (err) {
      console.error(err);
      setError("Login failed. Please check your credentials.");
    }
  }

  return (
    <div className="flex justify-center items-center h-screen">
      <div className="bg-custom-gray p-8 rounded-3xl shadow-md w-434 h-488">
        <h2 className="text-3xl mb-14 text-center text-custom-green">SIGN IN </h2>
        {error && <p className="text-red-500 mb-4">{error}</p>}
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="email" className="block mb-3 pl-12 text-lg font-bold">User name</label>
            <input
              type="text"
              id="email"
              name="email"
              placeholder='user name'
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-72 px-3 py-2 ml-9 border rounded focus:outline-none focus:border-blue-500"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="email" className="block mb-3 pl-12 text-lg font-bold">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              placeholder='Password'
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-72 px-3 py-2  ml-9 border rounded focus:outline-none focus:border-blue-500"
            />
          </div>
          <div className="flex justify-center">
            <button type="submit" className="bg-custom-green text-white py-2 px-4 rounded hover:bg-green-700 justify-center mt-14 h-12 w-28">Login</button>
          </div>
        </form>
        <p className="mt-4 text-center">Don't have an account? <Link to="/register" className="text-blue-500">Sign Up</Link></p>
      </div>
    </div>
  );
}

export default LoginPage;
