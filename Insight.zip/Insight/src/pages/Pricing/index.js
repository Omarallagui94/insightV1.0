// Import React and other necessary modules
import React from 'react';
import logo from "../../Assets/insight.png";
import logowhite from "../../Assets/insightwhite.png";

// Define the Index component
function Index() {
  return (
<>

    <div>
      <div className="flex flex-wrap justify-center">
        {/* Pricing Information */}
        <div className="w-full text-center mt-28">
          <div className="text-green-500 text-sm mb-2">PRICING</div>
          <p className="text-6xl text-black font-semibold mb-2 mt-9">
            Explore our pricing options.
          </p>
          <p className="text-g1 text-sm mb-4 mt-9 ">
            Get a reliable tool to manage your online store, our affordable plans
          </p>
        </div>

        {/* Combined Table */}
        <div className= "mt-20  p-4 mx-auto">
          <table className="border-collapse bg-b2 border border-black w-full h-500 rounded-lg overflow-hidden">
            <tr>
              <td className="border p-4 text-left w-80 rounded-lg">
                <img src={logo} alt="" className="h-14 mb-4" />
                <div className="font-bold">Free Plan</div>
                <div className="text-xs text-gray-400 mt-2">The best for start</div>
                <div className="flex items-center mt-5">
                  <div className="font-bold text-4xl">Free</div>
                </div>
                <div className="text-sm text-gray-400 mt-2">
                  <div>/month</div>
                </div>
                <div className="ml-2 mt-10 text-center">
                  <div className="text-sm text-gray-400 flex items-center">
                    <input type="checkbox" checked />
                    <div className='ml-3'>Access to basic features</div>
                  </div>
                  <div className="text-sm text-gray-400 flex items-center mt-6">
                    <input type="checkbox" checked />
                    <div className='ml-3'>Order tracking</div>
                  </div>
                  <div className="text-sm text-gray-400 flex items-center mt-6">
                    <input type="checkbox" checked />
                    <div className='ml-3'>Communication</div>
                  </div>
                  <button className="bg-green-200 hover:bg-green-300 text-green-700 py-2 px-4 w-48 rounded-lg mt-20">
                    &nbsp; &nbsp; Try right now &nbsp;&nbsp;
                  </button>
                </div>
              </td>
              <td className="border p-4 text-left w-80 rounded-lg">
                <img src={logo} alt="" className="h-14 mb-4" />
                <div className="font-bold">Standard Plan</div>
                <div className="text-xs text-gray-400 mt-2">For users who want to do more</div>
                <div className="flex items-center mt-5">
                  <div className="font-bold text-4xl">$99</div>
                </div>
                <div className="text-sm text-gray-400 mt-2">
                  <div>/month</div>
                </div>
                <div className="ml-2 mt-10 text-center">
                  <div className="text-sm text-gray-400 flex items-center mt-6">
                    <input type="checkbox" checked />
                    <div className='ml-3'>Enhance functionality</div>
                  </div>
                  <div className="text-sm text-gray-400 flex items-center mt-6">
                    <input type="checkbox" checked />
                    <div className='ml-3'>Sales analytics</div>
                  </div>
                  <div className="text-sm text-gray-400 flex items-center mt-6">
                    <input type="checkbox" checked />
                    <div className='ml-3'>Delivery optimization</div>
                  </div>
                  <button className="bg-green-200 hover:bg-green-300 text-green-700 py-2 px-4 w-48 rounded-lg mt-20">
                    &nbsp; &nbsp; Try right now &nbsp;&nbsp;
                  </button>
                </div>
              </td>
              <td className="border p-4 text-left bg-b1 text-white w-80 rounded-lg">
                <img src={logowhite} alt="" className="h-14 mb-4" />
                <div className="font-bold">Corporate Plan</div>
                <div className="text-xs text-white mt-2">Your entire team in one place</div>
                <div className="flex items-center mt-5">
                  <div className="font-bold text-4xl">$249</div>
                </div>
                <div className="text-sm text-white mt-2">
                  <div>/month</div>
                </div>
                <div className="ml-2 mt-6 text-center">
                  <div className="text-sm text-white flex items-center">
                    <input type="checkbox" checked />
                    <div className='ml-3'>Custom plan</div>
                  </div>
                  <div className="text-sm text-white flex items-center mt-6">
                    <input type="checkbox" checked />
                    <div className='ml-3'>Personal account manager</div>
                  </div>
                  <div className="text-sm text-white flex items-center mt-6">
                    <input type="checkbox" checked />
                    <div className='ml-3 '>Features and customization</div>
                  </div>
                  <button className="bg-white hover:bg-green-300 text-green-950 py-2 px-4 rounded-lg w-48 mt-20">
                    &nbsp; &nbsp; Try right now &nbsp;&nbsp;
                  </button>
                </div>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </div>
    </>
  );
}

// Export the Index component
export default Index;
