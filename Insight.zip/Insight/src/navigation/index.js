import React, { useState } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Header from '../components/header';
import About from '../pages/About';
import Features from '../pages/Features';
import Pricing from '../pages/Pricing';
import Solutions from '../pages/Solutions';
import Welcome from '../pages/Welcome';
import Contacts from '../pages/Contacts';
import LoginPage from '../login';
import LoggedInLayout from "../components/pages/LoggedInLayout "
import Signup from "../signup"

const Navigation = () => {
  // const [isLoggedIn, setIsLoggedIn] = useState(true);
 const [user, setUser] = useState(null);


  return (
    <BrowserRouter>
      <Routes>
        <Route path="/about" element={<About />} />
        <Route path="/features" element={<Features />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/solutions" element={<Solutions />} />
        <Route path="/contacts" element={<Contacts />} />
        <Route path="/register" element={<Signup />} />
        <Route path="/" element={<Welcome />} />
        <Route path="/login" element={<LoginPage/>} />


        {/* Use the LoggedInLayout for logged-in pages */}
        <Route path="/home/*" element={<LoggedInLayout userName={user && user.name} />} />
      </Routes>
    </BrowserRouter>
  );
};

export default Navigation;
