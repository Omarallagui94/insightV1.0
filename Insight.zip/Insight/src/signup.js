import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';


const Signup = ({ setIsLoggedIn }) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    axios.post('http://localhost:3001/register',{ name, email, password })
    .then(ress =>{

      navigate("/login")

    }).catch((err)=> console.log(err))


  }
  
  return (
    <div className="flex justify-center items-center h-screen">
      <div className="bg-custom-gray p-8 rounded-3xl shadow-md w-434 h-488">
        <h2 className="text-3xl mb-14 text-center text-custom-green">SIGN IN</h2>
        {error && <p className="text-red-500 mb-4">{error}</p>}
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="name" className="block mb-3 pl-12 text-lg font-bold">Name</label>
            <input
              type="text"
              id="name"
              name="name"
              placeholder='Name'
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-72 px-3 py-2 ml-9 border rounded focus:outline-none focus:border-blue-500"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="email" className="block mb-3 pl-12 text-lg font-bold">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder='Email'
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-72 px-3 py-2 ml-9 border rounded focus:outline-none focus:border-blue-500"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="password" className="block mb-3 pl-12 text-lg font-bold">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              placeholder='Password'
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-72 px-3 py-2 ml-9 border rounded focus:outline-none focus:border-blue-500"
            />
          </div>
          <div className="flex justify-center"> 
            <button type="submit" className="bg-custom-green text-white py-2 px-4 rounded hover:bg-green-700 justify-center mt-14 h-12 w-28">Login</button>
          </div>
        </form>
        <p className="mt-4 text-center">Don't have an account? <Link to="/register" className="text-blue-500">Sign Up</Link></p>
      </div>
    </div>
  );
}

export default Signup;